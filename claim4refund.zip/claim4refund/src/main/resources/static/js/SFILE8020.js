$(document).ready(function () {
    $('#history-remark').DataTable({
        responsive: true,
        "dom": 'lrtip',
        //"order": [[4, "desc"]]
    });
    $('#history-event').DataTable({
        responsive: true,
        "dom": 'lrtip',
        //"order": [[4, "desc"]]
    });
    $('#history-update').DataTable({
        responsive: true,
        "dom": 'lrtip',
        //"order": [[4, "desc"]]
    });
});
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};
$('#add-remark-btn').on('click',function(){
    $('#remark-input-container').toggle();
});
$('#clear-remark-btn').on('click',function(){
   $('#remark-input').val('')
});
$('#submit-add-remark').on('click',function(){
    $('#add-remark-result').text("");
   let rm= $('#remark-input').val();
  let claimId= getUrlParameter("id");
   $.post('/admin/claimhistory/add-remark?'+$.param({"claimId":claimId,"remark":rm}))
       .then(function(res){
           console.log(res);
            if(res.success){
                $('#remark-input').val('');
                $('#add-remark-result').text("success")
            }else{
                $('#add-remark-result').text(res.message)
            }
       })
       .catch(function(err){
           $('#add-remark-result').text(err)
       })
});