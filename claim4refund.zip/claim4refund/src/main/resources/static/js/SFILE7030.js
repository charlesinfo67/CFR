$(document).ready(function() {
    if ($('select[name=appType]').val() == "I") {
        $("#individual").show();
        $("#firstName").prop('required', true);
        $("#lastName").prop('required', true);
        $("#company").hide();
        $("#companyName").prop('required', false);
        $("#agent").hide();
    } else if ($('select[name=appType]').val() == "C") {
        $("#individual").hide();
        $("#firstName").prop('required', false);
        $("#lastName").prop('required', false);
        $("#company").show();
        $("#companyName").prop('required', true);
        $("#agent").show();
    }
    if ($('input[name=claimRefundTypeId]').val() == 1) {
        $("#section-2").show();
        $("#section-3").hide();
    } else {
        $("#section-2").hide();
        $("#section-3").show();
    }

    $('select[name=appType]').on("change", function () {
        if ($(this).val() == "I") {
            $("#individual").show();
            $("#firstName").prop('required', true);
            $("#lastName").prop('required', true);
            $("#company").hide();
            $("#companyName").prop('required', false);
            $("#agent").hide();
        } else if ($(this).val() == "C") {
            $("#individual").hide();
            $("#firstName").prop('required', false);
            $("#lastName").prop('required', false);
            $("#company").show();
            $("#companyName").prop('required', true);
            $("#agent").show();
        }
    });

    $('input[name=claimRefundTypeId]').on("change", function () {
        if($(this).val() == 1) {
            $("#section-2").show();
            $("#section-3").hide();
        } else {
            $("#section-2").hide();
            $("#section-3").show();
        }
    });

});

function formatAPN(input) {
	$(input).val($(input).val().replace(/(\d{3})(\d{3})(\d{2})/, "$1-$2-$3."));
}
$("#btn-preview").click(function () {
    var pdf_link = "";
    $.post("../createnewclaim/preview", $('form').serialize(), function (res) {
        if (res.success) {
            pdf_link = res.value;
            var iframe = '<object data="' + pdf_link + '" type="application/pdf" width="100%" height="600px">' +
                '  Cannot load PDF : <a href="' + pdf_link + '">Download</a>' +
                '</object>';
            showPreView(iframe);
            $("#error-panel").html('');
            $(".error-item").each(function () {
                $(this).removeClass("error-item");
            });
        } else {
            //showAlertMessage(res.message);
            $("#error-panel").html('<p class="error-message">' + res.message + '</p>');
            $("#error-panel").focus();
            var items = res.value.replace(/\[/g, "").replace(/\]/g, "").split(" ");
            $("form").each(function () {
                $(this).find(':input').each(function () {
                    if ($.inArray($(this).prop('id'), items) !== -1) {
                        $(this).addClass("error-item");
                    } else {
                        $(this).removeClass("error-item");
                    }
                })
            });
        }
    }).done(function (res) {
        // alert("second success" + res.success);
    }).fail(function (e) {
        showAlertMessage("error: " + e.responseText);
    });
});

$(document.body).on("keyup mouseup", "#applicable-property .amount", function() {
	var total = 0;
	$(".amount").each(function() {
		total += parseInt($(this).val());
	});
	$("#totalAmount").text(addCommas(total));
});

// format tel number
window.addFormat = function addFormat(f) {
    if (f.value == '') return;
    var r = /(\D+)/g,
        npa = '',
        nxx = '',
        last4 = '';
    f.value = f.value.replace(r, '');
    npa = f.value.substr(0, 3);
    nxx = f.value.substr(3, 3);
    last4 = f.value.substr(6, 4);
    f.value = '(' + npa + ') ' + nxx + '-' + last4;
};

//event
function deleteProperty(button) {
    var row_index = $(button).parent().parent().index();
    $("#applicable-property").load('../createnewclaim/new?removeRow=' + row_index + ' #applicable-property', $('form').serialize());
}
function addProperty() {
    $("#applicable-property").load('../createnewclaim/new?addRow #applicable-property', $('form').serialize());
}
$('#selectAll').click(function (e) {
    $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
});

$('#btn-submit').click(function (e) {
    // if (!$("form")[0].checkValidity()) {
        // If any option in Section 5 checked
        $("#manual-review").closest('table').find('td input:checkbox').each(function (index) {
            if ($(this).prop('checked')) {
                e.preventDefault();
                $("#btn-incomplete").trigger("click");
                return false;
            }
        });
    // }
});

$("form").submit(function (event) {

    if (!confirm("Are you sure you want to finalize the claim?")) {
        event.preventDefault();
    }

    if (isDup()) {
        if (!confirm("Do you want to save duplicate claim?")) {
            event.preventDefault();
            return false;
        }
        $("#allowdup").val("true");
    }
    //showConfirmMessage("Are you sure you want to finalize the claim?");
});

$("#btn-incomplete").click(function (event) {
    if (!confirm("Claim save is not complete?")) {
		event.preventDefault();
	}
	//showConfirmMessage("Are you sure you want to finalize the claim?");
});

$("#btn-ok").on('click',function(){
	$("form").submit();
});

function isDup() {
    let isDup =true;
    $.post({
        url: '../ajax/checkdup',
        data: $("#claim").serialize(),
        async:false,
        success: function (res) {
            if (res.success) {
                if (res.value == "0") {
                    isDup=false;
                } else {
                    // highlighting
                    $("#applicable-property").find('tr').each(function (index) {
                        $(this).removeClass("bg-danger");
                    });
                    $("#applicable-property").find('tr').eq(res.value).addClass("bg-danger");
                }
            }
        }
    }).fail(function (e) {
        alert("error: " + e.responseText);
    });
    return isDup;
}
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

function printLetter(claimid) {
    var pdf_link = "";
    $.get("../createnewclaim/print?claimId="+claimid, function (res) {
        if (res.success) {
            pdf_link = res.value;
            let docxlink = pdf_link.replace("pdf", "docx");
            let prelink = pdf_link.replace("download", "preview");
            var iframe = '<p><a target="_blank" href="' + docxlink + '" class="btn btn-success">Download .docx</a>' +
                '<a target="_blank" href="' + pdf_link + '" class="btn btn-success">Download .pdf</a>' +
                '</p><object data="' + prelink + '" type="application/pdf" width="100%" height="600px">' +
                '  cannot load pdf : <a href="' + pdf_link + '">download</a>' +
                '</object>';
            showPreView(iframe);
        } else {
            console.log(res)
        }
    })
}
// Flow Update FollowUp Date
function updateFollowUpDate(claimId,followUpDate) {
     return $.post("../createnewclaim/update_followup_date?"+$.param({ "claimId":claimId, "followUpDate":followUpDate }))
}

$("#closeFollowUpdateDateBtn").on('click',function(){
    // back to edit
    let claimId = getUrlParameter("id");
    window.location.href = "../admin/claimedit?id=" + claimId
});

$("#updateFollowUpdateDateBtn").on("click", function(){
    // send ajax update followup date for incomplete claim
    let claimId = getUrlParameter("claimId")
    let followUpDate = $("#followUpDateInput").val();
    if (followUpDate){
        console.log(followUpDate)
        updateFollowUpDate(claimId,followUpDate)
            .then(resp=>{
                // handle error
                console.log(resp)
                printLetter(claimId)
            })
            .catch(err=>{
                console.log(err)
            })
    }
})

var printClaimMessage ={
    2:"Do you want to printout an Incomplete Letter?",
    3:"You you want to printout an Duplicate Letter?",
    4:"Do you want to printout an Acknowledge Letter?"
};
var updateFollowUpDateMsg ={
    2: "Msg 301: Claim submitted is incomplete. Follow up of 30 day(s) is assigned by default. If you wish to modify the follow-up date, please"
        + "do so before continuing."
        + "Click Yes to continue or click No to go back and modify the claim.",
    3: "Msg 332: Records indicate that one or more of the property details are Duplicates(s) of existing claim."
        + "Follow-up of 30 day(s) is assigned by default. If you wish to modify the follow-up date, please do so before continueing."
        + "Click Yes to continue or click No to go back and modify the claim."
};
function onNewClaimSuccess(){
    let success = getUrlParameter("success");
    let claimId = getUrlParameter("id");
    let claimStatus = getUrlParameter("claimStatus");

    if (success&&claimId){
        if(!printClaimMessage[claimStatus]){
            console.log("ERROR: print message not found for claim status" + claimStatus);
            return
        }
        if(!confirm(printClaimMessage[claimStatus])){
            return
        }
        if ( claimStatus == 2){ // incomplete
            // show popup update followup date
            $('#updateFollowUpDateMsg').text(updateFollowUpDateMsg[2]);
            $('#updateFollowUpdateDateModal').modal();
            $('#followUpDateInput').val(getUrlParameter("followUpDate"))
        }else if(claimStatus == 3){
            // show popup update followup date
            $('#updateFollowUpDateMsg').text(updateFollowUpDateMsg[3]);
            $('#updateFollowUpdateDateModal').modal();
            $('#followUpDateInput').val(getUrlParameter("followUpDate"))
        }else{
            printLetter(claimId)
        }
    }
}

onNewClaimSuccess();
