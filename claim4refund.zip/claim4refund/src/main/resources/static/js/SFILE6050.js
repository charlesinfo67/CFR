$(document).ready(function () {
    var table = $('#dataTables-claim').DataTable({
        responsive: true,
        "dom": 'lrtip',
        "order": [[4, "desc"]]
    });


    $("#btnClear").on("click", function () {
        $("#cobrefno").val("");
        table
            .clear()
            .draw();
    });
});