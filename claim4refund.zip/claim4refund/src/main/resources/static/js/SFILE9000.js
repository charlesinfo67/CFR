$(document).ready(function () {
    var table = $('#dataTables-claim').DataTable({
        responsive: true,
        "dom": 'lrtip',
        "order": [[4, "desc"]]
    });


    $("#btnClear").on("click", function () {
        $("#cobrefno").val("");
        table
            .clear()
            .draw();
    });

    $("#btn-statuschange").click(function (event) {
        var selectedID = $('input[name=selectedClaim]:checked').val();
        if (selectedID === undefined) {
            showAlertMessage("Select a claim to change the status!");
            event.preventDefault();
            return false;
        }
        $("#claimid").val(selectedID);
        if (!confirm("Are you sure to change the status?")) {
            event.preventDefault();
        }
    });
});

$("#btn-ok").on('click', function () {
    $("form").submit();
});

