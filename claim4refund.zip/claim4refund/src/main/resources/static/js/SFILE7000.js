$(document).ready(function () {
    initDataTable();
});

$("#btnEdit").on("click", function () {
    var selectedID = $('input[name=selectedClaim]:checked').val();
    if (selectedID === undefined) {
        showAlertMessage("Select a Claim to edit");
        return;
    }
    location.href = "../admin/claimedit?id=" + selectedID;
});

$("#btnTTCReview").on("click", function () {
    var selectedID = $('input[name=selectedClaim]:checked').val();
    if (selectedID === undefined) {
        showAlertMessage("Select a Claim to review");
        return;
    }
    location.href = "../admin/ttcreview?id=" + selectedID;
});

$("#btnAssessorReview").on("click", function () {
    var selectedID = $('input[name=selectedClaim]:checked').val();
    if (selectedID === undefined) {
        showAlertMessage("Select a Claim to review");
        return;
    }
    location.href = "../admin/assessorreview?id=" + selectedID;
});

$('#dataTables-claim tbody').on('dblclick', 'tr', function () {
    let selectedID = $(this).find('input:radio').val();
    if (selectedID === undefined) {
        return false;
    }
    location.href = "../admin/claimview?id=" + selectedID;
});

function initDataTable() {
    $("#btnClear").attr("disabled", true);
    $("#btnSearch").attr("disabled", true);

    if ($.fn.dataTable.isDataTable('#dataTables-claim')) {
        let table = $('#dataTables-claim').DataTable();
        table.destroy();
    }

    var table = $('#dataTables-claim').DataTable({
        responsive: true,
        "serverSide": true,
        "deferLoading": 0,
        "ajax": {
            "url": "../admin/searchclaim/search",
            "type": "POST"
        },
        "columns": [
            {
                "data": "claimId",
                "render": function (data, type, full, meta) {
                    return '<input type="radio" name="selectedClaim" value="' + data + '">';
                }
            },
            {
                "data": "cobrefno",
                "render": function (data, type, full, meta) {
                    return '<a href="/admin/claimview?cobrefno=' + data + '">' + data + '</a>';
                }
            },
            {"data": "claimRefundType"},
            {"data": "claimStatus"},
            {"data": "receivedDate"},
            {"data": "claimantName"},
            {"data": "agentName"},
            {"data": "apn"},
            {"data": "taxYear"},
            {"data": "assessmentNo"}
        ],
        "dom": 'lrtip',
        "order": [[4, "desc"]],
        buttons: [
            {
                extend: 'excelHtml5',
                text: 'Export to Excel',
                exportOptions: {
                    modifier: {
                        page: 'current'
                    }
                }
            }
        ],
        "initComplete": function () {
            $('#dataTables-claim').DataTable().buttons().container().appendTo($("#btnExcel"));
            $("#btnSearch").attr("disabled", false);
            $("#btnClear").attr("disabled", false);
        }

    });

    $("#btnSearch").on("click", function () {

        table.columns().search("");

        if (table.column(1).search() !== $("#cobrefno").val()) {
            table
                .column(1)
                .search($("#cobrefno").val());
        }

        if ($("#claimRefundTypeId").val() != ""
            && table.column(2).search() != $("#claimRefundTypeId").val()) {
            table
                .column(2)
                .search($("#claimRefundTypeId").val());
        }
        // var statusSearch = [];
        // $.each($("#status option:selected"), function () {
        //     if ($("#status option:selected").val() != "") {
        //         statusSearch.push($(this).text());
        //     }
        // });

        if ($("#status").val() != ""
            && table.column(3).search() != $("#status").val()) {
            table
                .column(3)
                .search($("#status").val());
        }

        let recievedDate = $("#date_s").val() + ',' + $("#date_e").val();
        if (recievedDate != ","
            && table.column(4).search() != recievedDate) {
            table
                .column(4)
                .search(recievedDate);
        }

        let claimantName = $("#firstName").val() + ',' + $("#lastName").val();
        if (claimantName != ",") {
            table
                .column(5)
                .search(claimantName);
        }

        if (table.column(6).search() !== $("#agentName").val()) {
            table
                .column(6)
                .search($("#agentName").val());
        }

        if (table.column(7).search() !== $("#apn").val()) {
            table
                .column(7)
                .search($("#apn").val());
        }

        if (table.column(8).search() !== $("#taxyear").val()) {
            table
                .column(8)
                .search($("#taxyear").val());
        }

        if (table.column(9).search() !== $("#assessmentNo").val()) {
            table
                .column(9)
                .search($("#assessmentNo").val());
        }

        table.ajax.url("../admin/searchclaim/search").load();
    });
}

$("#btnClear").on("click", function () {
    $("#cobrefno").val("");
    $("#claimRefundTypeId").val("");
    $("#date_s").val("");
    $("#date_e").val("");
    $("#status").val("");
    $("#companyName").val("");
    $("#agentName").val("");
    $("#firstName").val("");
    $("#lastName").val("");
    $("#apn").val("");
    $("#taxyear").val("");
    $("#assessmentNo").val("");

    let table = $('#dataTables-claim').DataTable();
    table.clear();
    initDataTable();
    //$("#dataTables-claim tbody").empty();
});

function searchWithParams() {
    var status = GetURLParameter('status');
    var days = GetURLParameter('days');

    if (status == 'open') {
        status = ["1", "2", "3"];
    }
    $("#status").val(status);

    $("#date_s").val(getDateBefore(days));

    $("#btnSearch").click();
}

function getDateBefore(days) {
    var now = new Date();
    now.setDate(now.getDate() - days);

    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    return now.getFullYear() + "-" + (month) + "-" + (day);
}