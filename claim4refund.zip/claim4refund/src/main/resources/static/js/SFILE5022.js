$("#realName").on("change", function () {
    var filename = this.value.substr(0, this.value.lastIndexOf('.')) || this.value;
    $('#templateName').val(filename+'.pdf');
});

$("#templateFile").on("change", function () {
    var filename = this.value.split('\\').pop();
    $('#fileName').val(filename);
});

$("#cost-input").on("change", function () {
    $(this).val(parseFloat($(this).val().replace(/,/g, ""))
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ","));

    $("#cost").val($("#cost-input").val().replace(/,/g, ""));
});

$( "form" ).submit(function( event ) {
    if($("#templateFile").val() == ''){
        showAlertMessage("Please upload the File Specifications. ");
        event.preventDefault();
    }
});