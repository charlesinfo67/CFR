$(document).ready(function () {


});


$("form").submit(function (event) {

});

$("#btn-assessor").click(function (event) {
    if (!confirm("Are you sure you want to send the claim to Assessor?")) {
        event.preventDefault();
    }
});

$("#btn-save").click(function (event) {
    if (!confirm("Are you sure you want to save the claim?")) {
        event.preventDefault();
    }
});

$("#btn-finalize").click(function (event) {
    if (!confirm("Are you sure you want to finalize the claim?")) {
        event.preventDefault();
    }
});
