$(document).ready(function() {
    if ($('select[name=appType]').val() == "I") {
        $("#individual").show();
        $("#firstName").prop('required', true);
        $("#lastName").prop('required', true);
        $("#company").hide();
        $("#companyName").prop('required', false);
        $("#agent").hide();
    } else if ($('select[name=appType]').val() == "C") {
        $("#individual").hide();
        $("#firstName").prop('required', false);
        $("#lastName").prop('required', false);
        $("#company").show();
        $("#companyName").prop('required', true);
        $("#agent").show();
    }
    if ($('input[name=claimRefundTypeId]').val() == 1) {
        $("#section-2").show();
        $("#section-3").hide();
    } else {
        $("#section-2").hide();
        $("#section-3").show();
    }

    $('select[name=appType]').on("change", function () {
        if ($(this).val() == "I") {
            $("#individual").show();
            $("#company").hide();
            $("#agent").hide();
        } else if ($(this).val() == "C") {
            $("#individual").hide();
            $("#company").show();
            $("#agent").show();
        }
    });

    $('input[name=claimRefundTypeId]').on("change", function () {
        if($(this).val() == 1) {
            $("#section-2").show();
            $("#section-3").hide();
        } else {
            $("#section-2").hide();
            $("#section-3").show();
        }
    });

});

$("#btn-preview").click(function () {
    var pdf_link = "";
    $.post("../createnewclaim/preview", $('form').serialize(), function (res) {
        if (res.success) {
            pdf_link = res.value;
            var iframe = '<object data="' + pdf_link + '" type="application/pdf" width="100%" height="600px">' +
                '  Cannot load PDF : <a href="' + pdf_link + '">Download</a>' +
                '</object>';
            showPreView(iframe);
            $("#error-panel").html('');
            $(".error-item").each(function () {
                $(this).removeClass("error-item");
            });
        } else {
            //showAlertMessage(res.message);
            $("#error-panel").html('<p class="error-message">' + res.message + '</p>');
            $("#error-panel").focus();
            var items = res.value.replace(/\[/g, "").replace(/\]/g, "").split(" ");
            $("form").each(function () {
                $(this).find(':input').each(function () {
                    if ($.inArray($(this).prop('id'), items) !== -1) {
                        $(this).addClass("error-item");
                    } else {
                        $(this).removeClass("error-item");
                    }
                })
            });
        }
    }).done(function (res) {
        // alert("second success" + res.success);
    }).fail(function (e) {
        showAlertMessage("error: " + e.responseText);
    });
});

$(document.body).on("keyup mouseup", "#applicable-property .amount", function() {
	var total = 0;
	$(".amount").each(function() {
		total += parseInt($(this).val());
	});
	$("#totalAmount").text(addCommas(total));
});


// format tel number
window.addFormat = function addFormat(f) {
    if (f.value == '') return;
    var r = /(\D+)/g,
        npa = '',
        nxx = '',
        last4 = '';
    f.value = f.value.replace(r, '');
    npa = f.value.substr(0, 3);
    nxx = f.value.substr(3, 3);
    last4 = f.value.substr(6, 4);
    f.value = '(' + npa + ') ' + nxx + '-' + last4;
};

function formatAPN(input) {
	$(input).val($(input).val().replace(/(\d{3})(\d{3})(\d{2})/, "$1-$2-$3."));
}
//event
function deleteProperty(button) {
    var row_index = $(button).parent().parent().index();
    $("#applicable-property").load('../createnewclaim/new?removeRow=' + row_index + ' #applicable-property', $('form').serialize());
}
function addProperty() {
    $("#applicable-property").load('../createnewclaim/new?addRow #applicable-property', $('form').serialize());
}
$("form").submit(function(event) {
    if (isDup()) {
        showAlertMessage("Claim is duplicated !");
        event.preventDefault();
        return false;
    }

	if(!confirm("Are you sure you want to finalize the claim?")) {
		event.preventDefault();
        return false;
	}
});

$("#btn-ok").on('click',function(){
	$("form").submit();
});

function isDup() {
    let isDup =true;
    $.post({
        url: '/createnewclaim/checkdup',
        data: $("#claim").serialize(),
        async: false
    }).done(function(res){
            if (res.success) {
                if (res.value == "0") {
                    isDup=false;
                }
            }
    }).fail(function (e) {
        alert("error: " + e.responseText);
    });
    return isDup;
}
