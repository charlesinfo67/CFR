$(document).ready(function () {
    var table = $('#dataTables-claim').DataTable({
        responsive: true,
        "dom": 'lrtip',
        "order": [[4, "desc"]]
    });

    $("#btn-search").on("click", function () {
        table.columns().search("");

        if (table.column(1).search() !== $("#cobrefno").val()) {
            table
                .column(1)
                .search($("#cobrefno").val());
        }

        table.draw();

    });


    $("#btnClear").on("click", function () {
        $("#cobrefno").val("");
        table.columns().search("").draw();
    });

    $("#btn-history").on("click", function () {
        var selectedID = $('input[name=selectedClaim]:checked').val();
        if (selectedID === undefined) {
            showAlertMessage("Select a Claim to view History");
            return;
        }
        location.href = "../dashboard/claimhistory?id=" + selectedID;
    });
});