$(document).ready(function () {
    var table = $('#dataTables-bank').DataTable({
        responsive: true,
        "dom": 'lrtip'//,
        // "order": [[ 3, "desc" ]]
    });
});