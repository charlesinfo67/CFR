$("#templateFile").on("change", function () {
    var filename = this.value.split('\\').pop();
    $('#fileName').val(filename);
});

$("#cost-input").on("change", function () {
    $(this).val(parseFloat($(this).val().replace(/,/g, ""))
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ","));

    $("#cost").val($("#cost-input").val().replace(/,/g, ""));
});

$(document).ready(function () {
    $("#cost-input").val($("#cost").val());
    $("#cost-input").val(parseFloat($("#cost-input").val().replace(/,/g, ""))
        .toFixed(2)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ","));
});

$( "form" ).submit(function( event ) {
    var filename = $("#realName").val().substr(0, $("#realName").val().lastIndexOf('.')) || $("#realName").val();
    $('#templateName').val(filename+'.pdf');
});