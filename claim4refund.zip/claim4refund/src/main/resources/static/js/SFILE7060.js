$(document).ready(function () {
    var table = $('#dataTables-claim').DataTable({
        responsive: true,
        "dom": 'lrtip',
    });

    //searchWithParams();
});

function listByStatus(status, m_s, m_e) {
    if ($.fn.dataTable.isDataTable('#dataTables-claim')) {
        let table = $('#dataTables-claim').DataTable();
        table.destroy();
    }

    initDataTable(status, m_s, m_e);
}

function initDataTable(status, m_s, m_e) {
    m_s = typeof m_s !== 'undefined' ? m_s : 0;
    m_e = typeof m_e !== 'undefined' ? m_e : 0;

    var table = $('#dataTables-claim').DataTable({
        responsive: true,
        "serverSide": true,
        "ajax": {
            "url": "../admin/metrics/search?status=" + status + "&month_s=" + m_s + "&month_e=" + m_e,
            "type": "POST"
        },
        "columns": [
            {
                "data": "claimId",
                "render": function (data, type, full, meta) {
                    return '<input type="radio" name="selectedClaim" value="' + data + '">';
                }
            },
            {
                "data": "cobrefno",
                "render": function (data, type, full, meta) {
                    return '<a href="/admin/claimview?cobrefno=' + data + '">' + data + '</a>';
                }
            },
            {"data": "claimRefundType"},
            {"data": "claimStatus"},
            {"data": "receivedDate"},
            {"data": "claimantName"},
            {"data": "agentName"},
            {"data": "apn"},
            {"data": "taxYear"},
            {"data": "assessmentNo"}
        ],
        "dom": 'lrtip',
        "order": [[4, "desc"]],
        buttons: [
            {
                extend: 'excelHtml5',
                text: 'Export to Excel',
                exportOptions: {
                    modifier: {
                        page: 'current'
                    }
                }
            }
        ],
        "initComplete": function () {
            table.buttons().container().appendTo($("#btnExcel"));
        }

    });

    $("#btnSearch").on("click", function () {
        table.columns().search("");

        if (status != ""
            && table.column(3).search() != status) {
            table
                .column(3)
                .search(status);
        }


        table.ajax.url("../admin/metrics/search").load();
    });

    $('#dataTables-claim tbody').on('dblclick', 'tr', function () {
        let selectedID = $(this).find('input:radio').val();
        if (selectedID === undefined) {
            return false;
        }
        location.href = "../admin/claimview?id=" + selectedID;
    });
}