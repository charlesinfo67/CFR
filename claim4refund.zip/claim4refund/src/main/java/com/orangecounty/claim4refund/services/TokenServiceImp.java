package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.TokenDao;
import com.orangecounty.claim4refund.entities.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class TokenServiceImp implements TokenService {
    @Autowired
    TokenDao tokenDao;

    @Override
    public List<Token> get() {
        return tokenDao.get();
    }

    @Override
    public Token findById(String id) {
        return tokenDao.findById(id);
    }

    @Override
    public Token findByValue(String value, int type) {
        return tokenDao.findByValue(value, type);
    }

    @Override
    public void create(Token token) {
        tokenDao.add(token);
    }

    @Override
    public void delete(String id) {
        tokenDao.delete(id);
    }

    @Override
    public Token update(Token token) {
        return tokenDao.update(token);
    }

    @Override
    public Token check(String token, int type) {

        return tokenDao.check(token, type);
    }
}