package com.orangecounty.claim4refund.schedule;

import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ScheduledTasks {
    @Autowired
    private Environment env;
    @Autowired
    private ClaimService claimService;

    private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

    @Scheduled(cron = "${com.claim4refund.schedule.cron.status_change}")
    @Async
    public void updateClaimStatusAutomatic() {
        try {
            log.info("Scheduled Tasks was started.");

            int updatedRecords = claimService.updateInvalid();

            log.info(String.format("%d claim(s) was change status to INVALID", updatedRecords));

            log.info("Scheduled Tasks was ended.");
        } catch (Exception e) {
            log.info("Scheduled Tasks was failed.");
            LogUtils.error(e);
        }
    }
}