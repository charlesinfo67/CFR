package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.Token;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.services.TokenService;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.LogUtils;
import com.orangecounty.claim4refund.utils.TokenGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.Date;

@Controller
@RequestMapping("/password_recover")
public class SFILE3000 {
    @Autowired
    public EmailService emailService;
    @Autowired
    private UserService userService;
    @Autowired
    private TokenService tokenService;

    @RequestMapping(method = RequestMethod.GET)
    public String index() {
        return "/SFILE3000";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String recover(@RequestParam(required = true) String idOrMail, final Model model) {
        Token token;
        UserAccount user;
        try {

            user = userService.findById(idOrMail);

            if(user == null)
                user = userService.findByEmail(idOrMail);

            if(user == null)
                throw new UserPrincipalNotFoundException("User ID or email not found.");

            String tokenString = TokenGenerator.generateToken();

            token = new Token();
            token.setDate(new Date());
            token.setToken(tokenString);
            token.setValue(user.getLoginId());
            token.setType(Constants.TOKEN_TYPE_RESET_PASS);

            tokenService.create(token);

            tokenString = user.getLoginId() + ":" + tokenString;

            String resetUrl = MvcUriComponentsBuilder.fromController(SFILE3010.class).queryParam("token", tokenString).build().toString();

            emailService.sendResetPassMail(resetUrl, user);

            model.addAttribute("message", "Check your email for a link to reset your password. If it doesn’t appear within a few minutes, check your spam folder.");
        } catch (UserPrincipalNotFoundException e){
            model.addAttribute("message", e.getName());
            LogUtils.error(e);
        } catch (Exception e) {
            model.addAttribute("message", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return "/SFILE3000";
    }
}
