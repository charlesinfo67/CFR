package com.orangecounty.claim4refund.storage;

import org.springframework.core.io.Resource;

import java.io.File;
import java.nio.file.Path;

public interface StorageService {

    void init();

    void storePDF(File file);

    Path loadPDF(String filename);

    Resource loadPDFAsResource(String filename);
    Resource loadAsResource(String filename);

    void deleteAllPDF();


}
