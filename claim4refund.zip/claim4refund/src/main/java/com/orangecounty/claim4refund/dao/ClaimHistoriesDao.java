package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ClaimHistories;

import java.util.List;

public interface ClaimHistoriesDao {

    void add(ClaimHistories claimHistories);

    List<ClaimHistories> findById(int claimId);

}