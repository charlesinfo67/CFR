package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.SecQuestion;
import com.orangecounty.claim4refund.entities.Token;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.services.SecQuestionService;
import com.orangecounty.claim4refund.services.TokenService;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.LogUtils;
import com.orangecounty.claim4refund.utils.TokenGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/security_question")
public class SFILE3020 {
    @Autowired
    private UserService userService;
    @Autowired
    private SecQuestionService secQuestionService;
    @Autowired
    private TokenService tokenService;

    @RequestMapping(method = RequestMethod.GET)
    public String recover(final Model model) {
        try {

            List<SecQuestion> secQuestions = secQuestionService.get();
            model.addAttribute("secQuestions", secQuestions);

        } catch (Exception e) {
            model.addAttribute("message", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }
        return "/SFILE3020";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String resendPass(@RequestParam(required = true) String loginId,
                             @RequestParam(required = true) String questionId,
                             @RequestParam(required = true) String answer, final Model model) {
        Token token;
        String url = "/SFILE3020";
        try {
            UserAccount user = userService.findById(loginId);
            if (user != null) {
                if (questionId.equals(user.getQuestionId())
                        && answer.equalsIgnoreCase(user.getSecurityAnswer())) {
                    String tokenString = TokenGenerator.generateToken();
                    token = new Token();
                    token.setDate(new Date());
                    token.setToken(tokenString);
                    token.setValue(loginId);
                    token.setType(Constants.TOKEN_TYPE_RESET_PASS);

                    tokenService.create(token);

                    url = "redirect:/reset_pass?token=" + loginId + ":" + tokenString;
                } else {
                    model.addAttribute("message", "Your security question or answer is wrong!");
                }
            } else {
                model.addAttribute("message", "Your ID not found!");
            }
        } catch (Exception e) {
            model.addAttribute("message", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }

        return url;
    }
}
