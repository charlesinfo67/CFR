package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.GroupedCount;
import com.orangecounty.claim4refund.utils.DateUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.*;
import java.text.ParseException;
import java.util.*;

import static com.orangecounty.claim4refund.Constants.STATUS_PENDING;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ClaimDaoImp implements ClaimDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(Claim claim) {
        Session session = sessionFactory.getCurrentSession();
        session.save(claim);
    }

    @Override
    public Claim update(Claim Claim) {
        Session session = sessionFactory.getCurrentSession();
        session.update(Claim);
        return Claim;
    }

    @Override
    public int updateInvalid() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaUpdate<Claim> criteriaUpdate = builder.createCriteriaUpdate(Claim.class);
        Root<Claim> root = criteriaUpdate.from(Claim.class);
        criteriaUpdate.set("claimStatusId", 8); // Invalid

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, -30); // past 30days

        List<Integer> statusIdList = new ArrayList<>();
        statusIdList.add(2); // Incomplete
        statusIdList.add(3); // Duplicate

        criteriaUpdate.where(builder.and(builder.lessThanOrEqualTo(root.get("updatedDate"), calendar.getTime()),
                root.get("claimStatusId").in(statusIdList)));

        return session.createQuery(criteriaUpdate).executeUpdate();
    }

    @Override
    public void delete(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        Claim Claim = findById(claimId);
        session.delete(Claim);
    }

    @Override
    public List<Claim> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from Claim", Claim.class).list();
    }

    @Override
    public Claim findById(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Claim.class, claimId);
    }

    @Override
    public Claim findByCobrefno(String cobrefno, Optional<String> userId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Claim> criteria = builder.createQuery(Claim.class);
        Root<Claim> root = criteria.from(Claim.class);

        Predicate predicate = builder.and(builder.equal(root.get("cobrefno"), cobrefno));
        if (userId.isPresent()) {
            predicate = builder.and(predicate, builder.equal(root.get("userId"), userId.get()));
        }
        criteria.select(root).where(predicate);

        Query<Claim> query = session.createQuery(criteria);
        List<Claim> claims = query.list();
        return claims.isEmpty() ? null : claims.get(0);
    }

    @Override
    public List<Claim> findByEmail(String email) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Claim> criteria = builder.createQuery(Claim.class);
        Root<Claim> root = criteria.from(Claim.class);

        criteria.select(root).where(builder.and(builder.equal(root.get("email"), email)));

        Query<Claim> query = session.createQuery(criteria);
        List<Claim> claims = query.list();
        return claims.isEmpty() ? new ArrayList<>() : claims;
    }

    @Override
    public List<Claim> findByUserId(String userId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Claim> criteria = builder.createQuery(Claim.class);
        Root<Claim> root = criteria.from(Claim.class);

        criteria.select(root).where(builder.and(builder.equal(root.get("userId"), userId)));

        Query<Claim> query = session.createQuery(criteria);
        List<Claim> claims = query.list();
        return claims.isEmpty() ? new ArrayList<>() : claims;
    }

    @Override
    public long countNewClaims() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<Claim> root = criteria.from(Claim.class);

        criteria.select(builder.count(root))
                .where(builder.and(builder.equal(root.get("status"), STATUS_PENDING)));
        return session.createQuery(criteria).getSingleResult();
    }

    @Override
    public long countClaims() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<Claim> root = criteria.from(Claim.class);

        criteria.select(builder.count(root));
        return session.createQuery(criteria).getSingleResult();
    }

    @Override
    public List<GroupedCount> countByStatus(Integer... ids) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<GroupedCount> criteria = builder.createQuery(GroupedCount.class);
        Root<Claim> root = criteria.from(Claim.class);
        criteria.groupBy(root.get("claimStatusId"));
        criteria.where(builder.and(root.get("claimStatusId").in(ids)));
        criteria
                .select(builder.construct(
                        GroupedCount.class,
                        root.get("claimStatusId"),
                        builder.count(root.get("claimStatusId"))
                ));

        return session.createQuery(criteria).getResultList();
    }

    @Override
    public List<GroupedCount> countPendingReview(int status, int month_s, int month_e) {
        Session session = sessionFactory.getCurrentSession();

        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<GroupedCount> criteria = builder.createQuery(GroupedCount.class);

        Root<Claim> root = criteria.from(Claim.class);
        criteria.groupBy(root.get("claimStatusId"));

        Predicate qr = builder.and(root.get("claimStatusId").in(status));

        if (month_s > 0) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.MONTH, (-1) * month_s);

            qr = builder.and(qr, builder.lessThanOrEqualTo(root.get("receivedDate"), calendar.getTime()));
        }
        if (month_e > 0) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.MONTH, (-1) * month_e);

            qr = builder.and(qr, builder.greaterThanOrEqualTo(root.get("receivedDate"), calendar.getTime()));
        }
        criteria.select(builder.construct(
                GroupedCount.class,
                root.get("claimStatusId"),
                builder.count(root.get("claimStatusId"))
        )).where(qr);

        return session.createQuery(criteria).getResultList();
    }

    @Override
    public String maxCOBREFNO(char prefix) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Claim> criteria = builder.createQuery(Claim.class);
        Root<Claim> root = criteria.from(Claim.class);

        criteria.where(builder.like(root.get("cobrefno"), "%" + prefix + "%"))
                .orderBy(builder.desc(root.get("cobrefno")));

        Query<Claim> query = session.createQuery(criteria);

        //query.setFirstResult(1);
        //query.setMaxResults(1);

        if (query.list().size() > 0)
            return query.list().get(0).getCobrefno();

        return null;
    }

    @Override
    public List<Claim> search(String cobrefno) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Claim> criteria = builder.createQuery(Claim.class);
        Root<Claim> root = criteria.from(Claim.class);

        Predicate qr = builder.and(
                builder.like(root.get("cobrefno"), "%" + cobrefno + "%"));

        criteria.select(root)
                .where(qr);

        Query<Claim> query = session.createQuery(criteria);
        return query.list();
    }

    @Override
    public List<Claim> search(int start, int length,
                              String cobrefno, Integer claimRefundTypeId, Integer[] status,
                              String receivedDate_s, String receivedDate_e,
                              String firstName, String lastName, String agentName) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Claim> criteria = builder.createQuery(Claim.class);
        Root<Claim> root = criteria.from(Claim.class);

        Predicate qr = builder.and(
                builder.like(root.get("cobrefno"), "%" + cobrefno + "%"),
                builder.like(root.get("firstName"), "%" + firstName + "%"),
                builder.like(root.get("lastName"), "%" + lastName + "%"),
                builder.like(root.get("agentName"), "%" + agentName + "%")
        );

        if (claimRefundTypeId != null) {
            qr = builder.and(qr, builder.equal(root.get("claimRefundTypeId"), claimRefundTypeId));
        }

        if (status != null && status.length > 0) {
            qr = builder.and(qr, root.get("claimStatusId").in(status));
        }

        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(DateUtils.toDate(receivedDate_s, "yyyy-MM-dd"));

            qr = builder.and(qr, builder.greaterThanOrEqualTo(root.get("receivedDate"), calendar.getTime()));
        } catch (ParseException ignored) {
        }

        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(DateUtils.toDate(receivedDate_e, "yyyy-MM-dd"));

            qr = builder.and(qr, builder.lessThanOrEqualTo(root.get("receivedDate"), calendar.getTime()));
        } catch (ParseException ignored) {
        }

        criteria.select(root)
                .where(qr);

        Query<Claim> query = session.createQuery(criteria)
                .setFirstResult(start)
                .setMaxResults(length);
        return query.list();
    }
}
