package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.SecQuestion;

import java.util.List;

public interface SecQuestionService {
    void create(SecQuestion question);

    List<SecQuestion> get();

    SecQuestion findById(String id);

    SecQuestion update(SecQuestion question);

    void delete(String id);
}