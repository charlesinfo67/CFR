package com.orangecounty.claim4refund.entities;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "ClaimRefundStatusMSTR")
public class ClaimRefundStatusMSTR {
    private int claimStatusId;
    private String description;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private boolean isActive;
    private Date inActiveDate;
    private String code;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ClaimStatusID", nullable = false)
    public int getClaimStatusId() {
        return claimStatusId;
    }

    public void setClaimStatusId(int claimStatusId) {
        this.claimStatusId = claimStatusId;
    }

    @Column(name = "Description", nullable = false, length = 50)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "CreatedBy", nullable = false, length = 50)
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "CreatedDate", nullable = false)
    public java.sql.Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(java.sql.Date createdDate) {
        this.createdDate = createdDate;
    }

    @Column(name = "UpdatedBy", nullable = true, length = 50)
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Column(name = "UpdatedDate", nullable = true)
    public java.sql.Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(java.sql.Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Column(name = "RV", nullable = false)
    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }

    @Column(name = "IsActive", nullable = false)
    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Column(name = "InActiveDate", nullable = true)
    public java.sql.Date getInActiveDate() {
        return inActiveDate;
    }

    public void setInActiveDate(java.sql.Date inActiveDate) {
        this.inActiveDate = inActiveDate;
    }

    @Column(name = "Code", nullable = false, length = 5)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
