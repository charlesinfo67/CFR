package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.ClaimLineStatusDao;
import com.orangecounty.claim4refund.entities.ClaimLineStatusMstr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@CacheConfig(cacheNames = {"status"})
@Transactional
public class ClaimLineStatusServiceImp implements ClaimLineStatusService {
    @Autowired
    ClaimLineStatusDao claimLineStatusDao;

    @Override
    @Cacheable
    public List<ClaimLineStatusMstr> get() {
        return claimLineStatusDao.get();
    }

    @Override
    public ClaimLineStatusMstr findById(String id) {
        return claimLineStatusDao.findById(id);
    }

    @Override
    public void create(ClaimLineStatusMstr entity) {
        claimLineStatusDao.add(entity);
    }

    @Override
    public void delete(String id) {
        claimLineStatusDao.delete(id);
    }

    @Override
    public ClaimLineStatusMstr update(ClaimLineStatusMstr entity) {
        return claimLineStatusDao.update(entity);
    }
}