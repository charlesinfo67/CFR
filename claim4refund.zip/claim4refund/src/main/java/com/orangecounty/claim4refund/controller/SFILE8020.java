package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.*;
import com.orangecounty.claim4refund.model.CFRJsonRespone;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.services.RemarkService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/claimhistory")
public class SFILE8020 {
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;
    @Autowired
    private RemarkService remarkService;
    @GetMapping
    public String index(@RequestParam Integer id, final Model model) {
        ClaimView claimView;

        Claim claim = claimService.findById(id);
        if (claim == null)
            return "/error/404";
        claimView = claimService.toView(claim);
        // claimHistories
        List<ClaimHistories> claimHistoriesByClaimId = claimService.findClaimHistoriesByClaimId(claim.getClaimId());
        List<PropertyHistories> propertyHistoriesByClaimId = propertiesService.findPropertyHistoriesByClaimId(claim.getClaimId());
        List<RemarkHistories> remarkHistoriesByClaimId = remarkService.findRemarkHistoriesByClaimId(claim.getClaimId());
        model.addAttribute("claim", claimView);
        model.addAttribute("claimHistories", claimHistoriesByClaimId);
        model.addAttribute("propertyHistories", propertyHistoriesByClaimId);
        model.addAttribute("remarkHistories", remarkHistoriesByClaimId);
        return "/SFILE8020";
    }
    @ResponseBody
    @PostMapping(path = "/add-remark")
    public CFRJsonRespone printLetter(
            @RequestParam(name = "claimId", required = true) int claimId,
            @RequestParam(name = "remark", required = true) String  remarkValue) {

        CFRJsonRespone cfrJsonRespone = new CFRJsonRespone();
        try {
            UserAccount userAccount = CommonUtils.getUserAccount();
            Claim claim = claimService.findById(claimId);

            Remark remark;
            remark = new Remark();
            remark.setRemarks(remarkValue);
            remark.setClaimId(claim.getClaimId());
            remark.setRv(DateUtils.now_sql());
            remark.setCreatedDate(DateUtils.now_sql());
            remark.setUpdatedDate(DateUtils.now_sql());
            remark.setCreatedBy(userAccount.getLoginId());
            remark.setUpdatedBy(userAccount.getLoginId());

            remarkService.create(remark);


            cfrJsonRespone.setSuccess(true);
        }catch (Exception e){
            cfrJsonRespone.setSuccess(false);
            cfrJsonRespone.setMessage(e.getMessage());
        }
        return cfrJsonRespone;
    }

}
