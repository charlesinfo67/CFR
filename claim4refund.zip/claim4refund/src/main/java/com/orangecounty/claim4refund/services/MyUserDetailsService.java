package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.UserDaoImp;
import com.orangecounty.claim4refund.model.UserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private UserDaoImp userDAO;

    @Override
    public UserDetails loadUserByUsername(final String loginId) throws UsernameNotFoundException {

        com.orangecounty.claim4refund.entities.UserAccount user = userDAO.loadUserByUsername(loginId);
        if (user == null) {
            throw new UsernameNotFoundException(loginId);
        }
        return new UserDetails(user);
    }

}
