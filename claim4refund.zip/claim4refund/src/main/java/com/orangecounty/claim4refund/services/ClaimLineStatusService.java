package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.ClaimLineStatusMstr;

import java.util.List;

public interface ClaimLineStatusService {
    void create(ClaimLineStatusMstr entity);

    List<ClaimLineStatusMstr> get();

    ClaimLineStatusMstr findById(String id);

    ClaimLineStatusMstr update(ClaimLineStatusMstr entity);

    void delete(String id);
}