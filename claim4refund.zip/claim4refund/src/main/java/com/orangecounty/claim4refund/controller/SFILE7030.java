package com.orangecounty.claim4refund.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.*;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.model.CFRJsonRespone;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.model.ManualReviewView;
import com.orangecounty.claim4refund.reports.ReportService;
import com.orangecounty.claim4refund.services.*;
import com.orangecounty.claim4refund.storage.StorageFileNotFoundException;
import com.orangecounty.claim4refund.storage.StorageService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.DateUtils;
import com.orangecounty.claim4refund.utils.FilenameUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.math.BigDecimal;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Transactional(rollbackFor = Exception.class)
@Controller
@RequestMapping("/admin/createnewclaim")
public class SFILE7030 {
    private final StorageService storageService;
    @Autowired
    private UserService userService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private StateService stateService;
    @Autowired
    private EmailService emailService;
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;
    @Autowired
    private RemarkService remarkService;
    @Autowired
    private ManualReviewService manualReviewService;
    @Autowired
    private ReportService reportService;

    @Autowired
    public SFILE7030(StorageService storageService) {
        this.storageService = storageService;
    }

    @ModelAttribute("countries")
    public List<Country> countries() {
        return countryService.get();
    }

    @ModelAttribute("states")
    public List<State> states() {
        return stateService.get();
    }

    @GetMapping(path = "/new")
    public String index(Model model) {
        ClaimView claim = new ClaimView();
        claim.addProperties(new ClaimProperties());
        model.addAttribute("claim", claim);
        return "/SFILE7030";
    }

    @ResponseBody
    @PostMapping(path = "/preview")
    public CFRJsonRespone preview(@ModelAttribute("claim") @Valid ClaimView claim,
                                  BindingResult result) {
        CFRJsonRespone cfrJsonRespone = new CFRJsonRespone();
        String fileName;
        String errorMsg = "";
        String errorItem = "";
        try {
            if (claim == null) {
                return cfrJsonRespone;
            }

            int index = 0;
            for (ClaimProperties prop : claim.getProperties()) {
                if (!StringUtils.isEmpty(prop.getApn()) && !StringUtils.isEmpty(prop.getAssessmentNo())) {
                    result.rejectValue(String.format("properties[%s].apn", index), null, String.format("Enter either APN or Assessment No. for row %s in property details.", index + 1));
                    result.rejectValue(String.format("properties[%s].assessmentNo", index), null, String.format("Enter either APN or Assessment No. for row %s in property details.", index + 1));
                }
                index++;
            }

            if (result.hasErrors()) {
                for (FieldError error : result.getFieldErrors()) {
                    errorMsg += error.getDefaultMessage() + "\n";
                    errorItem += error.getField() + " ";
                }
                cfrJsonRespone.setValue(errorItem);
                cfrJsonRespone.setMessage(errorMsg);
                cfrJsonRespone.setSuccess(false);
                return cfrJsonRespone;
            }

            List<ClaimProperties> properties = claim.getProperties();
            BigDecimal totalAmount = BigDecimal.ZERO;
            for (ClaimProperties prop : properties) {
                totalAmount = totalAmount.add(prop.getClaimAmount());
            }

            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> parameters = objectMapper.convertValue(claim, Map.class);
            parameters.put("partialRefund", claim.getRefundType().equals(Constants.REFUND_TYPE_PARTIAL));
            parameters.put("fullRefund", claim.getRefundType().equals(Constants.REFUND_TYPE_FULL));
            parameters.put("receivedDate", DateUtils.format(claim.getReceivedDate(), "MM-dd-yyyy"));
            parameters.put("logoImg", "reports/oc_logo.png");
            parameters.put("subReport", "reports/ClaimProperties.jasper");
            parameters.put("properties", new JRBeanCollectionDataSource(properties));
            parameters.put("totalClaimAmount", totalAmount);

            fileName = reportService.generatePDFReport("REPORT6020", parameters);
            cfrJsonRespone.setSuccess(true);
            cfrJsonRespone.setValue(MvcUriComponentsBuilder.fromMethodName(SFILE7030.class,
                    "serveFile", fileName).build().toString());

        } catch (Exception e) {
            cfrJsonRespone.setSuccess(false);
            LogUtils.error(e);
        }
        return cfrJsonRespone;
    }

    @PostMapping(path = "/new", params = "submit")
    public String registerClaim(@ModelAttribute("claim") @Valid ClaimView claim,
                                BindingResult result,
                                @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE7030";
        Claim newClaim;
        UserAccount user;
        ManualReview manualReview;
        boolean isDuplicated;

        try {
            if (claim.getProperties().stream()
                    .anyMatch(property -> !StringUtils.isEmpty(property.getApn())
                            && !StringUtils.isEmpty(property.getAssessmentNo())))
                result.rejectValue("properties", null, "Just either APN or AssessmentNo");
            // check duplicate

            isDuplicated = claim.getProperties()
                    .stream().anyMatch(prop -> {
                        Properties properties = new Properties();
                        BeanUtils.copyProperties(prop, properties);
                        return propertiesService.isDupplicated(properties);
                    });
            if (!allowdup && isDuplicated) {
                result.rejectValue("properties", null, "Properties has duplicate.");
            }

            if (!result.hasErrors()) {

                ClaimService.setClaimCobrefno(claim, claimService);
                // Create new user
                user = CommonUtils.getUserAccount();

                newClaim = newClaimFromClaim(claim, user, ClaimService.ClaimStatus.PENDING_TTC_REVIEW);

                isDuplicated = newProperties(claim, newClaim, user);

                if (isDuplicated) {
                    newClaim.setClaimStatusId(ClaimService.ClaimStatus.DUPLICATE.getValue());
                    claimService.update(newClaim);
                }

                newRemark(claim, newClaim, user);

                manualReview = new ManualReview();
                BeanUtils.copyProperties(claim.getManualReview(), manualReview);
                manualReview.setClaimId(newClaim.getClaimId());

                manualReviewService.create(manualReview);

                // Notify to Admins
                List<UserAccount> admins = userService.getByRole(Constants.USER_ROLE_ADMIN);
                for (UserAccount admin : admins) {
                    emailService.sendNotiMail("You have a new Claim need to approval.", admin);
                }
                url = new StringBuilder("redirect:/admin/createnewclaim/new?success=true")
                        .append("&claimStatus=").append(newClaim.getClaimStatusId())
                        .append("&claimId=").append(newClaim.getClaimId())
                        .append("&followUpDate=").append(URLEncoder
                                .encode(DateUtils.format(newClaim.getFollowUpDate(), "yyyy-MM-dd"), "UTF-8"))
                        .toString();

            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    private ClaimService.ClaimStatus calculateStatus(ClaimView claim) {
        ManualReviewView manualReview = claim.getManualReview();
        // If Any option in Section 5(Manual Review) checked
        if (BooleanUtils.isTrue(manualReview.getOption1())
                || BooleanUtils.isTrue(manualReview.getOption2())
                || BooleanUtils.isTrue(manualReview.getOption3())
                || BooleanUtils.isTrue(manualReview.getOption4())
                || BooleanUtils.isTrue(manualReview.getOption5())
                || BooleanUtils.isTrue(manualReview.getOption6())
                || BooleanUtils.isTrue(manualReview.getOption7())
                || BooleanUtils.isTrue(manualReview.getOption8())
                || BooleanUtils.isTrue(manualReview.getOption9())
                || BooleanUtils.isTrue(manualReview.getOption10())
                || BooleanUtils.isTrue(manualReview.getOption11())
        ) {
            // Override all required input data??
            return ClaimService.ClaimStatus.INCOMPLETE;
        }
        return ClaimService.ClaimStatus.PENDING_TTC_REVIEW;
    }

    private boolean newProperties(ClaimView claim, Claim newClaim, UserAccount finalUser) {
        boolean isDup = false;
        for (ClaimProperties claimProperties : claim.getProperties()) {
            if (StringUtils.isEmpty(claimProperties.getApn()) && StringUtils.isEmpty(claimProperties.getAssessmentNo()))
                continue;
            Properties properties = new Properties();
            BeanUtils.copyProperties(claimProperties, properties);
            properties.setClaimId(newClaim.getClaimId());
            if (propertiesService.isDupplicated(properties)) {
                properties.setClaimLineStatusId(ClaimPropertiesService.ClaimLineStatus.DUPLICATE.getCode());
                isDup = true;
            } else {
                properties.setClaimLineStatusId(ClaimPropertiesService.ClaimLineStatus.PENDING_REVIEW.getCode());
            }
            properties.setRv(DateUtils.now_sql());
            properties.setCreatedDate(DateUtils.now_sql());
            properties.setUpdatedDate(DateUtils.now_sql());
            properties.setCreatedBy(finalUser.getLoginId());
            properties.setUpdatedBy(finalUser.getLoginId());

            propertiesService.create(properties);
        }
        return isDup;
    }

    @ResponseBody
    @PostMapping(path = "/update_followup_date")
    public CFRJsonRespone updateFollowUpDate(@RequestParam(name = "claimId", required = true) int claimId,
                                             @RequestParam(name = "followUpDate", required = true) String followUpDate
    ) {
        CFRJsonRespone result = new CFRJsonRespone();
        result.setValue("0");
        try {
            // check duplicate
            Claim claim = claimService.findById(claimId);

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date followUpDateParsed = dateFormat.parse(followUpDate);
            claim.setFollowUpDate(new java.sql.Date(followUpDateParsed.getTime()));
            claimService.update(claim);
            result.setSuccess(true);
            result.setValue("1");

        } catch (Exception e) {
            result.setSuccess(false);
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;
    }

    @ResponseBody
    @GetMapping(path = "/print")
    public CFRJsonRespone printLetter(
            @RequestParam(name = "claimId", required = true) int claimId,
            @RequestParam(name = "type", required = true, defaultValue = "pdf") String type) {

        CFRJsonRespone cfrJsonRespone = new CFRJsonRespone();
        String fileName;
        try {
            fileName = buildReport(claimId, type);
            cfrJsonRespone.setSuccess(true);
            cfrJsonRespone.setValue(MvcUriComponentsBuilder.fromMethodName(SFILE7030.class,
                    "download", fileName).build().toString());

        } catch (Exception e) {
            cfrJsonRespone.setSuccess(false);
            LogUtils.error(e);
        }
        return cfrJsonRespone;
    }

    private String buildReport(int claimId, String type) {
        String outputFileName = DateUtils.toDayDateString("MMddyyyyhhmmss");
        switch (type) {
            case "docx":
                return buildDocxReport(claimId, outputFileName);

            default:
                buildDocxReport(claimId, outputFileName);
                return buildPDFReport(claimId, outputFileName);

        }
    }

    private String letterName(ClaimService.ClaimStatus status) {
        Map<ClaimService.ClaimStatus, String> mapStatusLetter = new HashMap<>();
        mapStatusLetter.put(ClaimService.ClaimStatus.PENDING_TTC_REVIEW, "AcknowledgeLetter");
        mapStatusLetter.put(ClaimService.ClaimStatus.DUPLICATE, "DuplicateLetter");
        mapStatusLetter.put(ClaimService.ClaimStatus.INCOMPLETE, "IncompleLetter");
        String letterName = mapStatusLetter.get(status);
        return letterName;
    }

    private String buildPDFReport(int claimId, String outputFileName) {
        Claim claim = claimService.findById(claimId);

        // TODO: refactor to report builder
        Map<String, Object> parameters = buildReportParams(claim);
        String letterName = letterName(ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId()));
        return reportService.generateReport(letterName, parameters, ReportService.Type.PDF, outputFileName);
    }

    private String buildDocxReport(int claimId, String outputFileName) {
        Claim claim = claimService.findById(claimId);

        // TODO: refactor to report builder
        Map<String, Object> parameters = buildReportParams(claim);
        String letterName = letterName(ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId()));
        return reportService.generateReport(letterName, parameters, ReportService.Type.DOCX, outputFileName);
    }

    private Map<String, Object> buildReportParams(Claim claim) {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> parameters = objectMapper.convertValue(claim, Map.class);
        // common fields
        parameters.put("receivedDate", DateUtils.format(claim.getReceivedDate(), "MM-dd-yyyy"));
        parameters.put("cobrefno", claim.getCobrefno());
        parameters.put("CompanyName", claim.getCompanyName());
        parameters.put("firstName", claim.getFirstName());
        parameters.put("lastName", claim.getLastName());
        parameters.put("address1", claim.getAddress1());
        parameters.put("city", claim.getCity());
        parameters.put("state", claim.getState());
        parameters.put("zipcode", claim.getZip());

        parameters.put("logoImg", "reports/oc_logo.png");

        //
        if (claim.getClaimStatusId() == ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue()) {//
            parameters.put("CreatedDate", DateUtils.format(claim.getCreatedDate(), "MM-dd-yyyy"));
            List<Properties> props = propertiesService.findByClaimId(claim.getClaimId());
            parameters.put("apn", props.stream().findFirst().orElse(new Properties()).getApn());

        } else if (claim.getClaimStatusId() == ClaimService.ClaimStatus.INCOMPLETE.getValue()) {
            Remark remark = remarkService.findByClaimId(claim.getClaimId());
            parameters.put("remarks", remark.getRemarksLetter());
            parameters.put("dueDate", "dueDate");
        } else if (claim.getClaimStatusId() == ClaimService.ClaimStatus.DUPLICATE.getValue()) {
            List<Properties> properties = propertiesService.findByClaimId(claim.getClaimId());
            parameters.put("CreatedDate", DateUtils.format(claim.getCreatedDate(), "MM-dd-yyyy"));

            parameters.put("subReport", "reports/DuplicateProperties.jasper");
            parameters.put("properties", new JRBeanCollectionDataSource(properties));
        }
        return parameters;
    }

    @PostMapping(path = "/new", params = "submitnovalidate")
    public String incompleteClaim(@ModelAttribute("claim") ClaimView claim) {
        String url = "/SFILE7030";
        Claim newClaim;
        UserAccount user;
        ManualReview manualReview;

        try {

            if (claim.getClaimRefundTypeId() == Constants.CLAIM_REFUND_TYPE_1)  // Overpayment Of Taxes paid(T)
                claim.setCobrefno(claimService.maxCOBREFNO(Constants.COBREFNO_PREFIX_T));
            else                                                                // Penalties For Late payment(P)
                claim.setCobrefno(claimService.maxCOBREFNO(Constants.COBREFNO_PREFIX_P));

            // Create new user
            user = CommonUtils.getUserAccount();
            // create new claim
            newClaim = newClaimFromClaim(claim, user, ClaimService.ClaimStatus.INCOMPLETE);

            newProperties(claim, newClaim, user);

            newRemark(claim, newClaim, user);

            manualReview = new ManualReview();
            BeanUtils.copyProperties(claim.getManualReview(), manualReview);
            manualReview.setClaimId(newClaim.getClaimId());

            manualReviewService.create(manualReview);

            // Notify to Admins
            List<UserAccount> admins = userService.getByRole(Constants.USER_ROLE_ADMIN);
            for (UserAccount admin : admins) {
                emailService.sendNotiMail("You have a new Claim need to approval.", admin);
            }
            url = new StringBuilder("redirect:/admin/createnewclaim/new?success=true")
                    .append("&claimStatus=").append(newClaim.getClaimStatusId())
                    .append("&claimId=").append(newClaim.getClaimId())
                    .append("&followUpDate=").append(URLEncoder
                            .encode(DateUtils.format(newClaim.getFollowUpDate(), "yyyy-MM-dd"), "UTF-8"))
                    .toString();
        } catch (Exception e) {
            LogUtils.error(e);
        }

        return url;
    }

    private Claim newClaimFromClaim(@ModelAttribute("claim") ClaimView claim,
                                    UserAccount user,
                                    ClaimService.ClaimStatus status) {
        Claim newClaim;
        newClaim = new Claim();
        BeanUtils.copyProperties(claim, newClaim);

        newClaim.setUserId(user.getLoginId());

        newClaim.setCompany(claim.getAppType().equals(Constants.CLAIM_APP_TYPE_C));

        newClaim.setClaimStatusId(status.getValue());

        newClaim.setPartialRefund(claim.getRefundType().equals(Constants.REFUND_TYPE_PARTIAL));
        newClaim.setFullRefund(claim.getRefundType().equals(Constants.REFUND_TYPE_FULL));

        newClaim.setRv(DateUtils.now_sql());
        newClaim.setCreatedDate(DateUtils.now_sql());
        newClaim.setUpdatedDate(DateUtils.now_sql());
        newClaim.setCreatedBy(user.getLoginId());
        newClaim.setUpdatedBy(user.getLoginId());

        claimService.create(newClaim);
        return newClaim;
    }

    private void newRemark(@Valid @ModelAttribute("claim") ClaimView claim, Claim newClaim, UserAccount finalUser) {
        // check for null/empty remark
        if (StringUtils.isNotEmpty(claim.getRemark().getRemarks())
                || StringUtils.isNotEmpty(claim.getRemark().getRemarksLetter())) {


            Remark remark;
            remark = new Remark();
            BeanUtils.copyProperties(claim.getRemark(), remark);
            remark.setClaimId(newClaim.getClaimId());
            remark.setRv(DateUtils.now_sql());
            remark.setCreatedDate(DateUtils.now_sql());
            remark.setUpdatedDate(DateUtils.now_sql());
            remark.setCreatedBy(finalUser.getLoginId());
            remark.setUpdatedBy(finalUser.getLoginId());

            remarkService.create(remark);
        }
    }

    @RequestMapping(path = "/new", params = {"success"})
    public String completed(Model model) {
        ClaimView claim = new ClaimView();
        claim.addProperties(new ClaimProperties());
        claim.setManualReview(new ManualReviewView());
        model.addAttribute("claim", claim);
        return "/SFILE7030";
    }

    @RequestMapping(path = "/new", params = {"addRow"})
    public String addRow(@ModelAttribute("claim") @Valid ClaimView claim,
                         BindingResult result) {
        claim.addProperties(new ClaimProperties());
        return "/SFILE7030";
    }

    @RequestMapping(path = "/new", params = {"removeRow"})
    public String removeRow(@ModelAttribute("claim") @Valid ClaimView claim,
                            BindingResult result, final HttpServletRequest req) {
        final Integer index = Integer.valueOf(req.getParameter("removeRow"));
        claim.removeProperties(index);
        return "/SFILE7030";
    }

    @GetMapping("/preview/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> preview(@PathVariable String filename) {
        String fileExtension = FilenameUtils.getFileExtension(filename);
        Resource file;

        switch (fileExtension) {
            case ".pdf":
                file = storageService.loadPDFAsResource(filename);
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + file.getFilename() + "\"").body(file);
            case ".docx":
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + file.getFilename() + "\"").body(file);
            default:
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf(URLConnection.guessContentTypeFromName(filename)))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + file.getFilename() + "\"").body(file);
        }
    }

    @GetMapping("/download/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> download(@PathVariable String filename) {
        String fileExtension = FilenameUtils.getFileExtension(filename);
        Resource file;

        switch (fileExtension) {
            case ".pdf":
                file = storageService.loadPDFAsResource(filename);
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + file.getFilename() + "\"").body(file);
            case ".docx":
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
            default:
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf(URLConnection.guessContentTypeFromName(filename)))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
        }
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
        LogUtils.error(exc);
        return ResponseEntity.notFound().build();
    }
}