package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.PropertyHistories;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ClaimPropertyHistoriesDaoImp implements ClaimPropertyHistoriesDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(PropertyHistories propHistory) {
        Session session = sessionFactory.getCurrentSession();
        session.save(propHistory);
    }

    @Override
    public List<PropertyHistories> findByPropertyId(int propertyId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<PropertyHistories> criteria = builder.createQuery(PropertyHistories.class);
        Root<PropertyHistories> root = criteria.from(PropertyHistories.class);
        criteria.where(builder.and(builder.equal(root.get("propertyId"), propertyId)));

        return session.createQuery(criteria).list();
    }

    @Override
    public List<PropertyHistories> findByClaimId(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<PropertyHistories> criteria = builder.createQuery(PropertyHistories.class);
        Root<PropertyHistories> root = criteria.from(PropertyHistories.class);
        criteria.where(builder.and(builder.equal(root.get("claimId"), claimId)));

        return session.createQuery(criteria).list();
    }
}
