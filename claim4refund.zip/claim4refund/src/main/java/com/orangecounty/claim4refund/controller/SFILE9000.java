package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimRefundStatusService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/admin/change_status")
public class SFILE9000 {
    @Autowired
    private ClaimService claimService;

    @Autowired
    private ClaimPropertiesService propertiesService;

    @Autowired
    private ClaimRefundStatusService statusService;

    @ModelAttribute("status")
    public List<ClaimRefundStatusMSTR> claimRefundStatusMstrs() {
        return statusService.get();
    }

    @GetMapping
    public String index() {
        return "/SFILE9000";
    }

    @PostMapping(params = "search")
    public String search(Model model, @RequestParam(value = "cobrefno", required = true) String cobrefno) {
        List<ClaimProperties> properties = new ArrayList<>();
        ClaimProperties propertyView;
        List<ClaimView> claims = new ArrayList<>();
        ClaimView claimView;

        for (Claim claim : claimService.search(cobrefno)) {
            claimView = new ClaimView();
            BeanUtils.copyProperties(claim, claimView);
            for (Properties property : propertiesService.findByClaimId(claim.getClaimId())) {
                propertyView = new ClaimProperties();
                BeanUtils.copyProperties(property, propertyView);
                properties.add(propertyView);
                break;
            }
            if (properties.isEmpty()) {
                properties.add(new ClaimProperties());
            }
            claimView.setProperties(properties);
            claims.add(claimView);
        }
        model.addAttribute("claims", claims);
        model.addAttribute("cobrefno", cobrefno);

        return "/SFILE9000";
    }

    @PostMapping(params = "statuschange")
    public String statuschange(Model model,
                               @RequestParam(value = "cobrefno", required = true) String cobrefno,
                               @RequestParam(value = "claimid", required = true) int id,
                               @RequestParam(value = "status", required = true) int status) {
        String url = "/SFILE9000";
        Claim updateClaim;

        try {

            updateClaim = claimService.findById(id);

            updateClaim.setClaimStatusId(status);

            claimService.update(updateClaim);

            model.addAttribute("updated", true);

            search(model, cobrefno);

        } catch (Exception e) {
            model.addAttribute("error", true);
            LogUtils.error(e);
        }

        return url;
    }

}