package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Remark;

import java.util.List;

public interface RemarkDao {
    void add(Remark entity);

    List<Remark> get();

    Remark findById(String id);

    Remark findByClaimId(int claimId);

    Remark update(Remark entity);

    void delete(String id);
}