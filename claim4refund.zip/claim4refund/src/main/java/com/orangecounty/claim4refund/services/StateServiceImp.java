 package com.orangecounty.claim4refund.services;

 import com.orangecounty.claim4refund.dao.StateDao;
 import com.orangecounty.claim4refund.entities.State;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.cache.annotation.CacheConfig;
 import org.springframework.cache.annotation.Cacheable;
 import org.springframework.stereotype.Service;
 import org.springframework.transaction.annotation.Transactional;

 import java.util.List;

@Service
@CacheConfig(cacheNames = {"states"})
@Transactional
public class StateServiceImp implements StateService {
    @Autowired
    StateDao stateDao;

    @Override
    @Cacheable
    public List<State> get() {
        return stateDao.get();
    }

    @Override
    public State findById(String id) {
        return stateDao.findById(id);
    }

    @Override
    public void create(State state) {
        stateDao.add(state);
    }

    @Override
    public void delete(String id) {
        stateDao.delete(id);
    }

    @Override
    public State update(State state) {
        return stateDao.update(state);
    }
}