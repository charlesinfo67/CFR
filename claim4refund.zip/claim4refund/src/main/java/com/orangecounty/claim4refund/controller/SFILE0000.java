package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.utils.CommonUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
public class SFILE0000 {

    @GetMapping({"/", "/home"})
    public String home() {
        if (CommonUtils.isLogged()) {
            return "redirect:/dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/about")
    public String about() {
        return "/about";
    }

    @GetMapping("/403")
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public String error403() {
        return "/error/403";
    }

    @GetMapping("/401")
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public String error401() {
        return "/error/401";
    }

    @GetMapping("/404")
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String error404() {
        return "/error/404";
    }

    @GetMapping("/err")
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String noHandlerFoundException() {
        return "/error/error";
    }

}