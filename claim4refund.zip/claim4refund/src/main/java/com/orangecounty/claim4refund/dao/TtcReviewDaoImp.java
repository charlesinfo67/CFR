package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.TtcReview;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class TtcReviewDaoImp implements TtcReviewDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(TtcReview question) {
        Session session = sessionFactory.getCurrentSession();
        session.save(question);
    }

    @Override
    public List<TtcReview> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from TtcReviewEntity", TtcReview.class).list();
    }

    @Override
    public TtcReview findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(TtcReview.class, id);
    }

    @Override
    public TtcReview update(TtcReview question) {
        Session session = sessionFactory.getCurrentSession();
        session.update(question);
        return question;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        TtcReview question = findById(id);
        session.delete(question);
    }
}
