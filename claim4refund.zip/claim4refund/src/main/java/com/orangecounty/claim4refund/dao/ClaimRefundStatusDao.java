package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;

import java.util.List;

public interface ClaimRefundStatusDao {
    void add(ClaimRefundStatusMSTR entity);

    List<ClaimRefundStatusMSTR> get();

    ClaimRefundStatusMSTR findById(String id);

    ClaimRefundStatusMSTR update(ClaimRefundStatusMSTR entity);

    void delete(String id);
}