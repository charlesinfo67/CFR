package com.orangecounty.claim4refund.handler;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class MyAuthenticationFailureHandler implements AuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException exception) throws IOException {
        if (exception instanceof BadCredentialsException) {
            response.sendRedirect(request.getContextPath() + "/login?error=1");
        } else if (exception instanceof UsernameNotFoundException) {
            response.sendRedirect(request.getContextPath() + "/login?username=" + exception.getMessage() + "&&error=2");
        } else if (exception instanceof DisabledException) {
            response.sendRedirect(request.getContextPath() + "/401");
        } else {
            response.sendRedirect(request.getContextPath() + "/err");
        }

    }
}