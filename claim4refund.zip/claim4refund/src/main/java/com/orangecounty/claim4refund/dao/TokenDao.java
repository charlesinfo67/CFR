package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Token;

import java.util.List;

public interface TokenDao {
    void add(Token token);

    List<Token> get();

    Token findById(String id);

    Token findByValue(String value, int type);

    Token update(Token token);

    void delete(String id);

    Token check(String token, int type);
}