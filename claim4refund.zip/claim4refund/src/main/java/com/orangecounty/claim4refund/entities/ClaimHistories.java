package com.orangecounty.claim4refund.entities;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "ClaimHistories")
public class ClaimHistories implements java.io.Serializable {

    private static final long serialVersionUID = 1L;
    private int Id;
    private int Status;
    private int claimId;
    private String userId;
    private String cobrefno;
    private String firstName;
    private String middleName;
    private String lastName;
    private String agentName;
    private String primaryPhone;
    private String alternatePhone1;
    private String email;
    private int claimRefundTypeId;
    private int claimStatusId;
    private Date receivedDate;
    private Date followUpDate;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private int claimLetterType;
    private Integer conversionKey;
    private boolean isCompany;
    private String companyName;
    private boolean isPrimaryPhoneUsa;
    private boolean isAlternatePhone1Usa;
    private String primaryPhoneExt;
    private String alternatePhone1Ext;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String city;
    private String country;
    private String zip;
    private String zipExtension;
    private String state;
    private String executed;
    private String by;
    private Boolean hasDisagree;
    private Boolean hasOverpaid;
    private Boolean partialRefund;
    private Boolean fullRefund;
    private String refundReasons;
    private Boolean backupDoc;
    private String internalRemarks;
    private String appType;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false)
    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    @Column(name = "Status", nullable = false)
    public int getStatus() {
        return Status;
    }

    public void setStatus(int status) {
        Status = status;
    }

    @Column(name = "ClaimID", nullable = false)
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    @Column(name = "UserId", nullable = false)
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Column(name = "COBREFNO", nullable = false, length = 15)
    public String getCobrefno() {
        return cobrefno;
    }

    public void setCobrefno(String cobrefno) {
        this.cobrefno = cobrefno;
    }

    @Column(name = "FirstName", nullable = true, length = 50)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name = "MiddleName", nullable = true, length = 20)
    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @Column(name = "LastName", nullable = true, length = 50)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column(name = "AgentName", nullable = true, length = 100)
    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    @Column(name = "PrimaryPhone", nullable = true, length = 20)
    public String getPrimaryPhone() {
        return primaryPhone;
    }

    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    @Column(name = "AlternatePhone1", nullable = true, length = 20)
    public String getAlternatePhone1() {
        return alternatePhone1;
    }

    public void setAlternatePhone1(String alternatePhone1) {
        this.alternatePhone1 = alternatePhone1;
    }

    @Column(name = "Email", nullable = true, length = 100)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Column(name = "ClaimRefundTypeID", nullable = false)
    public int getClaimRefundTypeId() {
        return claimRefundTypeId;
    }

    public void setClaimRefundTypeId(int claimRefundTypeId) {
        this.claimRefundTypeId = claimRefundTypeId;
    }

    @Column(name = "ClaimStatusID", nullable = false)
    public int getClaimStatusId() {
        return claimStatusId;
    }

    public void setClaimStatusId(int claimStatusId) {
        this.claimStatusId = claimStatusId;
    }

    @Column(name = "ReceivedDate", nullable = true)
    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    @Column(name = "FollowUpDate", nullable = true)
    public Date getFollowUpDate() {
        return followUpDate;
    }

    public void setFollowUpDate(Date followUpDate) {
        this.followUpDate = followUpDate;
    }

    @Column(name = "CreatedBy", nullable = false, length = 50)
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "CreatedDate", nullable = false)
    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    @Column(name = "UpdatedBy", nullable = true, length = 50)
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Column(name = "UpdatedDate", nullable = true)
    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Column(name = "RV", nullable = false)
    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }

    @Column(name = "ClaimLetterType", nullable = false)
    public int getClaimLetterType() {
        return claimLetterType;
    }

    public void setClaimLetterType(int claimLetterType) {
        this.claimLetterType = claimLetterType;
    }

    @Column(name = "Conversion_Key", nullable = true)
    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    @Column(name = "IsCompany", nullable = false)
    public boolean isCompany() {
        return isCompany;
    }

    public void setCompany(boolean company) {
        isCompany = company;
    }

    @Column(name = "CompanyName", nullable = true, length = 50)
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @Column(name = "IsPrimaryPhoneUSA", nullable = false)
    public boolean isPrimaryPhoneUsa() {
        return isPrimaryPhoneUsa;
    }

    public void setPrimaryPhoneUsa(boolean primaryPhoneUsa) {
        isPrimaryPhoneUsa = primaryPhoneUsa;
    }

    @Column(name = "IsAlternatePhone1USA", nullable = false)
    public boolean isAlternatePhone1Usa() {
        return isAlternatePhone1Usa;
    }

    public void setAlternatePhone1Usa(boolean alternatePhone1Usa) {
        isAlternatePhone1Usa = alternatePhone1Usa;
    }

    @Column(name = "PrimaryPhoneEXT", nullable = true, length = 10)
    public String getPrimaryPhoneExt() {
        return primaryPhoneExt;
    }

    public void setPrimaryPhoneExt(String primaryPhoneExt) {
        this.primaryPhoneExt = primaryPhoneExt;
    }

    @Column(name = "AlternatePhone1EXT", nullable = true, length = 10)
    public String getAlternatePhone1Ext() {
        return alternatePhone1Ext;
    }

    public void setAlternatePhone1Ext(String alternatePhone1Ext) {
        this.alternatePhone1Ext = alternatePhone1Ext;
    }

    @Column(name = "Address1", nullable = true, length = 100)
    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    @Column(name = "Address2", nullable = true, length = 50)
    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    @Column(name = "Address3", nullable = true, length = 50)
    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    @Column(name = "Address4", nullable = true, length = 50)
    public String getAddress4() {
        return address4;
    }

    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    @Column(name = "City", nullable = true, length = 70)
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Column(name = "Country", nullable = true, length = 70)
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Column(name = "Zip", nullable = true, length = 25)
    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    @Column(name = "ZipExtension", nullable = true, length = 10)
    public String getZipExtension() {
        return zipExtension;
    }

    public void setZipExtension(String zipExtension) {
        this.zipExtension = zipExtension;
    }

    @Column(name = "State", nullable = true, length = 70)
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Column(name = "Executed", nullable = false, length = 50)
    public String getExecuted() {
        return executed;
    }

    public void setExecuted(String executed) {
        this.executed = executed;
    }

    @Column(name = "[By]", nullable = true, length = 255)
    public String getBy() {
        return by;
    }

    public void setBy(String by) {
        this.by = by;
    }

    @Column(name = "HasDisagree", nullable = true)
    public Boolean getHasDisagree() {
        return hasDisagree;
    }

    public void setHasDisagree(Boolean hasDisagree) {
        this.hasDisagree = hasDisagree;
    }

    @Column(name = "HasOverpaid", nullable = true)
    public Boolean getHasOverpaid() {
        return hasOverpaid;
    }

    public void setHasOverpaid(Boolean hasOverpaid) {
        this.hasOverpaid = hasOverpaid;
    }

    @Column(name = "PartialRefund", nullable = true)
    public Boolean getPartialRefund() {
        return partialRefund;
    }

    public void setPartialRefund(Boolean partialRefund) {
        this.partialRefund = partialRefund;
    }

    @Column(name = "FullRefund", nullable = true)
    public Boolean getFullRefund() {
        return fullRefund;
    }

    public void setFullRefund(Boolean fullRefund) {
        this.fullRefund = fullRefund;
    }

    @Column(name = "RefundReasons", nullable = true, length = 150)
    public String getRefundReasons() {
        return refundReasons;
    }

    public void setRefundReasons(String refundReasons) {
        this.refundReasons = refundReasons;
    }

    @Column(name = "BackupDoc", nullable = true)
    public Boolean getBackupDoc() {
        return backupDoc;
    }

    public void setBackupDoc(Boolean backupDoc) {
        this.backupDoc = backupDoc;
    }

    @Column(name = "InternalRemarks", nullable = true, length = 300)
    public String getInternalRemarks() {
        return internalRemarks;
    }

    public void setInternalRemarks(String internalRemarks) {
        this.internalRemarks = internalRemarks;
    }

    @Column(name = "AppType", nullable = false, length = 1)
    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    @Override
    public String toString() {
        return "Claim{" +
                "claimId=" + claimId +
                ", userId='" + userId + '\'' +
                ", cobrefno='" + cobrefno + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", agentName='" + agentName + '\'' +
                ", primaryPhone='" + primaryPhone + '\'' +
                ", alternatePhone1='" + alternatePhone1 + '\'' +
                ", email='" + email + '\'' +
                ", claimRefundTypeId=" + claimRefundTypeId +
                ", claimStatusId=" + claimStatusId +
                ", receivedDate=" + receivedDate +
                ", followUpDate=" + followUpDate +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedDate=" + updatedDate +
                ", rv=" + rv +
                ", claimLetterType=" + claimLetterType +
                ", conversionKey=" + conversionKey +
                ", isCompany=" + isCompany +
                ", companyName='" + companyName + '\'' +
                ", isPrimaryPhoneUsa=" + isPrimaryPhoneUsa +
                ", isAlternatePhone1Usa=" + isAlternatePhone1Usa +
                ", primaryPhoneExt='" + primaryPhoneExt + '\'' +
                ", alternatePhone1Ext='" + alternatePhone1Ext + '\'' +
                ", address1='" + address1 + '\'' +
                ", address2='" + address2 + '\'' +
                ", address3='" + address3 + '\'' +
                ", address4='" + address4 + '\'' +
                ", city='" + city + '\'' +
                ", country='" + country + '\'' +
                ", zip='" + zip + '\'' +
                ", zipExtension='" + zipExtension + '\'' +
                ", state='" + state + '\'' +
                ", executed='" + executed + '\'' +
                ", by='" + by + '\'' +
                ", hasDisagree=" + hasDisagree +
                ", hasOverpaid=" + hasOverpaid +
                ", partialRefund=" + partialRefund +
                ", fullRefund=" + fullRefund +
                ", refundReasons='" + refundReasons + '\'' +
                ", backupDoc=" + backupDoc +
                ", internalRemarks='" + internalRemarks + '\'' +
                ", appType='" + appType + '\'' +
                '}';
    }
}
