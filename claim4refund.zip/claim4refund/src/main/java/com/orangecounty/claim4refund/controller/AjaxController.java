package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.model.CFRJsonRespone;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@Transactional
public class AjaxController {
    @Autowired
    private UserService userService;
    @Autowired
    public EmailService emailService;
    @Autowired
    private ClaimPropertiesService propertiesService;

    @ResponseBody
    @PostMapping(value = "/admin/ajax/user")
    public CFRJsonRespone deActiveUser(@RequestParam String id, @RequestParam boolean active) {
        CFRJsonRespone result = new CFRJsonRespone();
        try {
            UserAccount user = userService.findById(id);
            if (user != null) {
                if (active)
                    user.setStatus(Constants.STATUS_ACTIVE);
                else
                    user.setStatus(Constants.STATUS_INACTIVE);

                user = userService.update(user);
                emailService.sendNotiMail("Your account has been "+ (active?"actived.":"deactived."), user);

                result.setSuccess(true);
            } else {
                result.setMessage("User not found!");
            }

        } catch (Exception e) {
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }

    @ResponseBody
    @PostMapping(value = "/admin/ajax/role")
    public CFRJsonRespone changeRole(@RequestParam String id, @RequestParam boolean admin) {
        CFRJsonRespone result = new CFRJsonRespone();
        try {
            UserAccount user = userService.findById(id);
            if (user != null) {
                if (admin)
                    user.setRole(Constants.USER_ROLE_ADMIN);
                else
                    user.setRole(Constants.USER_ROLE_MEMBER);

                user = userService.update(user);
                emailService.sendNotiMail("Your account has been change to "+ (admin?"admin.":"user."), user);

                result.setSuccess(true);
            } else {
                result.setMessage("User not found!");
            }

        } catch (Exception e) {
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }

    @ResponseBody
    @PostMapping(value = "/admin/ajax/configuration")
    public CFRJsonRespone Obsoleted(@RequestParam String id, @RequestParam boolean active) {
        CFRJsonRespone result = new CFRJsonRespone();
        try {
            UserAccount user = userService.findById(id);
            if (user != null) {
                if (active) {
                    user.setRole(Constants.USER_ROLE_MEMBER);
                    user.setStatus(Constants.STATUS_ACTIVE);
                } else {
                    user.setRole(0);
                    user.setStatus(Constants.STATUS_PENDING);
                }
                userService.update(user);

                result.setSuccess(true);
            } else {
                result.setMessage("User not found!");
            }

        } catch (Exception e) {
            result.setSuccess(false);
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }


    @ResponseBody
    @PostMapping(path = "/admin/ajax/checkdup")
    public CFRJsonRespone checkDup(@ModelAttribute("claim") ClaimView claim) {
        CFRJsonRespone result = new CFRJsonRespone();
        result.setValue("0");
        boolean isDuplicated = false;
        try {
            // check duplicate
            int index = 1;
            for (ClaimProperties claimProperties : claim.getProperties()) {
                Properties properties = new Properties();
                BeanUtils.copyProperties(claimProperties, properties);
                if (propertiesService.isDupplicated(properties)) {
                    isDuplicated = true;
                    break;
                }
                index++;
            }
            if (isDuplicated) {
                result.setSuccess(true);
                result.setValue(String.valueOf(index));
            }else{
                result.setSuccess(true);
                result.setValue("0");
            }

        } catch (Exception e) {
            result.setSuccess(false);
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }
}