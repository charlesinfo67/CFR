package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Properties;

import java.util.List;

public interface ClaimPropertiesDao {

    void add(Properties properties);

    Properties update(Properties properties);

    void delete(int propertyId);

    List<Properties> get();

    Properties findById(int propertyId);

    List<Properties> findByClaimId(int claimId);

    boolean isDupplicated(Properties property);

    List<Properties> search(int claimId,
                            String apn,
                            Integer taxyear,
                            String assessmentNo);

}