package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.SecQuestion;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class SecQuestionDaoImp implements SecQuestionDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(SecQuestion question) {
        Session session = sessionFactory.getCurrentSession();
        session.save(question);
    }

    @Override
    public List<SecQuestion> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from SecQuestion", SecQuestion.class).list();
    }

    @Override
    public SecQuestion findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(SecQuestion.class, id);
    }

    @Override
    public SecQuestion update(SecQuestion question) {
        Session session = sessionFactory.getCurrentSession();
        session.update(question);
        return question;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        SecQuestion question = findById(id);
        session.delete(question);
    }
}
