package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.*;
import com.orangecounty.claim4refund.entities.*;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.model.ManualReviewView;
import com.orangecounty.claim4refund.model.RemarkView;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.orangecounty.claim4refund.Constants.COBREFNO_INIT_VALUE;

@Service
@CacheConfig(cacheNames = {"claims"})
@Transactional
public class ClaimServiceImp implements ClaimService {
    @Autowired
    ClaimDao claimDao;
    @Autowired
    ClaimPropertiesDao propertiesDao;
    @Autowired
    RemarkDao remarkDao;
    @Autowired
    ManualReviewDao manualReviewDao;
    @Autowired
    ClaimHistoriesDao claimHistoriesDao;

    @Override
    @Cacheable
    public List<Claim> get() {
        List<Claim> claims = claimDao.get();
        return claims;
    }

    @Override
    public Claim findById(int claimId) {
        Claim claim = claimDao.findById(claimId);
        return claim;
    }

    @Override
    public List<Claim> findByEmail(String email) {
        List<Claim> claims = claimDao.findByEmail(email);
        return claims;
    }

    @Override
    public List<Claim> findByUserId(String userId) {
        return claimDao.findByUserId(userId);
    }

    @Override
    public Claim findByCobrefno(String cobrefno, Optional<String> userId) {
        Claim claim = claimDao.findByCobrefno(cobrefno, userId);
        return claim;
    }

    @Override
    public long countNewClaims() {
        return claimDao.countNewClaims();
    }

    @Override
    public long countClaims() {
        return claimDao.countClaims();
    }

    @Override
    public List<GroupedCount> countByStatus(Integer... ids) {
        return claimDao.countByStatus(ids);
    }

    @Override
    public List<GroupedCount> countPendingReview(int status, int month_s, int month_e) {
        return claimDao.countPendingReview(status, month_s, month_e);
    }

    @Override
    @CachePut
    public void create(Claim claim) {
        claimDao.add(claim);
        ClaimHistories claimHistories = new ClaimHistories();
        BeanUtils.copyProperties(claim, claimHistories);
        claimHistories.setStatus(ClaimHistoriesStatus.CREATED.getValue());
        claimHistoriesDao.add(claimHistories);
    }

    @Override
    @CachePut
    public void delete(int claimId) {
        Claim claim = claimDao.findById(claimId);
        claimDao.delete(claimId);

        ClaimHistories claimHistories = new ClaimHistories();
        BeanUtils.copyProperties(claim, claimHistories);
        claimHistories.setStatus(ClaimHistoriesStatus.DELETED.getValue());
        claimHistoriesDao.add(claimHistories);
    }

    @Override
    public List<Claim> search(String cobrefno) {
        return claimDao.search(cobrefno);
    }

    @Override
    public String maxCOBREFNO(char prefix) {
        String cobrefno = claimDao.maxCOBREFNO(prefix);

        if (cobrefno != null) {
            cobrefno = cobrefno.substring(1);

            return prefix + String.valueOf(Long.valueOf(cobrefno) + 1);
        }
        return prefix + String.valueOf(COBREFNO_INIT_VALUE);
    }

    @Override
    public List<ClaimHistories> findClaimHistoriesByClaimId(int claimId) {
        return claimHistoriesDao.findById(claimId);
    }

    @Override
    @CachePut
    public Claim update(Claim claim) {
        Claim update = claimDao.update(claim);

        ClaimHistories claimHistories = new ClaimHistories();
        BeanUtils.copyProperties(update, claimHistories);
        claimHistories.setStatus(ClaimHistoriesStatus.UPDATED.getValue());
        claimHistoriesDao.add(claimHistories);
        return update;
    }

    @Override
    @CachePut
    public int updateInvalid() {
        return claimDao.updateInvalid();
    }

    @Override
    public ClaimView toView(Claim claim) {
        if (claim == null) return null;

        ClaimView claimView = new ClaimView();
        List<ClaimProperties> properties = new ArrayList<>();
        ClaimProperties propertyView;
        Remark remark;
        RemarkView remarkView;
        ManualReview manualReview;
        ManualReviewView manualReviewView;

        BeanUtils.copyProperties(claim, claimView);
        claimView.setIsPrimaryPhoneUsa(claim.isPrimaryPhoneUsa());
        claimView.setIsAlternatePhone1Usa(claim.isAlternatePhone1Usa());
        for (Properties property : propertiesDao.findByClaimId(claim.getClaimId())) {
            propertyView = new ClaimProperties();
            BeanUtils.copyProperties(property, propertyView);
            properties.add(propertyView);
        }
        claimView.setProperties(properties);

        remark = remarkDao.findByClaimId(claim.getClaimId());
        remarkView = new RemarkView();
        BeanUtils.copyProperties(remark, remarkView);
        claimView.setRemark(remarkView);

        manualReview = manualReviewDao.findByClaimId(claim.getClaimId());
        manualReviewView = new ManualReviewView();
        BeanUtils.copyProperties(manualReview, manualReviewView);
        claimView.setManualReview(manualReviewView);

        return claimView;
    }

    @Override
    public List<Claim> search(int start, int length,
                              String cobrefno, Integer claimRefundTypeId, Integer[] status,
                              String receivedDate_s, String receivedDate_e,
                              String firstName, String lastName, String agentName) {
        List<Claim> claims = claimDao.search(start, length, cobrefno, claimRefundTypeId, status,
                receivedDate_s, receivedDate_e, firstName, lastName, agentName);

        return claims;
    }
}