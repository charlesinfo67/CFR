package com.orangecounty.claim4refund.utils;

import com.orangecounty.claim4refund.CFRApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LogUtils
 */
public class LogUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(CFRApplication.class);

    public static void error(Exception ex) {
        LOGGER.error(ex.getLocalizedMessage(), ex);
    }

    public static void debug(String message) {
        LOGGER.debug(message);
    }
}
