package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.RemarkHistories;

import java.util.List;

public interface RemarkHistoriesDao {
    void add(RemarkHistories entity);
    List<RemarkHistories> findByClaimId(int claimId);
}