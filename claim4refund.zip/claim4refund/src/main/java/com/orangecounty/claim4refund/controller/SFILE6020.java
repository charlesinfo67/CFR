package com.orangecounty.claim4refund.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.reports.ReportService;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.storage.StorageFileNotFoundException;
import com.orangecounty.claim4refund.storage.StorageService;
import com.orangecounty.claim4refund.utils.DateUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/createnewclaim/completed")
public class SFILE6020 {

    @Autowired
    private ReportService reportService;
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;

    private final StorageService storageService;

    @Autowired
    public SFILE6020(StorageService storageService) {
        this.storageService = storageService;
    }

    @GetMapping
    public String index(@RequestParam(name = "id", required = false) Integer claimId, Model model) {
        if (claimId == null) {
            return "redirect:/404";
        }
        return "/SFILE6020";
    }

    @PostMapping
    public ResponseEntity<Resource> print(@RequestParam(name = "id", required = false) Integer claimId) {
        String fileName = "";
        try {
            if (claimId == null) {
                return ResponseEntity.notFound().build();
            }

            Claim claim = claimService.findById(claimId);
            List<Properties> properties = propertiesService.findByClaimId(claimId);
            BigDecimal totalAmount = BigDecimal.ZERO;
            for (Properties prop : properties) {
                totalAmount = totalAmount.add(prop.getClaimAmount());
            }

            if (claim == null) {
                return ResponseEntity.notFound().build();
            }

            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> parameters = objectMapper.convertValue(claim, Map.class);
            parameters.put("receivedDate", DateUtils.format(claim.getReceivedDate(), "MM-dd-yyyy"));
            parameters.put("logoImg", "reports/oc_logo.png");
            parameters.put("subReport", "reports/ClaimProperties.jasper");
            parameters.put("properties", new JRBeanCollectionDataSource(properties));
            parameters.put("totalClaimAmount", totalAmount);

            fileName = reportService.generatePDFReport("REPORT6020", parameters);

        } catch (Exception e) {
            LogUtils.error(e);
        }
        return serveFile(fileName);
    }

    @GetMapping("{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {

        Resource file = storageService.loadPDFAsResource(filename);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
        LogUtils.error(exc);
        return ResponseEntity.notFound().build();
    }

}