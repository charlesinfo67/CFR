package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.RemarkHistories;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class RemarkHistoriesDaoImp implements RemarkHistoriesDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(RemarkHistories entity) {
        Session session = sessionFactory.getCurrentSession();
        session.save(entity);
    }

    @Override
    public List<RemarkHistories> findByClaimId(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<RemarkHistories> criteria = builder.createQuery(RemarkHistories.class);
        Root<RemarkHistories> root = criteria.from(RemarkHistories.class);
        criteria.where(builder.and(builder.equal(root.get("claimId"), claimId)));

        List<RemarkHistories> results = session.createQuery(criteria).getResultList();
        return results;
    }
}
