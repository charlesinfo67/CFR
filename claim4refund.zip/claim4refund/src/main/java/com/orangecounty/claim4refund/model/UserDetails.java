package com.orangecounty.claim4refund.model;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.UserAccount;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

public class UserDetails extends User {
    private static final long serialVersionUID = 1L;
    private UserAccount userAccount;

    public UserDetails(String username, String password, boolean enabled, boolean accountNonExpired,
                       boolean credentialsNonExpired, boolean accountNonLocked,
                       Collection<? extends GrantedAuthority> authorities) {
        super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
    }

    public UserDetails(UserAccount user) {
        super(user.getLoginId(), user.getPassword(), Constants.STATUS_ACTIVE.equals(user.getStatus()),
                true, true, true, user.getAuthorities());
        this.setUserAccount(user);
    }

    public UserAccount getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(UserAccount userAccount) {
        this.userAccount = userAccount;
    }

}
