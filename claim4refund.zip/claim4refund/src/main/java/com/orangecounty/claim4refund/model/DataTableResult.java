
package com.orangecounty.claim4refund.model;

import java.util.List;

public class DataTableResult {

    private Integer draw;
    private Long recordsTotal;
    private Long recordsFiltered;
    private List<ClaimViewOnList> data = null;

    public Integer getDraw() {
        return draw;
    }

    public void setDraw(Integer draw) {
        this.draw = draw;
    }

    public Long getRecordsTotal() {
        return recordsTotal;
    }

    public void setRecordsTotal(Long recordsTotal) {
        this.recordsTotal = recordsTotal;
    }

    public Long getRecordsFiltered() {
        return recordsFiltered;
    }

    public void setRecordsFiltered(Long recordsFiltered) {
        this.recordsFiltered = recordsFiltered;
    }

    public List<ClaimViewOnList> getData() {
        return data;
    }

    public void setData(List<ClaimViewOnList> data) {
        this.data = data;
    }

}
