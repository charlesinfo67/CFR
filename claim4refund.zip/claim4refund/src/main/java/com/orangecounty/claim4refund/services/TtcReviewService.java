package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.TtcReview;

import java.util.List;

public interface TtcReviewService {
    void create(TtcReview entity);

    List<TtcReview> get();

    TtcReview findById(String id);

    TtcReview update(TtcReview entity);

    void delete(String id);
}