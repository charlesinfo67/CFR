package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.UserAccount;

import java.util.List;

public interface UserDao {
    void add(UserAccount user);


    List<UserAccount> get();

    long countUsers();

    List<UserAccount> get(int role);

    UserAccount findById(String loginId);

    UserAccount findByEmail(String email);

    UserAccount update(UserAccount user);

    void delete(String loginId);

    long countNewUsers();

    List<UserAccount> search(String name, int year, Integer start, Integer length);
}