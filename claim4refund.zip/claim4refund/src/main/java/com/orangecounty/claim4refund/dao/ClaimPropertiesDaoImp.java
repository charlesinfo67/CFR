package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Properties;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ClaimPropertiesDaoImp implements ClaimPropertiesDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(Properties properties) {
        Session session = sessionFactory.getCurrentSession();
        session.save(properties);
    }

    @Override
    public Properties update(Properties properties) {
        Session session = sessionFactory.getCurrentSession();
        session.update(properties);
        return properties;
    }

    @Override
    public void delete(int propertyId) {
        Session session = sessionFactory.getCurrentSession();
        Properties properties = findById(propertyId);
        session.delete(properties);
    }

    @Override
    public List<Properties> get() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Properties> criteria = builder.createQuery(Properties.class);
        return session.createQuery(criteria).list();
    }

    @Override
    public Properties findById(int propertyId) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Properties.class, propertyId);
    }

    @Override
    public List<Properties> findByClaimId(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Properties> criteria = builder.createQuery(Properties.class);
        Root<Properties> root = criteria.from(Properties.class);
        criteria.where(builder.and(builder.equal(root.get("claimId"), claimId)));

        return session.createQuery(criteria).list();
    }

    @Override
    public boolean isDupplicated(Properties property) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Properties> criteria = builder.createQuery(Properties.class);
        Root<Properties> root = criteria.from(Properties.class);

        Predicate predicate = builder.and(builder.equal(root.get("taxYear"), property.getTaxYear()));
        if (!StringUtils.isEmpty(property.getApn())) {
            predicate = builder.and(predicate, builder.equal(root.get("apn"), property.getApn()));
        }
        if (!StringUtils.isEmpty(property.getAppealNo())) {
            predicate = builder.and(predicate, builder.equal(root.get("appealNo"), property.getAppealNo()));
        }
        if (property.getPropertyId() > 0) {
            predicate = builder.and(predicate, builder.notEqual(root.get("propertyId"), property.getPropertyId()));
        }

        criteria.where(predicate);

        return !session.createQuery(criteria).list().isEmpty();
    }

    @Override
    public List<Properties> search(int claimId,
                                   String apn,
                                   Integer taxyear,
                                   String assessmentNo) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Properties> criteria = builder.createQuery(Properties.class);
        Root<Properties> root = criteria.from(Properties.class);

        Predicate qr = builder.and(
                builder.equal(root.get("claimId"), claimId),
                builder.like(root.get("apn"), "%" + apn + "%"),
                builder.like(root.get("assessmentNo"), "%" + assessmentNo + "%")
        );

        if (taxyear != null) {
            qr = builder.and(qr, builder.equal(root.get("taxYear"), taxyear));
        }

        criteria.select(root)
                .where(qr);

        Query<Properties> query = session.createQuery(criteria);
        return query.list();
    }
}
