package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

@Controller
public class CFRErrorController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Exception exception = (Exception) request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
        if (exception != null)
            LogUtils.error(exception);
        if (status != null) {
            Integer statusCode = Integer.valueOf(status.toString());
            switch (HttpStatus.valueOf(statusCode)) {
                case NOT_FOUND:
                    return "/error/404";
                case UNAUTHORIZED:
                    return "/error/401";
                case FORBIDDEN:
                    return "/error/403";
                default:
                    return "/error/error";
            }
        }
        return "/error/error";
    }

    @Override
    public String getErrorPath() {
        return "/error";
    }
}
