package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.UserDao;
import com.orangecounty.claim4refund.entities.UserAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImp implements UserService {
    @Autowired
    UserDao userDao;

    @Override
    public List<UserAccount> get() {
        List<UserAccount> users = userDao.get();
        return users;
    }

    @Override
    public UserAccount findById(String loginId) {
        UserAccount user = userDao.findById(loginId);
        return user;
    }

    @Override
    public UserAccount findByEmail(String email) {
        UserAccount user = userDao.findByEmail(email);
        return user;
    }

    @Override
    public void create(UserAccount user) {
        userDao.add(user);
    }

    @Override
    public void delete(String loginId) {
        userDao.delete(loginId);
    }

    @Override
    public long countNewUsers() {
        return userDao.countNewUsers();
    }

    @Override
    public long countUsers() {
        return userDao.countUsers();
    }

    @Override
    public List<UserAccount> search(String name, int year, Integer start, Integer length) {
        return userDao.search(name, year, start, length);
    }

    @Override
    public UserAccount update(UserAccount user) {
        return userDao.update(user);
    }

    @Override
    public List<UserAccount> getByRole(int role) {
        List<UserAccount> users = userDao.get(role);
        return users;
    }

}