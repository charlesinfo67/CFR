package com.orangecounty.claim4refund.model;

import java.util.Objects;

public class ManualReviewView {
    private int id;
    private int claimId;
    private Boolean option1;
    private Boolean option2;
    private Boolean option3;
    private Boolean option4;
    private Boolean option5;
    private Boolean option6;
    private Boolean option7;
    private Boolean option8;
    private Boolean option9;
    private Boolean option10;
    private Boolean option11;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public Boolean getOption1() {
        return option1;
    }

    public void setOption1(Boolean option1) {
        this.option1 = option1;
    }

    public Boolean getOption2() {
        return option2;
    }

    public void setOption2(Boolean option2) {
        this.option2 = option2;
    }

    public Boolean getOption3() {
        return option3;
    }

    public void setOption3(Boolean option3) {
        this.option3 = option3;
    }

    public Boolean getOption4() {
        return option4;
    }

    public void setOption4(Boolean option4) {
        this.option4 = option4;
    }

    public Boolean getOption5() {
        return option5;
    }

    public void setOption5(Boolean option5) {
        this.option5 = option5;
    }

    public Boolean getOption6() {
        return option6;
    }

    public void setOption6(Boolean option6) {
        this.option6 = option6;
    }

    public Boolean getOption7() {
        return option7;
    }

    public void setOption7(Boolean option7) {
        this.option7 = option7;
    }

    public Boolean getOption8() {
        return option8;
    }

    public void setOption8(Boolean option8) {
        this.option8 = option8;
    }

    public Boolean getOption9() {
        return option9;
    }

    public void setOption9(Boolean option9) {
        this.option9 = option9;
    }

    public Boolean getOption10() {
        return option10;
    }

    public void setOption10(Boolean option10) {
        this.option10 = option10;
    }

    public Boolean getOption11() {
        return option11;
    }

    public void setOption11(Boolean option11) {
        this.option11 = option11;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ManualReviewView that = (ManualReviewView) o;
        return id == that.id &&
                claimId == that.claimId &&
                Objects.equals(option1, that.option1) &&
                Objects.equals(option2, that.option2) &&
                Objects.equals(option3, that.option3) &&
                Objects.equals(option4, that.option4) &&
                Objects.equals(option5, that.option5) &&
                Objects.equals(option6, that.option6) &&
                Objects.equals(option7, that.option7) &&
                Objects.equals(option8, that.option8) &&
                Objects.equals(option9, that.option9) &&
                Objects.equals(option10, that.option10) &&
                Objects.equals(option11, that.option11);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, claimId, option1, option2, option3, option4, option5, option6, option7, option8, option9, option10, option11);
    }
}
