package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.Token;

import java.util.List;

public interface TokenService {
    void create(Token token);

    List<Token> get();

    Token findById(String id);

    Token findByValue(String value, int type);

    Token update(Token token);

    void delete(String id);

    Token check(String token, int type);
}