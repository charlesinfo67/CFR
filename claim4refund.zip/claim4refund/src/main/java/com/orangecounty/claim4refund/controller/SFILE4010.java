package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Country;
import com.orangecounty.claim4refund.entities.SecQuestion;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.model.UserEdit;
import com.orangecounty.claim4refund.services.CountryService;
import com.orangecounty.claim4refund.services.SecQuestionService;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/dashboard/profile")
public class SFILE4010 {
    @Autowired
    private UserService userService;
    @Autowired
    private SecQuestionService secQuestionService;
    @Autowired
    private CountryService countryService;

    @ModelAttribute("countries")
    public List<Country> countries() {
        return countryService.get();
    }

    @ModelAttribute("secQuestions")
    public List<SecQuestion> secQuestions() {
        return secQuestionService.get();
    }

    @GetMapping
    public String index(@RequestParam(required = false) String edit, final Model model) {
        UserAccount user = userService.findById(CommonUtils.getUserAccount().getLoginId());
        if (edit != null) {
            UserEdit userEdit = new UserEdit();
            BeanUtils.copyProperties(user, userEdit);
            userEdit.setConfirmEmail(userEdit.getEmail());

            model.addAttribute("userEdit", userEdit);
            return "/SFILE4011";
        }
        model.addAttribute("user", user);
        return "/SFILE4010";
    }

    @PostMapping
    public String edit(@ModelAttribute("userEdit") @Valid UserEdit user,
                       BindingResult result) {
        String url = "/SFILE4011";
        UserAccount updateUser;
        try {
            if (!result.hasErrors()) {
                updateUser = userService.findById(user.getLoginId());
                BeanUtils.copyProperties(user, updateUser);

                userService.update(updateUser);
                url = "redirect:/dashboard/profile";
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }

        return url;
    }
}
