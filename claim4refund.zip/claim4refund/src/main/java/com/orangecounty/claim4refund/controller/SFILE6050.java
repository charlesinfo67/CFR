package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.services.ClaimRefundStatusService;
import com.orangecounty.claim4refund.services.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/searchclaim")
public class SFILE6050 {
    @Autowired
    private ClaimService claimService;

    @Autowired
    private ClaimRefundStatusService statusService;

    @ModelAttribute("status")
    public List<ClaimRefundStatusMSTR> claimRefundStatusMstrs() {
        return statusService.get();
    }

    @GetMapping
    public String index() {
        return "/SFILE6050";
    }

    @PostMapping
    public String search(Model model, @RequestParam(value = "cobrefno", required = true) String cobrefno) {
        ClaimView claimView;

        Optional<Claim> claim = Optional.ofNullable(claimService.findByCobrefno(cobrefno, Optional.empty()));
        if (claim.isPresent()) {
            claimView = claimService.toView(claim.get());
            model.addAttribute("claim", claimView);
        }
        model.addAttribute("cobrefno", cobrefno);

        return "/SFILE6050";
    }

}