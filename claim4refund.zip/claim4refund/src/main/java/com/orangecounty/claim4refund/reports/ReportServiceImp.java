package com.orangecounty.claim4refund.reports;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.utils.DateUtils;
import net.sf.jasperreports.engine.JRDataSource;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ReportServiceImp implements ReportService {
    private static final String REPORT_PATH = "/reports/";
    private ReportFiller reportFiller;
    private ReportExporter reportExporter;

    public ReportServiceImp() {
    }

    @Override
    public void compileReport(String inputFileName) {
        reportFiller = new ReportFiller();
        reportFiller.setReportFileName(REPORT_PATH + inputFileName + ".jrxml");
        reportFiller.compileReport();
    }

    @Override
    public String generateReport(String inputFileName, Map<String, Object> params, ReportService.Type t, String outputName) {

        switch (t) {
            case DOCX:
                return generateDocxReport(inputFileName, params, outputName);
            case PDF:
                return generatePDFReport(inputFileName, params, outputName);
        }
        return "";
    }

    private String generateDocxReport(String inputFileName, Map<String, Object> params, String outputFileName) {
        String outputFilename = String.format("%s_%s.docx", inputFileName, outputFileName);
        String docx = String.join("/", Constants.REPORT_TEMP_PATH, outputFilename);

        reportFiller = new ReportFiller();
        reportExporter = new ReportExporter();

        reportFiller.loadReport(REPORT_PATH + inputFileName + ".jasper");

        reportFiller.setParameters(params);
        reportFiller.fillReport();

        reportExporter.setJasperPrint(reportFiller.getJasperPrint());

        reportExporter.exportToDocx(docx, "County of Orange");
        return outputFilename;
    }

    private String generateDocxReport(String inputFileName, Map<String, Object> params) {
        return generateDocxReport(inputFileName, params, DateUtils.toDayDateString("MMddyyyyhhmmss"));
    }

    public String generatePDFReport(String inputFileName, Map<String, Object> params, String outputFileName) {
        String outputFilename = String.format("%s_%s.pdf", inputFileName, outputFileName);
        String pdfPath = String.join("/", Constants.REPORT_TEMP_PATH, outputFilename);

        reportFiller = new ReportFiller();
        reportExporter = new ReportExporter();

        reportFiller.loadReport(REPORT_PATH + inputFileName + ".jasper");

        reportFiller.setParameters(params);
        reportFiller.fillReport();

        reportExporter.setJasperPrint(reportFiller.getJasperPrint());

        reportExporter.exportToPdf(pdfPath, "County of Orange");
        return outputFilename;
    }

    @Override
    public String generatePDFReport(String inputFileName, Map<String, Object> params) {
        return generatePDFReport(inputFileName, params, DateUtils.toDayDateString("MMddyyyyhhmmss"));
    }

    @Override
    public String generatePDFReport(String inputFileName, Map<String, Object> params, JRDataSource dataSource) {
        String outputFilename = String.format("%s_%s.pdf", inputFileName, DateUtils.toDayDateString("MMddyyyyhhmmss"));
        String pdfPath = String.join("/", Constants.REPORT_TEMP_PATH, outputFilename);

        reportFiller = new ReportFiller();
        reportExporter = new ReportExporter();

        reportFiller.loadReport(REPORT_PATH + inputFileName + ".jasper");

        reportFiller.setParameters(params);
        reportFiller.setDataSource(dataSource);
        reportFiller.fillReport();

        reportExporter.setJasperPrint(reportFiller.getJasperPrint());

        reportExporter.exportToPdf(pdfPath, "County of Orange");
        return outputFilename;
    }
}
