package com.orangecounty.claim4refund.utils;

import java.security.SecureRandom;

public class TokenGenerator {

    protected static SecureRandom random = new SecureRandom();

    public static synchronized String generateToken() {
        long longToken = Math.abs(random.nextLong());
        return Long.toString(longToken, 16);
    }
}
