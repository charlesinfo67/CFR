package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.GroupedCount;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.model.ClaimViewOnList;
import com.orangecounty.claim4refund.model.DataTableResult;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.utils.DateUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@RequestMapping("/admin/metrics")
public class SFILE7060 {
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;

    @ModelAttribute("statusCounts")
    public List<GroupedCount> countByStatus() {
        List<GroupedCount> result = claimService.countByStatus(1, 2, 3);
        GroupedCount tmp;
        for (int i = 1; i <= 3; i++) {
            tmp = new GroupedCount(i, 0);
            if (!result.contains(tmp))
                result.add(tmp);
        }
        return result;
    }

    @ModelAttribute("_30dayCountsTTC")
    public List<GroupedCount> _30dayCountsTTC() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 0, 1);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_60dayCountsTTC")
    public List<GroupedCount> _60dayCountsTTC() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 1, 2);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_90dayCountsTTC")
    public List<GroupedCount> _90dayCountsTTC() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 2, 3);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_91dayCountsTTC")
    public List<GroupedCount> _91dayCountsTTC() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 3, 0);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_30dayCountsASS")
    public List<GroupedCount> _30dayCountsASS() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 0, 1);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_60dayCountsASS")
    public List<GroupedCount> _60dayCountsASS() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 1, 2);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_90dayCountsASS")
    public List<GroupedCount> _90dayCountsASS() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 2, 3);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("_91dayCountsASS")
    public List<GroupedCount> _91dayCountsASS() {
        List<GroupedCount> result = claimService.countPendingReview(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 3, 0);
        if (result == null || result.isEmpty()) {
            result = new ArrayList<>();
            result.add(new GroupedCount(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue(), 0));
        }
        return result;
    }

    @ModelAttribute("closedCounts")
    public List<GroupedCount> closedCounts() {
        List<GroupedCount> result = claimService.countByStatus(6, 7, 8, 9);
        GroupedCount tmp;
        for (int i = 6; i <= 9; i++) {
            tmp = new GroupedCount(i, 0);
            if (!result.contains(tmp))
                result.add(tmp);
        }
        return result;
    }

    @GetMapping
    public String index(Model model) {
        return "/SFILE7060";
    }


    @ResponseBody
    @PostMapping(path = "/search")
    public DataTableResult search(@RequestParam Integer draw,
                                  @RequestParam Integer start,
                                  @RequestParam Integer length,
                                  @RequestParam(name = "status") Integer[] status,
                                  @RequestParam(name = "month_s", required = false, defaultValue = "0") Integer month_s,
                                  @RequestParam(name = "month_e", required = false, defaultValue = "0") Integer month_e) {
        DataTableResult result = new DataTableResult();
        List<ClaimViewOnList> claimsView;
        long recordFiltered = 0;
        String receivedDate_s = "";
        String receivedDate_e = "";
        try {
            claimsView = new ArrayList<>();

            if (month_s > 0) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(new Date());
                calendar.add(Calendar.MONTH, (-1) * month_s);

                receivedDate_s = DateUtils.format(calendar.getTime(), "yyyy-MM-dd");
            }
            if (month_e > 0) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(new Date());
                calendar.add(Calendar.MONTH, (-1) * month_e);

                receivedDate_e = DateUtils.format(calendar.getTime(), "yyyy-MM-dd");
            }

            List<Claim> claims = claimService.search(start, length, "", null, status,
                    receivedDate_s, receivedDate_e, "", "", "");

            recordFiltered = claimService.search(start, -1, "", null, status,
                    receivedDate_s, receivedDate_e, "", "", "").size();

            claims.forEach(claim -> {
                ClaimViewOnList claimViewOnLst = new ClaimViewOnList();
                BeanUtils.copyProperties(claim, claimViewOnLst);
                claimViewOnLst.setClaimantName(claim.getFirstName() + ' ' + claim.getLastName());

                Optional<Properties> prop = propertiesService.findByClaimId(claim.getClaimId()).stream().findFirst();
                if (prop.isPresent()) {
                    claimViewOnLst.setPropertyId(prop.get().getPropertyId());
                    claimViewOnLst.setAppealNo(prop.get().getAppealNo());
                    claimViewOnLst.setApn(prop.get().getApn());
                    claimViewOnLst.setTaxYear(prop.get().getTaxYear());
                    claimViewOnLst.setAssessmentNo(prop.get().getAssessmentNo());
                    claimViewOnLst.setClaimLineStatusId(prop.get().getClaimLineStatusId());
                }

                claimsView.add(claimViewOnLst);
            });

            result.setDraw(draw);
            result.setRecordsTotal(claimService.countClaims());
            result.setRecordsFiltered(recordFiltered);
            result.setData(claimsView);

        } catch (Exception e) {
            //result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }
}