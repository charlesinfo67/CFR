package com.orangecounty.claim4refund.mail;

public interface MailGunService {
    void sendText(String from, String to, String subject, String body);

    void sendHTML(String from, String to, String subject, String body);
}
