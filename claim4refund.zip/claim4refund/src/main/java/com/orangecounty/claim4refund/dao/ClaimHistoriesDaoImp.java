package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ClaimHistories;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ClaimHistoriesDaoImp implements ClaimHistoriesDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(ClaimHistories claimHistories) {
        Session session = sessionFactory.getCurrentSession();
        session.save(claimHistories);
    }

    @Override
    public List<ClaimHistories> findById(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<ClaimHistories> criteria = builder.createQuery(ClaimHistories.class);
        Root<ClaimHistories> root = criteria.from(ClaimHistories.class);

        criteria.where(builder.and(builder.equal(root.get("claimId"), claimId)));

        return session.createQuery(criteria).list();
    }
}
