package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.State;

import java.util.List;

public interface StateService {
    void create(State state);

    List<State> get();

    State findById(String id);

    State update(State state);

    void delete(String id);
}