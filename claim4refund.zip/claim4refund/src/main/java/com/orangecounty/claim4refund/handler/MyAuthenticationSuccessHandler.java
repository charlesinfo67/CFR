package com.orangecounty.claim4refund.handler;

import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.model.UserDetails;
import com.orangecounty.claim4refund.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@Component
public class MyAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
    @Autowired
    private UserService userService;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws
            IOException {

        UserAccount loggedUser = ((UserDetails) authentication.getPrincipal()).getUserAccount();
        loggedUser.setLastLogin(new Date());
        userService.update(loggedUser);

        response.sendRedirect(request.getContextPath()+"/dashboard");
    }
}
