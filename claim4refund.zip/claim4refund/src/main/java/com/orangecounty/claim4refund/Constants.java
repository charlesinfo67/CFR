package com.orangecounty.claim4refund;

public class Constants {
    public static final String STATUS_PENDING = "0";
    public static final String STATUS_ACTIVE = "1";
    public static final String STATUS_INACTIVE = "2";

    public static final int USER_ROLE_MEMBER = 2;
    public static final int USER_ROLE_ADMIN = 4;

    public static final int TOKEN_TYPE_RESET_PASS = 1;

    public static final String CLAIM_APP_TYPE_I = "I";
    public static final String CLAIM_APP_TYPE_C = "C";

    public static final int CLAIM_REFUND_TYPE_1 = 1;
    public static final int CLAIM_REFUND_TYPE_2 = 2;

    public static final String REFUND_TYPE_PARTIAL = "P";
    public static final String REFUND_TYPE_FULL = "F";

    public static final long COBREFNO_INIT_VALUE = 200000;

    public static final char COBREFNO_PREFIX_T = 'T';
    public static final char COBREFNO_PREFIX_P = 'P';

    public static final String REPORT_TEMP_PATH = "../reportsTemp";
}
