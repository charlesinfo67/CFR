package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.PropertyHistories;

import java.util.List;

public interface ClaimPropertyHistoriesDao {

    void add(PropertyHistories propHistory);

    List<PropertyHistories> findByPropertyId(int propertyId);

    List<PropertyHistories> findByClaimId(int claimId);

}