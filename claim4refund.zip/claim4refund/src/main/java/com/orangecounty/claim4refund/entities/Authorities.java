package com.orangecounty.claim4refund.entities;

import java.util.HashMap;
import java.util.Map;

public enum Authorities {
    INACTIVE(0), ROLE_USER(2), ROLE_ADMIN(4);

    private static final Map<Integer, Authorities> MY_MAP = new HashMap<>();

    static {
        for (Authorities myEnum : values()) {
            MY_MAP.put(myEnum.getValue(), myEnum);
        }
    }

    private final int value;

    Authorities(int value) {
        this.value = value;
    }

    public static Authorities getByValue(int value) {
        return MY_MAP.get(value);
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        return name() + ":" + value;
    }
}
