package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.TtcReviewDao;
import com.orangecounty.claim4refund.entities.TtcReview;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class TtcReviewServiceImp implements TtcReviewService {
    @Autowired
    TtcReviewDao claimRefundStatusDao;

    @Override
    public List<TtcReview> get() {
        return claimRefundStatusDao.get();
    }

    @Override
    public TtcReview findById(String id) {
        return claimRefundStatusDao.findById(id);
    }

    @Override
    public void create(TtcReview entity) {
        claimRefundStatusDao.add(entity);
    }

    @Override
    public void delete(String id) {
        claimRefundStatusDao.delete(id);
    }

    @Override
    public TtcReview update(TtcReview entity) {
        return claimRefundStatusDao.update(entity);
    }
}