package com.orangecounty.claim4refund.model;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

public class FileEdit {
    private int fileId;
    @Size(max = 255)
    private String templateName;
    @Size(max = 255)
    private String realName;
    @Size(max = 255)
    private String fileLocation;
    private BigDecimal cost;
    private String status;
    @Size(max = 300)
    private String description;
    private MultipartFile templateFile;
    @DateTimeFormat(iso=DateTimeFormat.ISO.DATE)
    private Date availStartDate;
    @DateTimeFormat(iso=DateTimeFormat.ISO.DATE)
    private Date availEndDate;
    private String updateBy;
    private Date updateDate;
    private Date realDate;
    private int frequency;

    public int getFileId() {
        return fileId;
    }

    public void setFileId(int fileId) {
        this.fileId = fileId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getFileLocation() {
        return fileLocation;
    }

    public void setFileLocation(String fileLocation) {
        this.fileLocation = fileLocation;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MultipartFile getTemplateFile() {
        return templateFile;
    }

    public void setTemplateFile(MultipartFile templateFile) {
        this.templateFile = templateFile;
    }

    public Date getAvailStartDate() {
        return availStartDate;
    }

    public void setAvailStartDate(Date availStartDate) {
        this.availStartDate = availStartDate;
    }

    public Date getAvailEndDate() {
        return availEndDate;
    }

    public void setAvailEndDate(Date availEndDate) {
        this.availEndDate = availEndDate;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    public Date getRealDate() {
    	return realDate;
    }
    
    public void setRealDate(Date realDate) {
    	this.realDate = realDate;
    }

    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }
}
