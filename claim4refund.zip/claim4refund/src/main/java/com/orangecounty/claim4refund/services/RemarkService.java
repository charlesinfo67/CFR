package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.Remark;
import com.orangecounty.claim4refund.entities.RemarkHistories;

import java.util.List;

public interface RemarkService {
    void create(Remark entity);

    List<Remark> get();

    Remark findById(String id);

    Remark findByClaimId(int claimId);

    Remark update(Remark entity);

    void delete(String id);
    List<RemarkHistories> findRemarkHistoriesByClaimId(int claimId);

    enum RemarkHistoryStatus {
        CREATED(1, "CREATED"),
        UPDATED(2, "UPDATED"),
        DELETED(3, "DELETED");

        private int code;
        private String text;

        RemarkHistoryStatus(int code, String text) {
            this.code = code;
            this.text = text;
        }

        public static RemarkHistoryStatus getStatusByCode(int code) {
            for (RemarkHistoryStatus status : RemarkHistoryStatus.values()) {
                if (status.code == code) {
                    return status;
                }
            }
            return null;
        }
        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }
}