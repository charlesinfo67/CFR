package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/dashboard/change_pass")
public class SFILE4020 {
    @Autowired
    private UserService userService;

    @GetMapping
    public String index(final Model model) {
        return "/SFILE4020";
    }

    @PostMapping
    public String updatePasswd(@RequestParam(required = true) String oldPassword,
                               @RequestParam(required = true) String password,
                               @RequestParam(required = true) String passwordConfirm, final Model model) {
        String url = "/SFILE4020";
        try {
            for (; ; ) {
                BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

                UserAccount user = userService.findById(CommonUtils.getUserAccount().getLoginId());

                if (!bCryptPasswordEncoder.matches(oldPassword, user.getPassword())) {
                    model.addAttribute("message", "Incorrect current password!");
                    break;
                }
                if (!password.equals(passwordConfirm)) {
                    model.addAttribute("message", "Your new password was not match!");
                    break;
                }

                String encodedPass = bCryptPasswordEncoder.encode(password);
                user.setPassword(encodedPass);

                userService.update(user);
                model.addAttribute("message", "Your password was updated!");
                model.addAttribute("success", "success");
                break;
            }

        } catch (Exception e) {
            model.addAttribute("message", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }

        return url;
    }
}
