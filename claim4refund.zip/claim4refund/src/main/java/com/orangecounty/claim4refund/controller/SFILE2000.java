package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.Country;
import com.orangecounty.claim4refund.entities.SecQuestion;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.model.UserRegister;
import com.orangecounty.claim4refund.services.CountryService;
import com.orangecounty.claim4refund.services.SecQuestionService;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/register")
public class SFILE2000 {

    @Autowired
    public EmailService emailService;
    @Autowired
    private UserService userService;
    @Autowired
    private SecQuestionService secQuestionService;
    @Autowired
    private CountryService countryService;

    @ModelAttribute("user")
    public UserRegister userRegistrationDto() {
        return new UserRegister();
    }

    @ModelAttribute("countries")
    public List<Country> countries() {
        return countryService.get();
    }

    @ModelAttribute("secQuestions")
    public List<SecQuestion> secQuestions() {
        return secQuestionService.get();
    }

    @GetMapping
    public String showRegistrationForm(final Model model) {
        return "/SFILE2000";
    }

    @PostMapping
    public String registerUserAccount(@ModelAttribute("user") @Valid UserRegister user,
                                      BindingResult result) {
        String url = "/SFILE2000";
        UserAccount newUser;
        try {
            UserAccount existing = userService.findById(user.getLoginId());
            if (existing != null) {
                result.rejectValue("loginId", null, "There is already an account registered with that ID");
            }

            existing = userService.findByEmail(user.getEmail());
            if (existing != null) {
                result.rejectValue("email", null, "There is already an account registered with that email");
            }

            if (!result.hasErrors()) {
//                PasswordGenerator passwordGenerator = new PasswordGenerator.PasswordGeneratorBuilder()
//                        .useDigits(true)
//                        .useLower(true)
//                        .useUpper(true)
//                        .build();
//                String password = passwordGenerator.generate(8);
                BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
                String encodedPass = bCryptPasswordEncoder.encode(user.getPassword());

                newUser = new UserAccount();
                BeanUtils.copyProperties(user, newUser);
                newUser.setPassword(encodedPass);
                newUser.setStatus(Constants.STATUS_PENDING);
                newUser.setRole(Constants.USER_ROLE_MEMBER);
                newUser.setRegistedDate(new Date());

                userService.create(newUser);

                List<UserAccount> admins = userService.getByRole(Constants.USER_ROLE_ADMIN);
                for (UserAccount admin : admins) {
                    emailService.sendNotiMail("You have a new Account need to approval.", admin);
                }

                emailService.sendNotiMail("Thank you for register.  Please check your email for Activation", newUser);
                url = "redirect:/register?success";
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }

        return url;
    }
}
