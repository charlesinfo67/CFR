package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.*;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.model.RemarkView;
import com.orangecounty.claim4refund.services.ClaimLineStatusService;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.services.RemarkService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.DateUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/admin/ttcreview")
public class SFILE8030 {
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;
    @Autowired
    private RemarkService remarkService;
    @Autowired
    private ClaimLineStatusService claimLineStatusService;

    @ModelAttribute("linestatus")
    public List<ClaimLineStatusMstr> linestatus() {
        return claimLineStatusService.get();
    }

    @GetMapping()
    public String index(@RequestParam Integer id, final Model model) {
        ClaimView claimView;

        Claim claim = claimService.findById(id);
        if (claim == null)
            return "/error/404";

        switch (ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId())) {
            case PENDING_TTC_REVIEW:
                claimView = claimService.toView(claim);

                model.addAttribute("claim", claimView);

                break;
            default:
                model.addAttribute("message", "Claim selected is not in status \"Pending TTC Review\".");
        }

        return "/SFILE8030";
    }

    @PostMapping(params = "save")
    public String save(@ModelAttribute("claim") @Valid ClaimView claim,
                       BindingResult result) {
        String url = "/SFILE8030";

        try {
            updateClaim(claim, "save");
            url = "redirect:/admin/claimview?id=" + claim.getClaimId();
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "assessor")
    public String assessor(@ModelAttribute("claim") @Valid ClaimView claim,
                           BindingResult result) {

        String url = "/SFILE8030";

        try {
            updateClaim(claim, "assessor");
            url = "redirect:/admin/claimview?id=" + claim.getClaimId();
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "finalize")
    public String finalize(@ModelAttribute("claim") @Valid ClaimView claim,
                           BindingResult result) {

        String url = "/SFILE8030";

        try {
            updateClaim(claim, "finalize");
            url = "redirect:/admin/claimview?id=" + claim.getClaimId();
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    private Claim updateClaim(ClaimView claim, String mode) {
        Remark remark;
        // Update claim
        Claim currentClaim = claimService.findById(claim.getClaimId());

        switch (mode) {
            case "save":
                currentClaim.setClaimStatusId(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue());
                break;
            case "assessor":
                currentClaim.setClaimStatusId(ClaimService.ClaimStatus.PENDING_ASSESSOR_REVIEW.getValue());
                break;
            case "finalize":
                currentClaim.setClaimStatusId(ClaimService.ClaimStatus.CLOSED.getValue());
                break;
        }
        currentClaim.setUpdatedBy(currentClaim.getCreatedBy());
        currentClaim.setUpdatedDate(currentClaim.getCreatedDate());
        claimService.update(currentClaim);

        for (ClaimProperties claimProperties : claim.getProperties()) {
            if (StringUtils.isEmpty(claimProperties.getApn()) && StringUtils.isEmpty(claimProperties.getAssessmentNo()))
                continue;
            Properties properties = propertiesService.findById(claimProperties.getPropertyId());
            if (properties.getClaimLineStatusId() == claimProperties.getClaimLineStatusId()
            ) { // property equal => no update
                continue;
            }
            properties.setClaimLineStatusId(claimProperties.getClaimLineStatusId());
            properties.setUpdatedDate(DateUtils.now_sql());
            properties.setUpdatedBy(CommonUtils.getUserAccount().getLoginId());
            propertiesService.update(properties);
        }

        remark = remarkService.findByClaimId(currentClaim.getClaimId());
        if (remark.getRemarkId() != 0) {
            RemarkView claimRemark = claim.getRemark();

            if (!Objects.equals(claimRemark.getRemarksLetter(), remark.getRemarksLetter())
                    || !Objects.equals(claimRemark.getRemarks(), remark.getRemarks())
            ) { // not same remark, updated
                remark.setRemarksLetter(claim.getRemark().getRemarksLetter());
                remark.setRemarks(claim.getRemark().getRemarks());
                remark.setClaimId(currentClaim.getClaimId());
                remark.setUpdatedDate(DateUtils.now_sql());
                remark.setUpdatedBy(CommonUtils.getUserAccount().getLoginId());

                remarkService.update(remark);
            }
        } else {
            newRemark(claim, currentClaim, CommonUtils.getUserAccount());
        }
        return currentClaim;
    }

    private void newRemark(@Valid @ModelAttribute("claim") ClaimView claim, Claim newClaim, UserAccount finalUser) {
        // check for null/empty remark
        if (StringUtils.isNotEmpty(claim.getRemark().getRemarks())
                || StringUtils.isNotEmpty(claim.getRemark().getRemarksLetter())) {


            Remark remark;
            remark = new Remark();
            BeanUtils.copyProperties(claim.getRemark(), remark);
            remark.setClaimId(newClaim.getClaimId());
            remark.setRv(DateUtils.now_sql());
            remark.setCreatedDate(DateUtils.now_sql());
            remark.setUpdatedDate(DateUtils.now_sql());
            remark.setCreatedBy(finalUser.getLoginId());
            remark.setUpdatedBy(finalUser.getLoginId());

            remarkService.create(remark);
        }
    }
}
