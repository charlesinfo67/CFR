package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.ManualReviewDao;
import com.orangecounty.claim4refund.entities.ManualReview;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ManualReviewServiceImp implements ManualReviewService {
    @Autowired
    ManualReviewDao manualReviewDao;

    @Override
    public List<ManualReview> get() {
        List<ManualReview> entity = manualReviewDao.get();
        return entity;
    }

    @Override
    public ManualReview findById(int id) {
        ManualReview entity = manualReviewDao.findById(id);
        return entity;
    }

    @Override
    public ManualReview findByClaimId(int claimId) {
        return manualReviewDao.findByClaimId(claimId);
    }

    @Override
    public void create(ManualReview entity) {
        manualReviewDao.add(entity);
    }

    @Override
    public void delete(int id) {
        manualReviewDao.delete(id);
    }

    @Override
    public ManualReview update(ManualReview entity) {
        return manualReviewDao.update(entity);
    }

}