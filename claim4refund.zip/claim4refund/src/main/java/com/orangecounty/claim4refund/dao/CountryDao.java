package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Country;

import java.util.List;

public interface CountryDao {
    void add(Country country);

    List<Country> get();

    Country findById(String id);

    Country update(Country country);

    void delete(String id);
}