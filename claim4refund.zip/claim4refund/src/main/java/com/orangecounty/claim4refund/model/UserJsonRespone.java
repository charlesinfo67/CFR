package com.orangecounty.claim4refund.model;

import com.orangecounty.claim4refund.entities.UserAccount;


public class UserJsonRespone {

    private UserAccount user;
    private boolean success;
    private String errorMessages;

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(String errorMessages) {
        this.errorMessages = errorMessages;
    }
}
