package com.orangecounty.claim4refund.reports;

import com.orangecounty.claim4refund.utils.LogUtils;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.util.JRSaver;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Component
public class ReportFiller {

    private String reportFileName;

    private JasperReport jasperReport;

    private JasperPrint jasperPrint;

    private Map<String, Object> parameters;

    private JRDataSource dataSource;

    public ReportFiller() {
        parameters = new HashMap<>();
        dataSource = new JREmptyDataSource();
    }

    public void prepareReport() {
        compileReport();
        fillReport();
    }

    public void loadReport(String jasperFileName) {
        try {
            InputStream reportStream = getClass().getResourceAsStream(jasperFileName);
            jasperReport = (JasperReport) JRLoader.loadObject(reportStream);
        } catch (JRException ex) {
            LogUtils.error(ex);
        }
    }

    public void compileReport() {
        try {
            InputStream reportStream = getClass().getResourceAsStream(reportFileName);
            jasperReport = JasperCompileManager.compileReport(reportStream);
            JRSaver.saveObject(jasperReport, reportFileName.replace(".jrxml", ".jasper"));
        } catch (JRException ex) {
            LogUtils.error(ex);
        }
    }

    public void fillReport() {
        try {
            jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
        } catch (JRException ex) {
            LogUtils.error(ex);
        }
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public String getReportFileName() {
        return reportFileName;
    }

    public void setReportFileName(String reportFileName) {
        this.reportFileName = reportFileName;
    }

    public JasperPrint getJasperPrint() {
        return jasperPrint;
    }

    public JRDataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(JRDataSource dataSource) {
        this.dataSource = dataSource;
    }

}
