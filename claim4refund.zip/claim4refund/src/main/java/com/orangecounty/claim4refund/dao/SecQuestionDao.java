package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.SecQuestion;

import java.util.List;

public interface SecQuestionDao {
    void add(SecQuestion question);

    List<SecQuestion> get();

    SecQuestion findById(String id);

    SecQuestion update(SecQuestion question);

    void delete(String id);
}