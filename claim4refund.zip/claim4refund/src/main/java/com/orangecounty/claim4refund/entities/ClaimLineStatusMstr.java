package com.orangecounty.claim4refund.entities;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "ClaimLineStatusMSTR", schema = "dbo", catalog = "CFRDB")
public class ClaimLineStatusMstr {
    private int claimLineStatusId;
    private String description;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private boolean isActive;
    private Date inActiveDate;
    private String code;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ClaimLineStatusID", nullable = false)
    public int getClaimLineStatusId() {
        return claimLineStatusId;
    }

    public void setClaimLineStatusId(int claimLineStatusId) {
        this.claimLineStatusId = claimLineStatusId;
    }

    @Basic
    @Column(name = "Description", nullable = false, length = 50)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "CreatedBy", nullable = false, length = 50)
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Basic
    @Column(name = "CreatedDate", nullable = false)
    public java.sql.Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(java.sql.Date createdDate) {
        this.createdDate = createdDate;
    }

    @Basic
    @Column(name = "UpdatedBy", nullable = true, length = 50)
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Basic
    @Column(name = "UpdatedDate", nullable = true)
    public java.sql.Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(java.sql.Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Basic
    @Column(name = "RV", nullable = false)
    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }

    @Basic
    @Column(name = "IsActive", nullable = false)
    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Basic
    @Column(name = "InActiveDate", nullable = true)
    public java.sql.Date getInActiveDate() {
        return inActiveDate;
    }

    public void setInActiveDate(java.sql.Date inActiveDate) {
        this.inActiveDate = inActiveDate;
    }

    @Basic
    @Column(name = "Code", nullable = false, length = 5)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        ClaimLineStatusMstr that = (ClaimLineStatusMstr) object;

        if (claimLineStatusId != that.claimLineStatusId) return false;
        if (isActive != that.isActive) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (updatedBy != null ? !updatedBy.equals(that.updatedBy) : that.updatedBy != null) return false;
        if (updatedDate != null ? !updatedDate.equals(that.updatedDate) : that.updatedDate != null) return false;
        if (rv != null ? !rv.equals(that.rv) : that.rv != null) return false;
        if (inActiveDate != null ? !inActiveDate.equals(that.inActiveDate) : that.inActiveDate != null) return false;
        return code != null ? code.equals(that.code) : that.code == null;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + claimLineStatusId;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (updatedBy != null ? updatedBy.hashCode() : 0);
        result = 31 * result + (updatedDate != null ? updatedDate.hashCode() : 0);
        result = 31 * result + (rv != null ? rv.hashCode() : 0);
        result = 31 * result + (isActive ? 1 : 0);
        result = 31 * result + (inActiveDate != null ? inActiveDate.hashCode() : 0);
        result = 31 * result + (code != null ? code.hashCode() : 0);
        return result;
    }
}
