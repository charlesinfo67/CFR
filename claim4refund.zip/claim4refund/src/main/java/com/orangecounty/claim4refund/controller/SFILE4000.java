package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dashboard")
public class SFILE4000 {
    @Autowired
    private UserService userService;

    @ModelAttribute("newUsers")
    public long newUsers() {
        return userService.countNewUsers();
    }

    @GetMapping
    public String index() {
        return "/SFILE5000";
    }

}