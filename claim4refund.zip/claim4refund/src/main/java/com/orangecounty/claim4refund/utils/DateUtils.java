package com.orangecounty.claim4refund.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Simple Date and time utils.
 */
public class DateUtils {

    public static java.sql.Date now_sql() {
        return new java.sql.Date(now_util().getTime());
    }

    public static java.util.Date now_util() {
        return new java.util.Date();
    }

    public static String toDayDateString(String format) {
        String result = "";
        try {
            DateFormat sdf = new SimpleDateFormat(format);
            result = sdf.format(new java.util.Date());
        } catch (Exception e) {
            LogUtils.error(e);
        }
        return result;
    }

    public static String format(java.util.Date date, String format) {
        String result = "";
        try {
            DateFormat sdf = new SimpleDateFormat(format);
            result = sdf.format(date);
        } catch (Exception e) {
            LogUtils.error(e);
        }
        return result;
    }

    public static java.util.Date toDate(String date, String format) throws ParseException {
        DateFormat sdf = new SimpleDateFormat(format);
        return sdf.parse(date);
    }
}
