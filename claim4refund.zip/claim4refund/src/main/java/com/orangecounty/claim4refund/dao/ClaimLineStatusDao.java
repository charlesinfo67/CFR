package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ClaimLineStatusMstr;

import java.util.List;

public interface ClaimLineStatusDao {
    void add(ClaimLineStatusMstr entity);

    List<ClaimLineStatusMstr> get();

    ClaimLineStatusMstr findById(String id);

    ClaimLineStatusMstr update(ClaimLineStatusMstr entity);

    void delete(String id);
}