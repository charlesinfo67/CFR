package com.orangecounty.claim4refund.mail;

import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.utils.LogUtils;
import com.sendgrid.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;

import java.io.IOException;

@Component
public class EmailService {
    @Autowired
    private Environment env;
    @Autowired
    public JavaMailSender emailSender;
    @Autowired
    private MailContentBuilder mailContentBuilder;
    @Autowired
    private MailGunService mailGun;

    public EmailService() {
    }

    @Async
    public void sendResetPassMail(String resetUrl, UserAccount user) {
        Context context = new Context();
        context.setVariable("resetUrl", resetUrl);
        context.setVariable("name", user.getBusinessName());
        context.setVariable("userName", user.getLoginId());
        String content = mailContentBuilder.buildResetPassMailTemplate(context);

        if (env.getProperty("mail.use.smtp", Boolean.class))
            sendMailUsingGmail("ClaimForRefund Reset Password", user.getEmail(), content);
        if(env.getProperty("mail.use.sendgrid", Boolean.class))
            sendMailUsingSendGrid("ClaimForRefund Reset Password", user.getEmail(), content);
        if (env.getProperty("mail.use.mailgun", Boolean.class))
            mailGun.sendHTML(String.format("ClaimForRefund Service <%s>", env.getProperty("mail.sender.address")), user.getEmail(), "ClaimForRefund Reset Password", content);
    }

    @Async
    public void sendDownloadLinkMail(String fileUrl, UserAccount user, String fileName) {
        Context context = new Context();
        context.setVariable("fileUrl", fileUrl);
        context.setVariable("name", user.getBusinessName());
        context.setVariable("fileName", fileName);
        String content = mailContentBuilder.buildDownloadLinkMailTemplate(context);

        if(env.getProperty("mail.use.smtp", Boolean.class))
            sendMailUsingGmail("ClaimForRefund Download File", user.getEmail(), content);
        if(env.getProperty("mail.use.sendgrid", Boolean.class))
            sendMailUsingSendGrid("ClaimForRefund Download File", user.getEmail(), content);
        if (env.getProperty("mail.use.mailgun", Boolean.class))
            mailGun.sendHTML(String.format("ClaimForRefund Service <%s>", env.getProperty("mail.sender.address")), user.getEmail(), "ClaimForRefund Download File", content);
    }

    @Async
    public void sendNotiMail(String message, UserAccount user) {
        Context context = new Context();
        context.setVariable("message", message);
        context.setVariable("userName", user.getBusinessName());
        String content = mailContentBuilder.buildNotiMailTemplate(context);

        if(env.getProperty("mail.use.smtp", Boolean.class))
            sendMailUsingGmail("ClaimForRefund Notification", user.getEmail(), content);
        if(env.getProperty("mail.use.sendgrid", Boolean.class))
            sendMailUsingSendGrid("ClaimForRefund Notification", user.getEmail(), content);
        if (env.getProperty("mail.use.mailgun", Boolean.class))
            mailGun.sendHTML(String.format("ClaimForRefund Service <%s>", env.getProperty("mail.sender.address")), user.getEmail(), "ClaimForRefund Notification", content);
    }

    private void sendMailUsingGmail(String subject, String mailto, String mailTemplate) {
        MimeMessagePreparator messagePreparator = mimeMessage -> {
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
            messageHelper.setFrom(env.getProperty("mail.sender.address"), "ClaimForRefund Service");
            messageHelper.setTo(mailto);
            messageHelper.setSubject(subject);

            messageHelper.setText(mailTemplate, true);
        };
        try {
            emailSender.send(messagePreparator);
        } catch (Exception ex) {
            LogUtils.error(ex);
        }
    }

    private void sendMailUsingSendGrid(String subject, String mailto,
            String mailTemplate) {
        Email from = new Email(env.getProperty("mail.sender.address"), "ClaimForRefund Service");
        Email to = new Email(mailto);
        Email replyTo = new Email(env.getProperty("mail.sender.address"), "ClaimForRefund Service");

        Content content = new Content("text/html", mailTemplate);
        Mail mail = new Mail(from, subject, to, content);
        mail.setReplyTo(replyTo);

        SendGrid sg = new SendGrid(env.getProperty("sendgrid.mail.api.key"));
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            Response response = sg.api(request);
        } catch (IOException e) {
            LogUtils.error(e);
        }

    }
}