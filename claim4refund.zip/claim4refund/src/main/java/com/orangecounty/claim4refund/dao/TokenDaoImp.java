package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Token;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class TokenDaoImp implements TokenDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(Token token) {
        Session session = sessionFactory.getCurrentSession();
        session.save(token);
    }

    @Override
    public List<Token> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from Token", Token.class).list();
    }

    @Override
    public Token findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Token.class, id);
    }

    @Override
    public Token findByValue(String value, int type) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Token> criteria = builder.createQuery(Token.class);
        Root<Token> root = criteria.from(Token.class);

        criteria.select(root).where(builder.and(builder.equal(root.get("value"), value),
                builder.equal(root.get("status"), 0),
                builder.equal(root.get("type"), type)));

        Query<Token> query = session.createQuery(criteria);
        List<Token> tokenList = query.list();

        Date today = new Date();
        for (Token token : tokenList) {
            // Check if token still valid in 24h
            Calendar c = Calendar.getInstance();
            c.setTime(token.getDate());
            c.add(Calendar.HOUR, 24);
            if (c.getTime().after(today)) {
                return token;
            }
        }

        return null;
    }

    @Override
    public Token update(Token token) {
        Session session = sessionFactory.getCurrentSession();
        session.update(token);
        return token;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        Token token = findById(id);
        session.delete(token);
    }

    @Override
    public Token check(String token, int type) {
        String[] tokens = token.split(":");
        if (tokens.length < 2)
            return null;
        String value = tokens[0];
        String tokenStr = tokens[1];

        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Token> criteria = builder.createQuery(Token.class);
        Root<Token> root = criteria.from(Token.class);

        criteria.select(root).where(builder.and(builder.equal(root.get("token"), tokenStr),
                builder.equal(root.get("value"), value),
                builder.equal(root.get("status"), 0),
                builder.equal(root.get("type"), type)));

        Query<Token> query = session.createQuery(criteria);
        List<Token> tokenList = query.list();

        Date today = new Date();
        if (tokenList.size() > 0) {
            // Check if token still valid in 24h
            Calendar c = Calendar.getInstance();
            c.setTime(tokenList.get(0).getDate());
            c.add(Calendar.HOUR, 24);
            if (c.getTime().after(today)) {
                return tokenList.get(0);
            }
        }

        return null;
    }
}
