package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimRefundStatusService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/dashboard/tracking")
public class SFILE7050 {
    @Autowired
    private ClaimService claimService;

    @Autowired
    private ClaimPropertiesService propertiesService;

    @Autowired
    private ClaimRefundStatusService statusService;

    @ModelAttribute("status")
    public List<ClaimRefundStatusMSTR> claimRefundStatusMstrs() {
        return statusService.get();
    }

    @GetMapping
    public String index(Model model) {
        List<ClaimProperties> properties;
        ClaimProperties propertyView;
        List<ClaimView> claims = new ArrayList<>();
        ClaimView claimView;
        for (Claim claim : claimService.findByUserId(CommonUtils.getUserAccount().getLoginId())) {
            claimView = new ClaimView();
            BeanUtils.copyProperties(claim, claimView);
            properties = new ArrayList<>();
            for (Properties property : propertiesService.findByClaimId(claim.getClaimId())) {
                propertyView = new ClaimProperties();
                BeanUtils.copyProperties(property, propertyView);
                properties.add(propertyView);
                break;
            }
            if (properties.isEmpty()) {
                properties.add(new ClaimProperties());
            }
            claimView.setProperties(properties);
            claims.add(claimView);
        }

        model.addAttribute("claims", claims);

        return "/SFILE7050";
    }

    @PostMapping
    public String search(Model model, @RequestParam(value = "cobrefno", required = true) String cobrefno) {
        List<ClaimProperties> properties = new ArrayList<>();
        ClaimProperties propertyView;
        ClaimView claimView;

        Optional<Claim> claim = Optional.ofNullable(claimService.findByCobrefno(cobrefno, Optional.ofNullable(CommonUtils.getUserAccount().getLoginId())));
        if (claim.isPresent()) {
            claimView = new ClaimView();
            BeanUtils.copyProperties(claim.get(), claimView);
            for (Properties property : propertiesService.findByClaimId(claim.get().getClaimId())) {
                propertyView = new ClaimProperties();
                BeanUtils.copyProperties(property, propertyView);
                properties.add(propertyView);
                break;
            }
            if (properties.isEmpty()) {
                properties.add(new ClaimProperties());
            }
            claimView.setProperties(properties);
            model.addAttribute("claim", claimView);
        }
        model.addAttribute("cobrefno", cobrefno);

        return "/SFILE7050";
    }

}