package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ClaimRefundStatusDaoImp implements ClaimRefundStatusDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(ClaimRefundStatusMSTR entity) {
        Session session = sessionFactory.getCurrentSession();
        session.save(entity);
    }

    @Override
    public List<ClaimRefundStatusMSTR> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from ClaimRefundStatusMSTR", ClaimRefundStatusMSTR.class).list();
    }

    @Override
    public ClaimRefundStatusMSTR findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(ClaimRefundStatusMSTR.class, id);
    }

    @Override
    public ClaimRefundStatusMSTR update(ClaimRefundStatusMSTR entity) {
        Session session = sessionFactory.getCurrentSession();
        session.update(entity);
        return entity;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        ClaimRefundStatusMSTR entity = findById(id);
        session.delete(entity);
    }
}
