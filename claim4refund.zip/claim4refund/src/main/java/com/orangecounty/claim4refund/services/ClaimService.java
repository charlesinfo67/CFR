package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.ClaimHistories;
import com.orangecounty.claim4refund.entities.GroupedCount;
import com.orangecounty.claim4refund.model.ClaimView;

import java.util.List;
import java.util.Optional;

public interface ClaimService {

    void create(Claim Claim);

    Claim update(Claim Claim);

    int updateInvalid();

    void delete(int claimId);

    List<Claim> get();

    Claim findById(int claimId);

    List<Claim> findByEmail(String email);

    List<Claim> findByUserId(String loginId);

    Claim findByCobrefno(String cobrefno, Optional<String> userId);

    long countNewClaims();

    long countClaims();

    List<GroupedCount> countByStatus(Integer... ids);

    List<GroupedCount> countPendingReview(int status, int month_s, int month_e);

    List<Claim> search(String cobrefno);

    String maxCOBREFNO(char prefix);

    List<ClaimHistories> findClaimHistoriesByClaimId(int claimId);

    static void setClaimCobrefno(ClaimView claim, ClaimService claimService) {
        if (claim.getClaimRefundTypeId() == Constants.CLAIM_REFUND_TYPE_1)  // Overpayment Of Taxes paid(T)
            claim.setCobrefno(claimService.maxCOBREFNO(Constants.COBREFNO_PREFIX_T));
        else                                                                // Penalties For Late payment(P)
            claim.setCobrefno(claimService.maxCOBREFNO(Constants.COBREFNO_PREFIX_P));
    }

    enum ClaimStatus {
        NOT_RECEIVED(1, "NOT RECEIVED"),
        INCOMPLETE(2, "INCOMPLETE"),
        DUPLICATE(3, "DUPLICATE"),
        PENDING_TTC_REVIEW(4, "PENDING TTC REVIEW"),
        PENDING_ASSESSOR_REVIEW(5, "PENDING ASSESSOR REVIEW"),
        WITHDRAWN(6, "WITHDRAWN"),
        VOID(7, "VOID"),
        INVALID(8, "INVALID"),
        CLOSED(9, "CLOSED"),
        SUBMITTED(10, "SUBMITTED"),
        CORRECTION(11, "CORRECTION");

        private int value;
        private String text;

        ClaimStatus(int value, String text) {
            this.value = value;
            this.text = text;
        }

        public static ClaimStatus getStatusByCode(int value) {
            for (ClaimStatus status : ClaimStatus.values()) {
                if (status.value == value) {
                    return status;
                }
            }
            return INVALID;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int code) {
            this.value = value;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }

    enum ClaimHistoriesStatus {
        CREATED(1, "CREATED"),
        UPDATED(2, "UPDATED"),
        DELETED(3, "DELETED");

        private int value;
        private String text;

        ClaimHistoriesStatus(int value, String text) {
            this.value = value;
            this.text = text;
        }

        public static ClaimHistoriesStatus getStatusByCode(int value) {
            for (ClaimHistoriesStatus status : ClaimHistoriesStatus.values()) {
                if (status.value == value) {
                    return status;
                }
            }
            return null;
        }

        public int getValue() {
            return value;
        }

        public String getText() {
            return text;
        }
    }

    ClaimView toView(Claim claim);

    List<Claim> search(int start, int length,
                       String cobrefno, Integer claimRefundTypeId, Integer[] status,
                       String receivedDate_s, String receivedDate_e,
                       String firstName, String lastName, String agentName);
}