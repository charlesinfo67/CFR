package com.orangecounty.claim4refund.model;

import com.orangecounty.claim4refund.constraint.FieldMatch;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@FieldMatch.List({
        @FieldMatch(first = "email", second = "confirmEmail", message = "The email fields must match")
})
public class UserEdit {
    @NotEmpty
    @Size(min = 6, max = 35)
    private String loginId;
    @Size(max = 35)
    private String businessName;
    @NotEmpty
    private String title;
    @NotEmpty
    @Size(max = 45)
    private String firstName;
    private String middleName;
    @NotEmpty
    @Size(max = 45)
    private String lastName;
    @NotEmpty
    @Size(max = 100)
    private String address1;
    @Size(max = 100)
    private String address2;
    @Size(max = 100)
    private String address3;
    @Size(max = 100)
    private String address4;
    @NotEmpty
    private String tel;
    private String alternateTel;
    @NotEmpty
    private String city;
    @Size(max = 10)
    private String country;
    @Size(max = 30)
    private String state;
    @NotEmpty
    @Size(max = 20)
    private String zip;
    @Email
    @NotEmpty
    @Size(max = 50)
    private String email;
    @Email
    @NotEmpty
    @Size(max = 50)
    private String confirmEmail;
    private String questionId;
    @NotEmpty
    @Size(max = 100)
    private String securityAnswer;
    @NotEmpty
    @Size(max = 500)
    private String purpose;

    public UserEdit() {
    }

    public String getLoginId() {
        return this.loginId;
    }

    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getAddress4() {
        return address4;
    }

    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAlternateTel() {
        return alternateTel;
    }

    public void setAlternateTel(String alternateTel) {
        this.alternateTel = alternateTel;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getConfirmEmail() {
        return confirmEmail;
    }

    public void setConfirmEmail(String confirmEmail) {
        this.confirmEmail = confirmEmail;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}
