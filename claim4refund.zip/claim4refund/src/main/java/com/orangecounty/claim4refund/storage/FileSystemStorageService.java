package com.orangecounty.claim4refund.storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class FileSystemStorageService implements StorageService {

    private final Path pdfLocation;

    @Autowired
    public FileSystemStorageService(StorageProperties properties) {
        this.pdfLocation = Paths.get(properties.getPdfPath());
    }

    @Override
    public void storePDF(File file) {
        String filename = StringUtils.cleanPath(file.getName());
        try {
//            if (file.getTemplateFile().isEmpty()) {
//                throw new StorageException("Failed to storePDF empty file " + filename);
//            }
            if (filename.contains("..")) {
                // This is a security check
                throw new StorageException(
                        "Cannot storePDF file with relative path outside current directory "
                                + filename);
            }
//            try (InputStream inputStream = new ) {
//                Files.copy(inputStream, this.pdfLocation.resolve(filename),
//                        StandardCopyOption.REPLACE_EXISTING);
//            }
        } catch (Exception e) {
            throw new StorageException("Failed to storePDF file " + filename, e);
        }
    }

    @Override
    public Path loadPDF(String filename) {
        return pdfLocation.resolve(filename);
    }

    @Override
    public Resource loadPDFAsResource(String filename) {
        try {
            Path file = loadPDF(filename);
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new StorageFileNotFoundException(
                        "Could not read file: " + filename);

            }
        } catch (MalformedURLException e) {
            throw new StorageFileNotFoundException("Could not read file: " + filename, e);
        }
    }

    @Override
    public Resource loadAsResource(String filename) {
        try {

            Path file = pdfLocation.resolve(filename);
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new StorageFileNotFoundException(
                        "Could not read file: " + filename);

            }
        } catch (MalformedURLException e) {
            throw new StorageFileNotFoundException("Could not read file: " + filename, e);
        }
    }


    @Override
    public void deleteAllPDF() {
        FileSystemUtils.deleteRecursively(pdfLocation.toFile());
    }

    @Override
    public void init() {
        try {
            Files.createDirectories(pdfLocation);
        } catch (IOException e) {
            throw new StorageException("Could not initialize storage", e);
        }
    }
}
