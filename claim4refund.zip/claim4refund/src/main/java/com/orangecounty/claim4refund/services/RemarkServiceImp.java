package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.RemarkDao;
import com.orangecounty.claim4refund.dao.RemarkHistoriesDao;
import com.orangecounty.claim4refund.entities.Remark;
import com.orangecounty.claim4refund.entities.RemarkHistories;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RemarkServiceImp implements RemarkService {
    @Autowired
    RemarkDao claimRefundStatusDao;
    @Autowired
    RemarkHistoriesDao remarkHistoriesDao;

    @Override
    public List<Remark> get() {
        return claimRefundStatusDao.get();
    }

    @Override
    public Remark findById(String id) {
        return claimRefundStatusDao.findById(id);
    }

    @Override
    public Remark findByClaimId(int claimId) {
        return claimRefundStatusDao.findByClaimId(claimId);
    }
    @Override
    public void create(Remark entity) {
        claimRefundStatusDao.add(entity);
        RemarkHistories remarkHistories = new RemarkHistories();
        BeanUtils.copyProperties(entity,remarkHistories);
        remarkHistories.setStatus(RemarkHistoryStatus.CREATED.getCode());
        remarkHistoriesDao.add(remarkHistories);
    }

    @Override
    public void delete(String id) {
        Remark remark = claimRefundStatusDao.findById(id);
        claimRefundStatusDao.delete(id);

        RemarkHistories remarkHistories = new RemarkHistories();
        BeanUtils.copyProperties(remark,remarkHistories);
        remarkHistories.setStatus(RemarkHistoryStatus.DELETED.getCode());
        remarkHistoriesDao.add(remarkHistories);
    }

    @Override
    public List<RemarkHistories> findRemarkHistoriesByClaimId(int claimId) {
        return remarkHistoriesDao.findByClaimId(claimId);
    }

    @Override
    public Remark update(Remark entity) {
        Remark update = claimRefundStatusDao.update(entity);

        RemarkHistories remarkHistories = new RemarkHistories();
        BeanUtils.copyProperties(update,remarkHistories);
        remarkHistories.setStatus(RemarkHistoryStatus.UPDATED.getCode());
        remarkHistoriesDao.add(remarkHistories);
        return update;
    }
}