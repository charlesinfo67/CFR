package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.utils.CommonUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SFILE1000 {

    @GetMapping("/login")
    public String login(@RequestParam(required = false) String loginId,
                        @RequestParam(required = false) String error, final Model model) {

        if (CommonUtils.isLogged()) {
            return "redirect:/dashboard";
        }

        if (error != null && !error.isEmpty()) {
            if (error.equals("1")) {
                model.addAttribute("message", "Incorrect ID or password!");
            }
            if (error.equals("2")) {
                model.addAttribute("message", "User not found by ID: " + loginId);
            }
        }
        return "/SFILE1000";
    }
}