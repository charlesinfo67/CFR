package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.reports.ReportService;
import com.orangecounty.claim4refund.services.*;
import com.orangecounty.claim4refund.storage.StorageFileNotFoundException;
import com.orangecounty.claim4refund.storage.StorageService;
import com.orangecounty.claim4refund.utils.FilenameUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.net.URLConnection;

@Controller
@RequestMapping("/admin/claimprinter")
public class ClaimPrinter {
    private final StorageService storageService;
    @Autowired
    private UserService userService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private StateService stateService;
    @Autowired
    private EmailService emailService;
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;
    @Autowired
    private RemarkService remarkService;
    @Autowired
    private ManualReviewService manualReviewService;
    @Autowired
    private ReportService reportService;

    @Autowired
    public ClaimPrinter(StorageService storageService) {
        this.storageService = storageService;
    }

    @GetMapping
    public String switcher(@RequestParam Integer id, @RequestParam String mode) {
        Claim claim = claimService.findById(id);

        if (claim == null)
            return "/error/404";

        return "redirect:/login";
    }

    @GetMapping("/preview/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> preview(@PathVariable String filename) {
        String fileExtension = FilenameUtils.getFileExtension(filename);
        Resource file;

        switch (fileExtension) {
            case ".pdf":
                file = storageService.loadPDFAsResource(filename);
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + file.getFilename() + "\"").body(file);
            case ".docx":
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + file.getFilename() + "\"").body(file);
            default:
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf(URLConnection.guessContentTypeFromName(filename)))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + file.getFilename() + "\"").body(file);
        }
    }

    @GetMapping("/download/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> download(@PathVariable String filename) {
        String fileExtension = FilenameUtils.getFileExtension(filename);
        Resource file;

        switch (fileExtension) {
            case ".pdf":
                file = storageService.loadPDFAsResource(filename);
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + file.getFilename() + "\"").body(file);
            case ".docx":
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
            default:
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf(URLConnection.guessContentTypeFromName(filename)))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
        }
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
        LogUtils.error(exc);
        return ResponseEntity.notFound().build();
    }
}