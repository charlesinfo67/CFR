package com.orangecounty.claim4refund.model;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.constraint.FieldMatch;
import com.orangecounty.claim4refund.utils.DateUtils;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@FieldMatch.List({
        @FieldMatch(first = "email", second = "confirmEmail", message = "The email fields must match")
})
public class ClaimView {
    @NotEmpty(message = "Please select Applicant Type.")
    @Size(max = 1)
    private String appType;
    private int claimId;
    private String cobrefno;
    @Size(max = 45)
    private String firstName;
    private String middleName;
    @Size(max = 45)
    private String lastName;
    @Size(max = 100)
    private String agentName;
    @NotEmpty(message = "Please input Primary Phone.")
    private String primaryPhone;
    private String alternatePhone1;
    private int claimRefundTypeId;
    private int claimStatusId;
    private Date receivedDate;
    private Date followUpDate;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private int claimLetterType;
    private Integer conversionKey;
    private boolean isCompany;
    @Size(max = 50)
    private String companyName;
    private boolean isPrimaryPhoneUsa;
    private boolean isAlternatePhone1Usa;
    private String primaryPhoneExt;
    private String alternatePhone1Ext;
    @NotEmpty(message = "Please input Address 1.")
    @Size(max = 100)
    private String address1;
    @Size(max = 50)
    private String address2;
    @Size(max = 50)
    private String address3;
    @Size(max = 50)
    private String address4;
    @NotEmpty(message = "Please input City.")
    @Size(max = 70)
    private String city;
    @Size(max = 10)
    private String country;
    @Size(max = 30)
    private String state;
    @NotEmpty(message = "Please input Zip.")
    @Size(max = 25)
    private String zip;
    private String zipExtension;
    @Email
    @NotEmpty(message = "Please input Email.")
    @Size(max = 50)
    private String email;
    @Email
    @NotEmpty(message = "Please input Confirm Email.")
    @Size(max = 50)
    private String confirmEmail;
    @NotEmpty(message = "Please input Executed.")
    private String executed;
    @NotEmpty(message = "Please input By.")
    private String by;
    private boolean hasDisagree;
    private boolean hasOverpaid;
    @NotEmpty(message = "Please input Refund Reasons.")
    @Size(max = 150)
    private String refundReasons;
    private boolean backupDoc;
    @Size(max = 300)
    private String internalRemarks;
    private String refundType;
    private List<ClaimProperties> properties;
    private RemarkView remark;
    private ManualReviewView manualReview;

    public ClaimView() {
        claimRefundTypeId = Constants.CLAIM_REFUND_TYPE_1;
        refundType = Constants.REFUND_TYPE_PARTIAL;
        properties = new ArrayList<>();
        receivedDate = DateUtils.now_sql();
        followUpDate = DateUtils.now_sql();
    }

    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public String getCobrefno() {
        return cobrefno;
    }

    public void setCobrefno(String cobrefno) {
        this.cobrefno = cobrefno;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getPrimaryPhone() {
        return primaryPhone;
    }

    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public String getAlternatePhone1() {
        return alternatePhone1;
    }

    public void setAlternatePhone1(String alternatePhone1) {
        this.alternatePhone1 = alternatePhone1;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getClaimRefundTypeId() {
        return claimRefundTypeId;
    }

    public void setClaimRefundTypeId(int claimRefundTypeId) {
        this.claimRefundTypeId = claimRefundTypeId;
    }

    public int getClaimStatusId() {
        return claimStatusId;
    }

    public void setClaimStatusId(int claimStatusId) {
        this.claimStatusId = claimStatusId;
    }

    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    public Date getFollowUpDate() {
        return followUpDate;
    }

    public void setFollowUpDate(Date followUpDate) {
        this.followUpDate = followUpDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public int getClaimLetterType() {
        return claimLetterType;
    }

    public void setClaimLetterType(int claimLetterType) {
        this.claimLetterType = claimLetterType;
    }

    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    public boolean isCompany() {
        return isCompany;
    }

    public void setCompany(boolean company) {
        isCompany = company;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public boolean getIsPrimaryPhoneUsa() {
        return isPrimaryPhoneUsa;
    }

    public void setIsPrimaryPhoneUsa(boolean primaryPhoneUsa) {
        isPrimaryPhoneUsa = primaryPhoneUsa;
    }

    public boolean getIsAlternatePhone1Usa() {
        return isAlternatePhone1Usa;
    }

    public void setIsAlternatePhone1Usa(boolean alternatePhone1Usa) {
        isAlternatePhone1Usa = alternatePhone1Usa;
    }

    public String getPrimaryPhoneExt() {
        return primaryPhoneExt;
    }

    public void setPrimaryPhoneExt(String primaryPhoneExt) {
        this.primaryPhoneExt = primaryPhoneExt;
    }

    public String getAlternatePhone1Ext() {
        return alternatePhone1Ext;
    }

    public void setAlternatePhone1Ext(String alternatePhone1Ext) {
        this.alternatePhone1Ext = alternatePhone1Ext;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getAddress4() {
        return address4;
    }

    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getZipExtension() {
        return zipExtension;
    }

    public void setZipExtension(String zipExtension) {
        this.zipExtension = zipExtension;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getExecuted() {
        return executed;
    }

    public void setExecuted(String executed) {
        this.executed = executed;
    }

    public String getBy() {
        return by;
    }

    public void setBy(String by) {
        this.by = by;
    }

    public boolean getHasDisagree() {
        return hasDisagree;
    }

    public void setHasDisagree(boolean hasDisagree) {
        this.hasDisagree = hasDisagree;
    }

    public boolean getHasOverpaid() {
        return hasOverpaid;
    }

    public void setHasOverpaid(boolean hasOverpaid) {
        this.hasOverpaid = hasOverpaid;
    }

    public String getRefundReasons() {
        return refundReasons;
    }

    public void setRefundReasons(String refundReasons) {
        this.refundReasons = refundReasons;
    }

    public boolean getBackupDoc() {
        return backupDoc;
    }

    public void setBackupDoc(boolean backupDoc) {
        this.backupDoc = backupDoc;
    }

    public String getInternalRemarks() {
        return internalRemarks;
    }

    public void setInternalRemarks(String internalRemarks) {
        this.internalRemarks = internalRemarks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClaimView that = (ClaimView) o;
        return claimId == that.claimId &&
                claimRefundTypeId == that.claimRefundTypeId &&
                claimStatusId == that.claimStatusId &&
                claimLetterType == that.claimLetterType &&
                isCompany == that.isCompany &&
                isPrimaryPhoneUsa == that.isPrimaryPhoneUsa &&
                isAlternatePhone1Usa == that.isAlternatePhone1Usa &&
                Objects.equals(cobrefno, that.cobrefno) &&
                Objects.equals(firstName, that.firstName) &&
                Objects.equals(middleName, that.middleName) &&
                Objects.equals(lastName, that.lastName) &&
                Objects.equals(agentName, that.agentName) &&
                Objects.equals(primaryPhone, that.primaryPhone) &&
                Objects.equals(alternatePhone1, that.alternatePhone1) &&
                Objects.equals(email, that.email) &&
                Objects.equals(receivedDate, that.receivedDate) &&
                Objects.equals(followUpDate, that.followUpDate) &&
                Objects.equals(createdBy, that.createdBy) &&
                Objects.equals(createdDate, that.createdDate) &&
                Objects.equals(updatedBy, that.updatedBy) &&
                Objects.equals(updatedDate, that.updatedDate) &&
                Objects.equals(conversionKey, that.conversionKey) &&
                Objects.equals(companyName, that.companyName) &&
                Objects.equals(primaryPhoneExt, that.primaryPhoneExt) &&
                Objects.equals(alternatePhone1Ext, that.alternatePhone1Ext) &&
                Objects.equals(address1, that.address1) &&
                Objects.equals(address2, that.address2) &&
                Objects.equals(address3, that.address3) &&
                Objects.equals(address4, that.address4) &&
                Objects.equals(city, that.city) &&
                Objects.equals(country, that.country) &&
                Objects.equals(zip, that.zip) &&
                Objects.equals(zipExtension, that.zipExtension) &&
                Objects.equals(state, that.state) &&
                Objects.equals(executed, that.executed) &&
                Objects.equals(by, that.by) &&
                Objects.equals(hasDisagree, that.hasDisagree) &&
                Objects.equals(hasOverpaid, that.hasOverpaid) &&
                Objects.equals(refundReasons, that.refundReasons) &&
                Objects.equals(backupDoc, that.backupDoc) &&
                Objects.equals(internalRemarks, that.internalRemarks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(claimId, cobrefno, firstName, middleName, lastName, agentName, primaryPhone, alternatePhone1, email, claimRefundTypeId, claimStatusId, receivedDate, followUpDate, createdBy, createdDate, updatedBy, updatedDate, claimLetterType, conversionKey, isCompany, companyName, isPrimaryPhoneUsa, isAlternatePhone1Usa, primaryPhoneExt, alternatePhone1Ext, address1, address2, address3, address4, city, country, zip, zipExtension, state, executed, by, hasDisagree, hasOverpaid, refundReasons, backupDoc, internalRemarks);
    }

    public void addProperties(ClaimProperties claimProperties) {
        this.properties.add(claimProperties);
    }

    public void removeProperties(int index) {
        if (this.properties.size() > index)
            this.properties.remove(index);
    }

    public List<ClaimProperties> getProperties() {
        return properties;
    }

    public void setProperties(List<ClaimProperties> properties) {
        this.properties = properties;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public String getRefundType() {
        return refundType;
    }

    public void setRefundType(String refundType) {
        this.refundType = refundType;
    }

    public String getConfirmEmail() {
        return confirmEmail;
    }

    public void setConfirmEmail(String confirmEmail) {
        this.confirmEmail = confirmEmail;
    }

    public RemarkView getRemark() {
        return remark;
    }

    public void setRemark(RemarkView remark) {
        this.remark = remark;
    }

    public ManualReviewView getManualReview() {
        return manualReview;
    }

    public void setManualReview(ManualReviewView manualReview) {
        this.manualReview = manualReview;
    }
}
