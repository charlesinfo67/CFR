package com.orangecounty.claim4refund.entities;

import javax.persistence.*;

@Entity
@Table(name = "State")
public class State implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String name;

    public State() {

    }

    @Id
    @Column(name = "StateID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "StateName", length = 100)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
