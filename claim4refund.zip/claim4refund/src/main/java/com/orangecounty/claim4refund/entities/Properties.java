package com.orangecounty.claim4refund.entities;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "Properties", schema = "dbo", catalog = "CFRDB")
public class Properties {
    private int propertyId;
    private int claimId;
    private String appealNo;
    private String apn;
    private String apnSuffix;
    private String assessmentNo;
    private BigDecimal claimAmount;
    private Integer taxYear;
    private Integer claimLineStatusId;
    private boolean isTaxesPaid;
    private BigDecimal amountApproved;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private boolean isActive;
    private Integer conversionKey;
    private Date dateSentToTtcForRefundCheck;

    @Id
    @Column(name = "PropertyID", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    @Basic
    @Column(name = "ClaimID", nullable = false)
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    @Basic
    @Column(name = "AppealNO", nullable = true, length = 25)
    public String getAppealNo() {
        return appealNo;
    }

    public void setAppealNo(String appealNo) {
        this.appealNo = appealNo;
    }

    @Basic
    @Column(name = "APN", nullable = true, length = 15)
    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    @Basic
    @Column(name = "APNSuffix", nullable = true, length = 4)
    public String getApnSuffix() {
        return apnSuffix;
    }

    public void setApnSuffix(String apnSuffix) {
        this.apnSuffix = apnSuffix;
    }

    @Basic
    @Column(name = "AssessmentNO", nullable = true, length = 15)
    public String getAssessmentNo() {
        return assessmentNo;
    }

    public void setAssessmentNo(String assessmentNo) {
        this.assessmentNo = assessmentNo;
    }

    @Basic
    @Column(name = "ClaimAmount", nullable = true)
    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    @Basic
    @Column(name = "TaxYear", nullable = true)
    public Integer getTaxYear() {
        return taxYear;
    }

    public void setTaxYear(Integer taxYear) {
        this.taxYear = taxYear;
    }

    @Basic
    @Column(name = "ClaimLineStatusID", nullable = true)
    public Integer getClaimLineStatusId() {
        return claimLineStatusId;
    }

    public void setClaimLineStatusId(Integer claimLineStatusId) {
        this.claimLineStatusId = claimLineStatusId;
    }

    @Basic
    @Column(name = "IsTaxesPaid", nullable = true)
    public boolean getTaxesPaid() {
        return isTaxesPaid;
    }

    public void setTaxesPaid(boolean taxesPaid) {
        isTaxesPaid = taxesPaid;
    }

    @Basic
    @Column(name = "AmountApproved", nullable = true)
    public BigDecimal getAmountApproved() {
        return amountApproved;
    }

    public void setAmountApproved(BigDecimal amountApproved) {
        this.amountApproved = amountApproved;
    }

    @Basic
    @Column(name = "CreatedBy", nullable = false, length = 50)
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Basic
    @Column(name = "CreatedDate", nullable = false)
    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    @Basic
    @Column(name = "UpdatedBy", nullable = true, length = 50)
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Basic
    @Column(name = "UpdatedDate", nullable = true)
    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Basic
    @Column(name = "RV", nullable = false)
    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }

    @Basic
    @Column(name = "IsActive", nullable = false)
    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Basic
    @Column(name = "Conversion_Key", nullable = true)
    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    @Basic
    @Column(name = "DateSentToTTCForRefundCheck", nullable = true)
    public Date getDateSentToTtcForRefundCheck() {
        return dateSentToTtcForRefundCheck;
    }

    public void setDateSentToTtcForRefundCheck(Date dateSentToTtcForRefundCheck) {
        this.dateSentToTtcForRefundCheck = dateSentToTtcForRefundCheck;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Properties that = (Properties) o;
        return propertyId == that.propertyId &&
                claimId == that.claimId &&
                isActive == that.isActive &&
                Objects.equals(appealNo, that.appealNo) &&
                Objects.equals(apn, that.apn) &&
                Objects.equals(apnSuffix, that.apnSuffix) &&
                Objects.equals(assessmentNo, that.assessmentNo) &&
                Objects.equals(claimAmount, that.claimAmount) &&
                Objects.equals(taxYear, that.taxYear) &&
                Objects.equals(claimLineStatusId, that.claimLineStatusId) &&
                Objects.equals(isTaxesPaid, that.isTaxesPaid) &&
                Objects.equals(amountApproved, that.amountApproved) &&
                Objects.equals(createdBy, that.createdBy) &&
                Objects.equals(createdDate, that.createdDate) &&
                Objects.equals(updatedBy, that.updatedBy) &&
                Objects.equals(updatedDate, that.updatedDate) &&
                Objects.equals(rv, that.rv) &&
                Objects.equals(conversionKey, that.conversionKey) &&
                Objects.equals(dateSentToTtcForRefundCheck, that.dateSentToTtcForRefundCheck);
    }

    @Override
    public int hashCode() {
        return Objects.hash(propertyId, claimId, appealNo, apn, apnSuffix, assessmentNo, claimAmount, taxYear, claimLineStatusId, isTaxesPaid, amountApproved, createdBy, createdDate, updatedBy, updatedDate, rv, isActive, conversionKey, dateSentToTtcForRefundCheck);
    }
}
