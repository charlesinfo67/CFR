package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ManualReview;

import java.util.List;

public interface ManualReviewDao {
    void add(ManualReview entity);

    List<ManualReview> get();

    ManualReview findById(int id);

    ManualReview findByClaimId(int claimId);

    ManualReview update(ManualReview entity);

    void delete(int id);
}