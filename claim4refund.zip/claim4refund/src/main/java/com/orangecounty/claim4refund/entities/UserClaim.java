package com.orangecounty.claim4refund.entities;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "User_Claim", schema = "dbo", catalog = "CFRDB")
public class UserClaim {
    private String userId;
    private int claimId;
    private int id;

    @Id
    @Column(name = "ID", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "UserID", nullable = false, length = 35)
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "ClaimID", nullable = false)
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserClaim that = (UserClaim) o;
        return claimId == that.claimId &&
                Objects.equals(userId, that.userId);
    }

    @Override
    public int hashCode() {

        return Objects.hash(userId, claimId);
    }
}
