package com.orangecounty.claim4refund.entities;

import javax.persistence.*;

@Entity
@Table(name = "SecQuestion")
public class SecQuestion implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String question;

    public SecQuestion() {

    }

    @Id
    @Column(name = "QuestionID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id; 
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "Question", length = 200)
    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
