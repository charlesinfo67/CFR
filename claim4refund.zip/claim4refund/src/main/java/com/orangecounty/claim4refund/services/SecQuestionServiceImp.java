package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.SecQuestionDao;
import com.orangecounty.claim4refund.entities.SecQuestion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SecQuestionServiceImp implements SecQuestionService {
    @Autowired
    SecQuestionDao secQuestionDao;

    @Override
    public List<SecQuestion> get() {
        return secQuestionDao.get();
    }

    @Override
    public SecQuestion findById(String id) {
        return secQuestionDao.findById(id);
    }

    @Override
    public void create(SecQuestion question) {
        secQuestionDao.add(question);
    }

    @Override
    public void delete(String id) {
        secQuestionDao.delete(id);
    }

    @Override
    public SecQuestion update(SecQuestion question) {
        return secQuestionDao.update(question);
    }
}