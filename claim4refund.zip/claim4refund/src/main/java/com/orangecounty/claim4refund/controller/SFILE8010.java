package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.Country;
import com.orangecounty.claim4refund.entities.State;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.services.CountryService;
import com.orangecounty.claim4refund.services.StateService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin/claimview")
public class SFILE8010 {
    @Autowired
    private ClaimService claimService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private StateService stateService;

    @ModelAttribute("countries")
    public List<Country> countries() {
        return countryService.get();
    }

    @ModelAttribute("states")
    public List<State> states() {
        return stateService.get();
    }

    @GetMapping
    public String index(@RequestParam(required = false, defaultValue = "0") Integer id,
                        @RequestParam(required = false, defaultValue = "") String cobrefno,
                        final Model model) {
        ClaimView claimView = null;
        Claim claim = null;

        claim = claimService.findById(id);
        if (claim == null)
            claim = claimService.findByCobrefno(cobrefno, Optional.empty());
        if (claim == null)
            return "/error/404";

        claimView = claimService.toView(claim);
        model.addAttribute("claim", claimView);
        return "/SFILE8010";
    }

    @PostMapping
    public String edit(@ModelAttribute("userEdit") @Valid ClaimView claimView,
                       BindingResult result) {
        String url = "/SFILE8011";
        Claim claim;
        try {
            if (!result.hasErrors()) {
                claim = claimService.findById(claimView.getClaimId());
                BeanUtils.copyProperties(claimView, claim);

                claimService.update(claim);
                url = "redirect:/admin/claimview?id=" + claim.getClaimId();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }
}
