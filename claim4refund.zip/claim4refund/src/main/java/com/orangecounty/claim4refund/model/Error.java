package com.orangecounty.claim4refund.model;

public class Error {
    private int errorCode;
    private String errorMsg;
    private String itemId;
}
