package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.State;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class StateDaoImp implements StateDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(State state) {
        Session session = sessionFactory.getCurrentSession();
        session.save(state);
    }

    @Override
    public List<State> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from State", State.class).list();
    }

    @Override
    public State findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(State.class, id);
    }

    @Override
    public State update(State state) {
        Session session = sessionFactory.getCurrentSession();
        session.update(state);
        return state;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        State state = findById(id);
        session.delete(state);
    }
}
