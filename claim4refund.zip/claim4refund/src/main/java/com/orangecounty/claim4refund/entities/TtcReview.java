package com.orangecounty.claim4refund.entities;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "TTCReview", schema = "dbo", catalog = "CFRDB")
public class TtcReview {
    private int id;
    private int claimId;
    private Date dateSentToTtc;
    private Date dateReviewedByTtc;
    private Date dateCertifiedByTtc;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private Integer conversionKey;
    private String reviewedBy;

    @Id
    @Column(name = "ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "ClaimID", nullable = false)
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    @Basic
    @Column(name = "DateSentToTTC", nullable = true)
    public java.sql.Date getDateSentToTtc() {
        return dateSentToTtc;
    }

    public void setDateSentToTtc(java.sql.Date dateSentToTtc) {
        this.dateSentToTtc = dateSentToTtc;
    }

    @Basic
    @Column(name = "DateReviewedByTTC", nullable = true)
    public java.sql.Date getDateReviewedByTtc() {
        return dateReviewedByTtc;
    }

    public void setDateReviewedByTtc(java.sql.Date dateReviewedByTtc) {
        this.dateReviewedByTtc = dateReviewedByTtc;
    }

    @Basic
    @Column(name = "DateCertifiedByTTC", nullable = true)
    public java.sql.Date getDateCertifiedByTtc() {
        return dateCertifiedByTtc;
    }

    public void setDateCertifiedByTtc(java.sql.Date dateCertifiedByTtc) {
        this.dateCertifiedByTtc = dateCertifiedByTtc;
    }

    @Basic
    @Column(name = "CreatedBy", nullable = false, length = 50)
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Basic
    @Column(name = "CreatedDate", nullable = false)
    public java.sql.Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(java.sql.Date createdDate) {
        this.createdDate = createdDate;
    }

    @Basic
    @Column(name = "UpdatedBy", nullable = true, length = 50)
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Basic
    @Column(name = "UpdatedDate", nullable = true)
    public java.sql.Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(java.sql.Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Basic
    @Column(name = "RV", nullable = false)
    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }

    @Basic
    @Column(name = "Conversion_Key", nullable = true)
    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    @Basic
    @Column(name = "ReviewedBy", nullable = true, length = 50)
    public String getReviewedBy() {
        return reviewedBy;
    }

    public void setReviewedBy(String reviewedBy) {
        this.reviewedBy = reviewedBy;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        TtcReview that = (TtcReview) object;

        if (claimId != that.claimId) return false;
        if (dateSentToTtc != null ? !dateSentToTtc.equals(that.dateSentToTtc) : that.dateSentToTtc != null)
            return false;
        if (dateReviewedByTtc != null ? !dateReviewedByTtc.equals(that.dateReviewedByTtc) : that.dateReviewedByTtc != null)
            return false;
        if (dateCertifiedByTtc != null ? !dateCertifiedByTtc.equals(that.dateCertifiedByTtc) : that.dateCertifiedByTtc != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (updatedBy != null ? !updatedBy.equals(that.updatedBy) : that.updatedBy != null) return false;
        if (updatedDate != null ? !updatedDate.equals(that.updatedDate) : that.updatedDate != null) return false;
        if (rv != null ? !rv.equals(that.rv) : that.rv != null) return false;
        if (conversionKey != null ? !conversionKey.equals(that.conversionKey) : that.conversionKey != null)
            return false;
        return reviewedBy != null ? reviewedBy.equals(that.reviewedBy) : that.reviewedBy == null;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + claimId;
        result = 31 * result + (dateSentToTtc != null ? dateSentToTtc.hashCode() : 0);
        result = 31 * result + (dateReviewedByTtc != null ? dateReviewedByTtc.hashCode() : 0);
        result = 31 * result + (dateCertifiedByTtc != null ? dateCertifiedByTtc.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (updatedBy != null ? updatedBy.hashCode() : 0);
        result = 31 * result + (updatedDate != null ? updatedDate.hashCode() : 0);
        result = 31 * result + (rv != null ? rv.hashCode() : 0);
        result = 31 * result + (conversionKey != null ? conversionKey.hashCode() : 0);
        result = 31 * result + (reviewedBy != null ? reviewedBy.hashCode() : 0);
        return result;
    }
}
