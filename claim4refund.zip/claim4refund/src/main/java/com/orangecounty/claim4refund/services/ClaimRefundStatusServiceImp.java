package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.ClaimRefundStatusDao;
import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@CacheConfig(cacheNames = {"status"})
@Transactional
public class ClaimRefundStatusServiceImp implements ClaimRefundStatusService {
    @Autowired
    ClaimRefundStatusDao claimRefundStatusDao;

    @Override
    @Cacheable
    public List<ClaimRefundStatusMSTR> get() {
        return claimRefundStatusDao.get();
    }

    @Override
    public ClaimRefundStatusMSTR findById(String id) {
        return claimRefundStatusDao.findById(id);
    }

    @Override
    public void create(ClaimRefundStatusMSTR entity) {
        claimRefundStatusDao.add(entity);
    }

    @Override
    public void delete(String id) {
        claimRefundStatusDao.delete(id);
    }

    @Override
    public ClaimRefundStatusMSTR update(ClaimRefundStatusMSTR entity) {
        return claimRefundStatusDao.update(entity);
    }
}