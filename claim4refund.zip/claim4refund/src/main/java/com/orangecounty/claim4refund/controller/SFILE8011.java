package com.orangecounty.claim4refund.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.entities.*;
import com.orangecounty.claim4refund.model.CFRJsonRespone;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.model.RemarkView;
import com.orangecounty.claim4refund.reports.ReportService;
import com.orangecounty.claim4refund.services.*;
import com.orangecounty.claim4refund.storage.StorageFileNotFoundException;
import com.orangecounty.claim4refund.storage.StorageService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.DateUtils;
import com.orangecounty.claim4refund.utils.FilenameUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/admin/claimedit")
public class SFILE8011 {
    private final StorageService storageService;
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;
    @Autowired
    private RemarkService remarkService;
    @Autowired
    private ManualReviewService manualReviewService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private StateService stateService;
    @Autowired
    private ReportService reportService;
    @Autowired
    private ClaimLineStatusService claimLineStatusService;

    @Autowired
    public SFILE8011(StorageService storageService) {
        this.storageService = storageService;
    }

    @ModelAttribute("linestatus")
    public List<ClaimLineStatusMstr> linestatus() {
        return claimLineStatusService.get();
    }

    @ModelAttribute("countries")
    public List<Country> countries() {
        return countryService.get();
    }

    @ModelAttribute("states")
    public List<State> states() {
        return stateService.get();
    }

    @GetMapping()
    public String index(@RequestParam Integer id, final Model model) {
        ClaimView claimView = null;

        Claim claim = claimService.findById(id);
        if (claim == null)
            return "/error/404";

        switch (ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId())) {
            case WITHDRAWN:
            case VOID:
            case INVALID:
            case CLOSED:
                model.addAttribute("message", "Record with status \"" + ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId()).getText() + "\" cannot be updated.");
                break;
            default:
                claimView = claimService.toView(claim);
                break;
        }

        model.addAttribute("claim", claimView);

        return "/SFILE8011";
    }

    @PostMapping(params = "save")
    public String save(@ModelAttribute("claim") @Valid ClaimView claim,
                       BindingResult result,
                       @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE8011";

        try {
            updateClaim(result, claim, allowdup, "save");
            if (!result.hasErrors()) {
                url = "redirect:/admin/claimview?id=" + claim.getClaimId();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "duplicate")
    public String duplicate(@ModelAttribute("claim") @Valid ClaimView claim,
                            BindingResult result,
                            @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE8011";

        try {
            Claim updateClaim = updateClaim(result, claim, allowdup, "duplicate");
            if (!result.hasErrors()) {
                url = new StringBuilder("redirect:/admin/claimedit?success=true")
                        .append("&claimStatus=").append(updateClaim.getClaimStatusId())
                        .append("&id=").append(updateClaim.getClaimId())
                        .append("&followUpDate=").append(URLEncoder
                                .encode(DateUtils.format(updateClaim.getFollowUpDate(), "yyyy-MM-dd"), "UTF-8"))
                        .toString();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "incomplete")
    public String incomplete(@ModelAttribute("claim") @Valid ClaimView claim,
                             BindingResult result,
                             @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE8011";

        try {
            Claim updateClaim = updateClaim(result, claim, allowdup, "incomplete");
            if (!result.hasErrors()) {
                url = new StringBuilder("redirect:/admin/claimedit?success=true")
                        .append("&claimStatus=").append(updateClaim.getClaimStatusId())
                        .append("&id=").append(updateClaim.getClaimId())
                        .append("&followUpDate=").append(URLEncoder
                                .encode(DateUtils.format(updateClaim.getFollowUpDate(), "yyyy-MM-dd"), "UTF-8"))
                        .toString();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "correction")
    public String correction(@ModelAttribute("claim") @Valid ClaimView claim,
                             BindingResult result,
                             @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE8011";

        try {
            Claim updateClaim = updateClaim(result, claim, allowdup, "correction");
            if (!result.hasErrors()) {
                url = new StringBuilder("redirect:/admin/claimedit?success=true")
                        .append("&claimStatus=").append(ClaimService.ClaimStatus.CORRECTION.getValue())
                        .append("&id=").append(updateClaim.getClaimId())
                        .append("&followUpDate=").append(URLEncoder
                                .encode(DateUtils.format(updateClaim.getFollowUpDate(), "yyyy-MM-dd"), "UTF-8"))
                        .toString();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "void")
    public String saveVoid(@ModelAttribute("claim") @Valid ClaimView claim,
                           BindingResult result,
                           @RequestParam(required = false, defaultValue = "false") boolean allowdup) {

        String url = "/SFILE8011";

        try {
            updateClaim(result, claim, allowdup, "void");
            if (!result.hasErrors()) {
                url = "redirect:/admin/claimview?id=" + claim.getClaimId();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "withdrawn")
    public String withdrawn(@ModelAttribute("claim") @Valid ClaimView claim,
                            BindingResult result,
                            @RequestParam(required = false, defaultValue = "false") boolean allowdup) {

        String url = "/SFILE8011";

        try {
            updateClaim(result, claim, allowdup, "withdrawn");
            if (!result.hasErrors()) {
                url = "redirect:/admin/claimview?id=" + claim.getClaimId();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    @PostMapping(params = "finalize")
    public String finalize(@ModelAttribute("claim") @Valid ClaimView claim,
                           BindingResult result,
                           @RequestParam(required = false, defaultValue = "false") boolean allowdup) {

        String url = "/SFILE8011";

        try {
            updateClaim(result, claim, allowdup, "finalize");
            if (!result.hasErrors()) {
                url = "redirect:/admin/claimview?id=" + claim.getClaimId();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }


    @PostMapping(params = "acknowledgment")
    public String acknowledgment(@ModelAttribute("claim") @Valid ClaimView claim,
                                 BindingResult result,
                                 @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE8011";

        try {
            Claim updateClaim = updateClaim(result, claim, allowdup, "acknowledgment");
            if (!result.hasErrors()) {
                url = new StringBuilder("redirect:/admin/claimedit?success=true")
                        .append("&claimStatus=").append(updateClaim.getClaimStatusId())
                        .append("&id=").append(updateClaim.getClaimId())
                        .append("&followUpDate=").append(URLEncoder
                                .encode(DateUtils.format(updateClaim.getFollowUpDate(), "yyyy-MM-dd"), "UTF-8"))
                        .toString();
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    private Claim updateClaim(BindingResult result, ClaimView claim, boolean allowdup, String mode) {
        Claim updateClaim = null;
        Remark remark;
        ManualReview manualReview;
        boolean isDuplicated;

        if (claim.getProperties().stream()
                .anyMatch(property -> !StringUtils.isEmpty(property.getApn())
                        && !StringUtils.isEmpty(property.getAssessmentNo())))
            result.rejectValue("properties", null, "Just either APN or AssessmentNo");

        isDuplicated = claim.getProperties()
                .stream().anyMatch(prop -> {
                    Properties properties = new Properties();
                    BeanUtils.copyProperties(prop, properties);
                    return propertiesService.isDupplicated(properties);
                });
        if (!allowdup && isDuplicated) {
            result.rejectValue("properties", null, "Properties has duplicate.");
        }
        if (!result.hasErrors()) {
            // Update claim
            Claim currentClaim = claimService.findById(claim.getClaimId());

            updateClaim = new Claim();
            BeanUtils.copyProperties(claim, updateClaim);
            //
            updateClaim.setClaimId(claim.getClaimId());
            updateClaim.setCobrefno(currentClaim.getCobrefno());
            updateClaim.setCompany(claim.getAppType().equals(Constants.CLAIM_APP_TYPE_C));
            updateClaim.setPartialRefund(claim.getRefundType().equals(Constants.REFUND_TYPE_PARTIAL));
            updateClaim.setFullRefund(claim.getRefundType().equals(Constants.REFUND_TYPE_FULL));
            updateClaim.setUpdatedDate(DateUtils.now_sql());
            updateClaim.setUpdatedBy(CommonUtils.getUserAccount().getLoginId());
            switch (mode) {
                case "save":
                case "acknowledgment":
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue());
                    break;
                case "void":
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.VOID.getValue());
                    break;
                case "withdrawn":
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.WITHDRAWN.getValue());
                    break;
                case "duplicate":
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.DUPLICATE.getValue());
                    break;
                case "incomplete":
                case "correction":
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.INCOMPLETE.getValue());
                    break;
                case "finalize":
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.CLOSED.getValue());
                    break;
                default:
                    updateClaim.setClaimStatusId(ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue());
            }
            updateClaim.setCreatedBy(currentClaim.getCreatedBy());
            updateClaim.setCreatedDate(currentClaim.getCreatedDate());
            updateClaim.setRv(currentClaim.getRv());
            updateClaim.setUserId(currentClaim.getUserId());
            claimService.update(updateClaim);

            UserAccount finalUser = CommonUtils.getUserAccount();
            for (ClaimProperties claimProperties : claim.getProperties()) {
                if (StringUtils.isEmpty(claimProperties.getApn()) && StringUtils.isEmpty(claimProperties.getAssessmentNo()))
                    continue;
                Properties properties = null;
                if (claimProperties.getPropertyId() > 0) {
                    properties = propertiesService.findById(claimProperties.getPropertyId());
                    if (properties.getApn().equals(claimProperties.getApn()) &&
                            properties.getAppealNo().equals(claimProperties.getAppealNo()) &&
                            properties.getAssessmentNo().equals(claimProperties.getAssessmentNo()) &&
                            properties.getClaimAmount().equals(claimProperties.getClaimAmount()) &&
                            properties.getTaxYear().equals(claimProperties.getTaxYear()) &&
                            properties.getClaimLineStatusId() == claimProperties.getClaimLineStatusId()
                    ) { // property equal => no update
                        continue;
                    }
                } else {
                    properties = new Properties();
                }
                properties.setClaimId(updateClaim.getClaimId());
                properties.setAppealNo(claimProperties.getAppealNo());
                properties.setApn(claimProperties.getApn());
                properties.setAssessmentNo(claimProperties.getAssessmentNo());
                properties.setClaimAmount(claimProperties.getClaimAmount());
                properties.setTaxYear(claimProperties.getTaxYear());
                if (propertiesService.isDupplicated(properties)) {
                    isDuplicated = true;
                    properties.setClaimLineStatusId(ClaimPropertiesService.ClaimLineStatus.DUPLICATE.getCode());
                } else {
                    properties.setClaimLineStatusId(ClaimPropertiesService.ClaimLineStatus.PENDING_REVIEW.getCode());
                }
                properties.setUpdatedDate(DateUtils.now_sql());
                properties.setUpdatedBy(finalUser.getLoginId());

                if (properties.getPropertyId() == 0) { // new property
                    properties.setRv(DateUtils.now_sql());
                    properties.setCreatedDate(DateUtils.now_sql());
                    properties.setCreatedBy(finalUser.getLoginId());
                    propertiesService.create(properties);
                } else { //update prop
                    propertiesService.update(properties);
                }
            }

            if (isDuplicated) {
                updateClaim.setClaimStatusId(ClaimService.ClaimStatus.DUPLICATE.getValue());
                claimService.update(updateClaim);
            }

            remark = remarkService.findByClaimId(updateClaim.getClaimId());
            if (remark.getRemarkId() != 0) {
                RemarkView claimRemark = claim.getRemark();

                if (!Objects.equals(claimRemark.getRemarksLetter(), remark.getRemarksLetter())
                        || !Objects.equals(claimRemark.getRemarks(), remark.getRemarks())
                ) { // not same remark, updated
                    remark.setRemarksLetter(claim.getRemark().getRemarksLetter());
                    remark.setRemarks(claim.getRemark().getRemarks());
                    remark.setClaimId(updateClaim.getClaimId());
                    remark.setUpdatedDate(DateUtils.now_sql());
                    remark.setUpdatedBy(finalUser.getLoginId());

                    remarkService.update(remark);
                }
            } else {
                newRemark(claim, updateClaim, CommonUtils.getUserAccount());
            }

            switch (ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId())) {
                case INCOMPLETE:
                case SUBMITTED:
                case DUPLICATE:
                case NOT_RECEIVED:
                    manualReview = manualReviewService.findByClaimId(updateClaim.getClaimId());
                    if (manualReview.getId() != 0) {
                        claim.getManualReview().setId(manualReview.getId());
                        BeanUtils.copyProperties(claim.getManualReview(), manualReview);
                        manualReview.setClaimId(updateClaim.getClaimId());

                        manualReviewService.update(manualReview);
                    } else {
                        manualReview = new ManualReview();
                        BeanUtils.copyProperties(claim.getManualReview(), manualReview);
                        manualReview.setClaimId(updateClaim.getClaimId());

                        manualReviewService.create(manualReview);
                    }
                    break;
                default:

                    break;
            }
        }
        return updateClaim;
    }

    private void newRemark(@Valid @ModelAttribute("claim") ClaimView claim, Claim newClaim, UserAccount finalUser) {
        // check for null/empty remark
        if (StringUtils.isNotEmpty(claim.getRemark().getRemarks())
                || StringUtils.isNotEmpty(claim.getRemark().getRemarksLetter())) {


            Remark remark;
            remark = new Remark();
            BeanUtils.copyProperties(claim.getRemark(), remark);
            remark.setClaimId(newClaim.getClaimId());
            remark.setRv(DateUtils.now_sql());
            remark.setCreatedDate(DateUtils.now_sql());
            remark.setUpdatedDate(DateUtils.now_sql());
            remark.setCreatedBy(finalUser.getLoginId());
            remark.setUpdatedBy(finalUser.getLoginId());

            remarkService.create(remark);
        }
    }


    @ResponseBody
    @PostMapping(path = "/update_followup_date")
    public CFRJsonRespone updateFollowUpDate(@RequestParam(name = "claimId", required = true) int claimId,
                                             @RequestParam(name = "followUpDate", required = true) String followUpDate
    ) {
        CFRJsonRespone result = new CFRJsonRespone();
        result.setValue("0");
        try {
            // check duplicate
            Claim claim = claimService.findById(claimId);

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date followUpDateParsed = dateFormat.parse(followUpDate);
            claim.setFollowUpDate(new java.sql.Date(followUpDateParsed.getTime()));
            claimService.update(claim);
            result.setSuccess(true);
            result.setValue("1");

        } catch (Exception e) {
            result.setSuccess(false);
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;
    }

    @ResponseBody
    @GetMapping(path = "/print")
    public CFRJsonRespone printLetter(
            @RequestParam(name = "claimId", required = true) int claimId,
            @RequestParam(name = "type", required = true, defaultValue = "pdf") String type) {

        CFRJsonRespone cfrJsonRespone = new CFRJsonRespone();
        String fileName;
        try {
            fileName = buildReport(claimId, type);
            cfrJsonRespone.setSuccess(true);
            cfrJsonRespone.setValue(MvcUriComponentsBuilder.fromMethodName(this.getClass(),
                    "download", fileName).build().toString());

        } catch (Exception e) {
            cfrJsonRespone.setSuccess(false);
            LogUtils.error(e);
        }
        return cfrJsonRespone;
    }

    private String buildReport(int claimId, String type) {
        String outputFileName = DateUtils.toDayDateString("MMddyyyyhhmmss");
        switch (type) {
            case "docx":
                return buildDocxReport(claimId, outputFileName);

            default:
                buildDocxReport(claimId, outputFileName);
                return buildPDFReport(claimId, outputFileName);

        }
    }

    private String letterName(ClaimService.ClaimStatus status) {
        Map<ClaimService.ClaimStatus, String> mapStatusLetter = new HashMap<>();
        mapStatusLetter.put(ClaimService.ClaimStatus.PENDING_TTC_REVIEW, "AcknowledgeLetter");
        mapStatusLetter.put(ClaimService.ClaimStatus.DUPLICATE, "DuplicateLetter");
        mapStatusLetter.put(ClaimService.ClaimStatus.INCOMPLETE, "IncompleLetter");
        mapStatusLetter.put(ClaimService.ClaimStatus.CORRECTION, "CorrectionLetter");
        String letterName = mapStatusLetter.get(status);
        return letterName;
    }

    private String buildPDFReport(int claimId, String outputFileName) {
        Claim claim = claimService.findById(claimId);

        // TODO: refactor to report builder
        Map<String, Object> parameters = buildReportParams(claim);
        String letterName = letterName(ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId()));
        return reportService.generateReport(letterName, parameters, ReportService.Type.PDF, outputFileName);
    }

    private String buildDocxReport(int claimId, String outputFileName) {
        Claim claim = claimService.findById(claimId);

        // TODO: refactor to report builder
        Map<String, Object> parameters = buildReportParams(claim);
        String letterName = letterName(ClaimService.ClaimStatus.getStatusByCode(claim.getClaimStatusId()));
        return reportService.generateReport(letterName, parameters, ReportService.Type.DOCX, outputFileName);
    }

    private Map<String, Object> buildReportParams(Claim claim) {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> parameters = objectMapper.convertValue(claim, Map.class);
        // common fields
        parameters.put("receivedDate", DateUtils.format(claim.getReceivedDate(), "MM-dd-yyyy"));
        parameters.put("cobrefno", claim.getCobrefno());
        parameters.put("CompanyName", claim.getCompanyName());
        parameters.put("firstName", claim.getFirstName());
        parameters.put("lastName", claim.getLastName());
        parameters.put("address1", claim.getAddress1());
        parameters.put("city", claim.getCity());
        parameters.put("state", claim.getState());
        parameters.put("zipcode", claim.getZip());

        parameters.put("logoImg", "reports/oc_logo.png");

        //
        if (claim.getClaimStatusId() == ClaimService.ClaimStatus.PENDING_TTC_REVIEW.getValue()) {//
            parameters.put("CreatedDate", DateUtils.format(claim.getCreatedDate(), "MM-dd-yyyy"));
            List<Properties> props = propertiesService.findByClaimId(claim.getClaimId());
            parameters.put("apn", props.stream().findFirst().orElse(new Properties()).getApn());

        } else if (claim.getClaimStatusId() == ClaimService.ClaimStatus.INCOMPLETE.getValue()) {
            Remark remark = remarkService.findByClaimId(claim.getClaimId());
            parameters.put("remarks", remark.getRemarksLetter());
            parameters.put("dueDate", "dueDate");
        } else if (claim.getClaimStatusId() == ClaimService.ClaimStatus.DUPLICATE.getValue()) {
            List<Properties> properties = propertiesService.findByClaimId(claim.getClaimId());
            parameters.put("CreatedDate", DateUtils.format(claim.getCreatedDate(), "MM-dd-yyyy"));

            parameters.put("subReport", "reports/DuplicateProperties.jasper");
            parameters.put("properties", new JRBeanCollectionDataSource(properties));
        }
        return parameters;
    }

    @GetMapping("/preview/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> preview(@PathVariable String filename) {
        String fileExtension = FilenameUtils.getFileExtension(filename);
        Resource file;

        switch (fileExtension) {
            case ".pdf":
                file = storageService.loadPDFAsResource(filename);
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + file.getFilename() + "\"").body(file);
            case ".docx":
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + file.getFilename() + "\"").body(file);
            default:
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf(URLConnection.guessContentTypeFromName(filename)))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "inline; filename=\"" + file.getFilename() + "\"").body(file);
        }
    }

    @GetMapping("/download/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> download(@PathVariable String filename) {
        String fileExtension = FilenameUtils.getFileExtension(filename);
        Resource file;

        switch (fileExtension) {
            case ".pdf":
                file = storageService.loadPDFAsResource(filename);
                return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + file.getFilename() + "\"").body(file);
            case ".docx":
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
            default:
                file = storageService.loadAsResource(filename);
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf(URLConnection.guessContentTypeFromName(filename)))
                        .header(HttpHeaders.CONTENT_DISPOSITION,
                                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
        }
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
        LogUtils.error(exc);
        return ResponseEntity.notFound().build();
    }
}
