package com.orangecounty.claim4refund.model;

import javax.validation.constraints.DecimalMin;
import java.math.BigDecimal;

public class WithdrawDetails implements java.io.Serializable {

    private static final long serialVersionUID = 1L;
    @DecimalMin("1")
    private BigDecimal dWAmount;
    private String remarks;


    public WithdrawDetails() {
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public BigDecimal getdWAmount() {
        return dWAmount;
    }

    public void setdWAmount(BigDecimal dWAmount) {
        this.dWAmount = dWAmount;
    }

}
