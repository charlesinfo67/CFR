 package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.CountryDao;
import com.orangecounty.claim4refund.entities.Country;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@CacheConfig(cacheNames = {"countries"})
@Transactional
public class CountryServiceImp implements CountryService {
    @Autowired
    CountryDao countryDao;

    @Override
    @Cacheable
    public List<Country> get() {
        return countryDao.get();
    }

    @Override
    public Country findById(String id) {
        return countryDao.findById(id);
    }

    @Override
    public void create(Country question) {
        countryDao.add(question);
    }

    @Override
    public void delete(String id) {
        countryDao.delete(id);
    }

    @Override
    public Country update(Country question) {
        return countryDao.update(question);
    }
}