package com.orangecounty.claim4refund.reports;

import net.sf.jasperreports.engine.JRDataSource;

import java.util.Map;

public interface ReportService {

    void compileReport(String inputFileName);

    String generateReport(String inputFileName, Map<String, Object> params, Type t, String outputName);

    String generatePDFReport(String inputFileName, Map<String, Object> params);

    String generatePDFReport(String inputFileName, Map<String, Object> params, JRDataSource dataSource);

    enum Type {
        PDF(1, "PDF"),
        DOCX(2, "DOCX");

        private int value;
        private String text;

        Type(int value, String text) {
            this.value = value;
            this.text = text;
        }

        public static Type getByValue(int value) {
            for (Type t : Type.values()) {
                if (t.value == value) {
                    return t;
                }
            }
            return null;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }

}
