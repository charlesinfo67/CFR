package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.entities.PropertyHistories;

import java.util.List;

public interface ClaimPropertiesService {

    void create(Properties properties);

    Properties update(Properties properties);

    void delete(int propertyId);

    List<Properties> get();

    Properties findById(int propertyId);

    List<Properties> findByClaimId(int claimId);

    List<PropertyHistories> findPropertyHistoriesByPropertyId(int propertyId);
    List<PropertyHistories> findPropertyHistoriesByClaimId(int claimId);

    enum ClaimLineStatus {
        DUPLICATE(1, "DUPLICATE"),
        PENDING_REVIEW(2, "PENDING REVIEW"),
        VOID(3, "VOID"),
        DENIED(4, "DENIED"),
        APPROVED(5, "APPROVED"),
        WITHDRAWN(6, "WITHDRAWN"),
        INVALID(7, "INVALID");

        private int code;
        private String text;

        ClaimLineStatus(int code, String text) {
            this.code = code;
            this.text = text;
        }

        public static ClaimPropertiesService.ClaimLineStatus getStatusByCode(int code) {
            for (ClaimPropertiesService.ClaimLineStatus status : ClaimPropertiesService.ClaimLineStatus.values()) {
                if (status.code == code) {
                    return status;
                }
            }
            return null;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }

    boolean isDupplicated(Properties property);

    enum PropertyHistoryStatus {
        CREATED(1, "CREATED"),
        UPDATED(2, "UPDATED"),
        DELETED(3, "DELETED");

        private int code;
        private String text;

        PropertyHistoryStatus(int code, String text) {
            this.code = code;
            this.text = text;
        }

        public static PropertyHistoryStatus getStatusByCode(int code) {
            for (PropertyHistoryStatus status : PropertyHistoryStatus.values()) {
                if (status.code == code) {
                    return status;
                }
            }
            return null;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }

    List<Properties> search(int claimId,
                            String apn,
                            Integer taxyear,
                            String assessmentNo);
}