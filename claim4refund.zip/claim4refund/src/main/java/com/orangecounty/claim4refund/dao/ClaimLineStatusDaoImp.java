package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ClaimLineStatusMstr;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ClaimLineStatusDaoImp implements ClaimLineStatusDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(ClaimLineStatusMstr entity) {
        Session session = sessionFactory.getCurrentSession();
        session.save(entity);
    }

    @Override
    public List<ClaimLineStatusMstr> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from ClaimLineStatusMstr", ClaimLineStatusMstr.class).list();
    }

    @Override
    public ClaimLineStatusMstr findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(ClaimLineStatusMstr.class, id);
    }

    @Override
    public ClaimLineStatusMstr update(ClaimLineStatusMstr entity) {
        Session session = sessionFactory.getCurrentSession();
        session.update(entity);
        return entity;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        ClaimLineStatusMstr entity = findById(id);
        session.delete(entity);
    }
}
