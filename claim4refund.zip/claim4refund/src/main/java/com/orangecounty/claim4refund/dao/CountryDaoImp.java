package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Country;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class CountryDaoImp implements CountryDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(Country question) {
        Session session = sessionFactory.getCurrentSession();
        session.save(question);
    }

    @Override
    public List<Country> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from Country", Country.class).list();
    }

    @Override
    public Country findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Country.class, id);
    }

    @Override
    public Country update(Country question) {
        Session session = sessionFactory.getCurrentSession();
        session.update(question);
        return question;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        Country question = findById(id);
        session.delete(question);
    }
}
