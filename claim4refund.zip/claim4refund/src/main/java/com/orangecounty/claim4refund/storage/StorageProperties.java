package com.orangecounty.claim4refund.storage;

import com.orangecounty.claim4refund.Constants;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("storage")
public class StorageProperties {

    public String getPdfPath() {
        return Constants.REPORT_TEMP_PATH;
    }

}