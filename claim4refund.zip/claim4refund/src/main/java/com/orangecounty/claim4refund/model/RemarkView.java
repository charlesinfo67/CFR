package com.orangecounty.claim4refund.model;

import java.sql.Date;

public class RemarkView {
    private int remarkId;
    private String remarks;
    private String remarksLetter;
    private int claimId;
    private int departmentId;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private boolean isDispositionRemark;
    private Integer conversionKey;

    public int getRemarkId() {
        return remarkId;
    }

    public void setRemarkId(int remarkId) {
        this.remarkId = remarkId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRemarksLetter() {
        return remarksLetter;
    }

    public void setRemarksLetter(String remarksLetter) {
        this.remarksLetter = remarksLetter;
    }

    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }


    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }


    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }


    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }


    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }


    public boolean isDispositionRemark() {
        return isDispositionRemark;
    }

    public void setDispositionRemark(boolean dispositionRemark) {
        isDispositionRemark = dispositionRemark;
    }


    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;

        RemarkView that = (RemarkView) object;

        if (remarkId != that.remarkId) return false;
        if (claimId != that.claimId) return false;
        if (departmentId != that.departmentId) return false;
        if (isDispositionRemark != that.isDispositionRemark) return false;
        if (remarks != null ? !remarks.equals(that.remarks) : that.remarks != null) return false;
        if (remarksLetter != null ? !remarksLetter.equals(that.remarksLetter) : that.remarksLetter != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (updatedBy != null ? !updatedBy.equals(that.updatedBy) : that.updatedBy != null) return false;
        if (updatedDate != null ? !updatedDate.equals(that.updatedDate) : that.updatedDate != null) return false;
        if (rv != null ? !rv.equals(that.rv) : that.rv != null) return false;
        return conversionKey != null ? conversionKey.equals(that.conversionKey) : that.conversionKey == null;
    }

    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + remarkId;
        result = 31 * result + (remarks != null ? remarks.hashCode() : 0);
        result = 31 * result + (remarksLetter != null ? remarksLetter.hashCode() : 0);
        result = 31 * result + claimId;
        result = 31 * result + departmentId;
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (updatedBy != null ? updatedBy.hashCode() : 0);
        result = 31 * result + (updatedDate != null ? updatedDate.hashCode() : 0);
        result = 31 * result + (rv != null ? rv.hashCode() : 0);
        result = 31 * result + (isDispositionRemark ? 1 : 0);
        result = 31 * result + (conversionKey != null ? conversionKey.hashCode() : 0);
        return result;
    }
}
