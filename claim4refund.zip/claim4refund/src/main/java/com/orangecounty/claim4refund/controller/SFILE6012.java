package com.orangecounty.claim4refund.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.*;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.model.CFRJsonRespone;
import com.orangecounty.claim4refund.model.ClaimProperties;
import com.orangecounty.claim4refund.model.ClaimView;
import com.orangecounty.claim4refund.reports.ReportService;
import com.orangecounty.claim4refund.services.*;
import com.orangecounty.claim4refund.storage.StorageFileNotFoundException;
import com.orangecounty.claim4refund.storage.StorageService;
import com.orangecounty.claim4refund.utils.CommonUtils;
import com.orangecounty.claim4refund.utils.DateUtils;
import com.orangecounty.claim4refund.utils.LogUtils;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/dashboard/createnewclaim")
public class SFILE6012 {
    private final StorageService storageService;
    @Autowired
    private UserService userService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private StateService stateService;
    @Autowired
    private EmailService emailService;
    @Autowired
    private ClaimService claimService;
    @Autowired
    private ClaimPropertiesService propertiesService;
    @Autowired
    private ReportService reportService;

    @Autowired
    public SFILE6012(StorageService storageService) {
        this.storageService = storageService;
    }

    @ModelAttribute("countries")
    public List<Country> countries() {
        return countryService.get();
    }

    @ModelAttribute("states")
    public List<State> states() {
        return stateService.get();
    }

    @GetMapping(path = "/new")
    public String index(Model model) {
        ClaimView claim = new ClaimView();
        UserAccount user = CommonUtils.getUserAccount();
        BeanUtils.copyProperties(user, claim);
        claim.addProperties(new ClaimProperties());
        model.addAttribute("claim", claim);
        return "/SFILE6012";
    }

    @ResponseBody
    @PostMapping(path = "/preview")
    public CFRJsonRespone preview(@ModelAttribute("claim") @Valid ClaimView claim,
                                  BindingResult result) {
        CFRJsonRespone cfrJsonRespone = new CFRJsonRespone();
        String fileName;
        String errorMsg = "";
        String errorItem = "";
        try {
            if (claim == null) {
                return cfrJsonRespone;
            }

            int index = 0;
            for (ClaimProperties prop : claim.getProperties()) {
                if (!StringUtils.isEmpty(prop.getApn()) && !StringUtils.isEmpty(prop.getAssessmentNo())) {
                    result.rejectValue(String.format("properties[%s].apn", index),
                            null,
                            String.format("Enter either APN or Assessment No. for row %s in property details.", index + 1));
                    result.rejectValue(String.format("properties[%s].assessmentNo", index),
                            null,
                            String.format("Enter either APN or Assessment No. for row %s in property details.", index + 1));
                }
                index++;
            }

            if (result.hasErrors()) {
                for (FieldError error : result.getFieldErrors()) {
                    errorMsg += error.getDefaultMessage() + "\n";
                    errorItem += error.getField() + " ";
                }
                cfrJsonRespone.setValue(errorItem);
                cfrJsonRespone.setMessage(errorMsg);
                cfrJsonRespone.setSuccess(false);
                return cfrJsonRespone;
            }

            List<ClaimProperties> properties = claim.getProperties();
            BigDecimal totalAmount = BigDecimal.ZERO;
            for (ClaimProperties prop : properties) {
                totalAmount = totalAmount.add(prop.getClaimAmount());
            }

            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> parameters = objectMapper.convertValue(claim, Map.class);
            parameters.put("partialRefund", claim.getRefundType().equals(Constants.REFUND_TYPE_PARTIAL));
            parameters.put("fullRefund", claim.getRefundType().equals(Constants.REFUND_TYPE_FULL));
            parameters.put("receivedDate", DateUtils.format(claim.getReceivedDate(), "MM-dd-yyyy"));
            parameters.put("logoImg", "reports/oc_logo.png");
            parameters.put("subReport", "reports/ClaimProperties.jasper");
            parameters.put("properties", new JRBeanCollectionDataSource(properties));
            parameters.put("totalClaimAmount", totalAmount);

            fileName = reportService.generatePDFReport("REPORT6020", parameters);
            cfrJsonRespone.setSuccess(true);
            cfrJsonRespone.setValue(MvcUriComponentsBuilder.fromMethodName(SFILE6012.class,
                    "serveFile", fileName).build().toString());

        } catch (Exception e) {
            cfrJsonRespone.setSuccess(false);
            LogUtils.error(e);
        }
        return cfrJsonRespone;
    }

    @PostMapping(path = "/new")
    public String registerClaim(@ModelAttribute("claim") @Valid ClaimView claim,
                                BindingResult result,
                                @RequestParam(required = false, defaultValue = "false") boolean allowdup) {
        String url = "/SFILE6012";
        Claim newClaim;
        try {
            if (claim.getProperties()
                    .stream()
                    .anyMatch(property -> StringUtils.isNotEmpty(property.getApn())
                            && StringUtils.isNotEmpty(property.getAssessmentNo())))
                result.rejectValue("properties", null, "Just either APN or AssessmentNo");

            boolean isDuplicated = claim.getProperties()
                    .stream().anyMatch(prop -> {
                        Properties properties = new Properties();
                        BeanUtils.copyProperties(prop, properties);
                        return propertiesService.isDupplicated(properties);
                    });
            if (isDuplicated && !allowdup) {
                result.rejectValue("properties", null, "Properties has duplicate.");
            }
            if (!result.hasErrors()) {

                ClaimService.setClaimCobrefno(claim, claimService);

                newClaim = newClaim(claim, CommonUtils.getUserAccount());

                for (ClaimProperties claimProperties : claim.getProperties()) {
                    if (StringUtils.isEmpty(claimProperties.getApn()) && StringUtils.isEmpty(claimProperties.getAssessmentNo()))
                        continue;
                    Properties properties = new Properties();
                    BeanUtils.copyProperties(claimProperties, properties);
                    properties.setClaimId(newClaim.getClaimId());
                    properties.setRv(DateUtils.now_sql());
                    properties.setCreatedDate(DateUtils.now_sql());
                    properties.setUpdatedDate(DateUtils.now_sql());
                    properties.setCreatedBy(CommonUtils.getUserAccount().getLoginId());
                    properties.setUpdatedBy(CommonUtils.getUserAccount().getLoginId());

                    if (propertiesService.isDupplicated(properties)) {
                        isDuplicated = true;
                        properties.setClaimLineStatusId(ClaimPropertiesService.ClaimLineStatus.DUPLICATE.getCode());
                    } else {
                        properties.setClaimLineStatusId(ClaimPropertiesService.ClaimLineStatus.PENDING_REVIEW.getCode());
                    }
                    propertiesService.create(properties);
                }
                if (isDuplicated) {
                    newClaim.setClaimStatusId(ClaimService.ClaimStatus.DUPLICATE.getValue());
                    claimService.update(newClaim);
                }

                // Notify to Admins
                List<UserAccount> admins = userService.getByRole(Constants.USER_ROLE_ADMIN);
                for (UserAccount admin : admins) {
                    emailService.sendNotiMail("You have a new Claim need to approval.", admin);
                }
                url = "redirect:/dashboard/createnewclaim/new?success=true";
            }
        } catch (Exception e) {
            result.reject("global", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }

        return url;
    }

    private Claim newClaim(ClaimView claim, UserAccount user) {
        Claim newClaim;
        newClaim = new Claim();
        BeanUtils.copyProperties(claim, newClaim);

        newClaim.setUserId(user.getLoginId());

        newClaim.setCompany(claim.getAppType().equals(Constants.CLAIM_APP_TYPE_C));

        newClaim.setClaimStatusId(ClaimService.ClaimStatus.SUBMITTED.getValue()); //SUBMITTED

        newClaim.setPartialRefund(claim.getRefundType().equals(Constants.REFUND_TYPE_PARTIAL));
        newClaim.setFullRefund(claim.getRefundType().equals(Constants.REFUND_TYPE_FULL));

        newClaim.setRv(DateUtils.now_sql());
        newClaim.setCreatedDate(DateUtils.now_sql());
        newClaim.setUpdatedDate(DateUtils.now_sql());
        newClaim.setCreatedBy(user.getLoginId());
        newClaim.setUpdatedBy(user.getLoginId());

        claimService.create(newClaim);
        return newClaim;
    }

    @RequestMapping(path = "/new", params = {"addRow"})
    public String addRow(@ModelAttribute("claim") @Valid ClaimView claim,
                         BindingResult result) {
        claim.addProperties(new ClaimProperties());
        return "/SFILE6012";
    }

    @RequestMapping(path = "/new", params = {"removeRow"})
    public String removeRow(@ModelAttribute("claim") @Valid ClaimView claim,
                            BindingResult result, final HttpServletRequest req) {
        final Integer index = Integer.valueOf(req.getParameter("removeRow"));
        claim.removeProperties(index);
        return "/SFILE6012";
    }

    @GetMapping("/preview/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {

        Resource file = storageService.loadPDFAsResource(filename);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF).header(HttpHeaders.CONTENT_DISPOSITION,
                "inline; filename=\"" + file.getFilename() + "\"").body(file);
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
        LogUtils.error(exc);
        return ResponseEntity.notFound().build();
    }

    @ResponseBody
    @PostMapping(path = "/checkdup")
    public CFRJsonRespone checkDup(@ModelAttribute("claim") ClaimView claim) {
        CFRJsonRespone result = new CFRJsonRespone();
        boolean isDuplicated = false;
        try {
            // check duplicate
            isDuplicated = isDuplicated(claim);
            if (isDuplicated) {
                result.setSuccess(true);
                result.setValue("1");
            } else {
                result.setSuccess(true);
                result.setValue("0");
            }

        } catch (Exception e) {
            result.setSuccess(false);
            result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }

    private boolean isDuplicated(ClaimView claim) {
        // check duplicate
        for (ClaimProperties claimProperties : claim.getProperties()) {
            Properties properties = new Properties();
            BeanUtils.copyProperties(claimProperties, properties);
            if (propertiesService.isDupplicated(properties)) {
                return true;
            }
        }
        return false;
    }
}