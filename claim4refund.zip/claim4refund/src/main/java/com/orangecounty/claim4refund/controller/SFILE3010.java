package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.Token;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.mail.EmailService;
import com.orangecounty.claim4refund.services.TokenService;
import com.orangecounty.claim4refund.services.UserService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/reset_pass")
public class SFILE3010 {
    @Autowired
    public EmailService emailService;
    @Autowired
    private UserService userService;
    @Autowired
    private TokenService tokenService;

    @RequestMapping(method = RequestMethod.GET)
    public String recover(@RequestParam(required = true, name = "token") String userToken, final Model model) {
        Token token;
        try {
            // check token valid
            token = tokenService.check(userToken, Constants.TOKEN_TYPE_RESET_PASS);
            if (token == null) {
                model.addAttribute("message", "Your token is invalid!");
            }
        } catch (Exception e) {
            model.addAttribute("message", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }
        return "/SFILE3010";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String updatePass(@RequestParam(required = true, name = "token") String userToken,
                             @RequestParam(required = true) String password1,
                             @RequestParam(required = true) String password2, final Model model) {
        Token token;
        try {
            // check token valid
            token = tokenService.check(userToken, Constants.TOKEN_TYPE_RESET_PASS);
            if (token == null) {
                model.addAttribute("message", "Your url is invalid!");
                return "/SFILE3010";
            }


            BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
            String encodedPass = bCryptPasswordEncoder.encode(password1);

            UserAccount user = userService.findById(token.getValue());
            user.setPassword(encodedPass);

            userService.update(user);

            token.setStatus(1);
            tokenService.update(token);

            model.addAttribute("message", "Your password was updated!");
        } catch (Exception e) {
            model.addAttribute("message", "Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
            e.printStackTrace();
        }

        return "/SFILE3010";
    }
}
