package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.UserAccount;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.orangecounty.claim4refund.Constants.STATUS_PENDING;
import static com.orangecounty.claim4refund.Constants.USER_ROLE_MEMBER;

@Repository
@Transactional(rollbackFor = Exception.class)
public class UserDaoImp implements UserDao {

    @Autowired
    private SessionFactory sessionFactory;

    public UserAccount loadUserByUsername(final String loginId) {
        return findById(loginId);
    }

    @Override
    public void add(UserAccount user) {
        Session session = sessionFactory.getCurrentSession();
        session.save(user);
    }

    @Override
    public List<UserAccount> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from UserAccount", UserAccount.class).list();
    }

    @Override
    public UserAccount findById(String loginId) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(UserAccount.class, loginId);
    }

    @Override
    public UserAccount findByEmail(String email) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<UserAccount> criteria = builder.createQuery(UserAccount.class);
        Root<UserAccount> root = criteria.from(UserAccount.class);

        criteria.select(root).where(builder.and(builder.equal(root.get("email"), email)));

        Query<UserAccount> query = session.createQuery(criteria);
        List<UserAccount> users = query.list();
        return users.isEmpty() ? null : users.get(0);
    }

    @Override
    public UserAccount update(UserAccount user) {
        Session session = sessionFactory.getCurrentSession();
        session.update(user);
        return user;
    }

    @Override
    public void delete(String loginId) {
        Session session = sessionFactory.getCurrentSession();
        UserAccount user = findById(loginId);
        if (user != null)
            session.delete(user);
    }

    @Override
    public long countNewUsers() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<UserAccount> root = criteria.from(UserAccount.class);

        criteria.select(builder.count(root))
                .where(builder.and(builder.equal(root.get("status"), STATUS_PENDING)));
        return session.createQuery(criteria).getSingleResult();
    }

    @Override
    public long countUsers() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<UserAccount> root = criteria.from(UserAccount.class);

        criteria.select(builder.count(root))
                .where(builder.and(builder.equal(root.get("role"), USER_ROLE_MEMBER)));
        return session.createQuery(criteria).getSingleResult();
    }

    @Override
    public List<UserAccount> get(int role) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<UserAccount> criteria = builder.createQuery(UserAccount.class);
        Root<UserAccount> root = criteria.from(UserAccount.class);

        criteria.select(root).where(builder.and(builder.equal(root.get("role"), role)));

        Query<UserAccount> query = session.createQuery(criteria);
        return query.list();
    }

    @Override
    public List<UserAccount> search(String name, int year, Integer start, Integer length) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<UserAccount> criteria = builder.createQuery(UserAccount.class);
        Root<UserAccount> root = criteria.from(UserAccount.class);

        Predicate qr = builder.and(builder.equal(root.get("role"), USER_ROLE_MEMBER),
                builder.or(
                        builder.like(root.get("businessName"), "%" + name + "%"),
                        builder.like(root.get("firstName"), "%" + name + "%"),
                        builder.like(root.get("lastName"), "%" + name + "%")));

        if(year > 0) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.YEAR, (-1)*year);

            qr = builder.and(qr, builder.lessThanOrEqualTo(root.get("lastLogin"), calendar.getTime()));
        }

        criteria.select(root)
                .where(qr);

        Query<UserAccount> query = session.createQuery(criteria)
                                            .setFirstResult(start)
                                            .setMaxResults(length);
        return query.list();
    }
}
