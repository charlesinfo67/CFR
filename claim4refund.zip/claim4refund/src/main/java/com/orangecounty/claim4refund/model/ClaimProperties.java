package com.orangecounty.claim4refund.model;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;

public class ClaimProperties {
    private int propertyId;
    @Size(max = 25)
    private String appealNo;
    @Size(max = 15)
    private String apn;
    @Size(max = 4)
    private String apnSuffix;
    @Size(max = 15)
    private String assessmentNo;
    private BigDecimal claimAmount;
    private Integer taxYear;
    private Integer claimLineStatusId;
    private boolean isTaxesPaid;
    private BigDecimal amountApproved;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private Date rv;
    private boolean isActive;
    private Integer conversionKey;
    private Date dateSentToTtcForRefundCheck;

    public ClaimProperties() {
        claimAmount = BigDecimal.ZERO;
        claimLineStatusId = 7;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public String getAppealNo() {
        return appealNo;
    }

    public void setAppealNo(String appealNo) {
        this.appealNo = appealNo;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    public String getApnSuffix() {
        return apnSuffix;
    }

    public void setApnSuffix(String apnSuffix) {
        this.apnSuffix = apnSuffix;
    }

    public String getAssessmentNo() {
        return assessmentNo;
    }

    public void setAssessmentNo(String assessmentNo) {
        this.assessmentNo = assessmentNo;
    }

    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    public Integer getTaxYear() {
        return taxYear;
    }

    public void setTaxYear(Integer taxYear) {
        this.taxYear = taxYear;
    }

    public Integer getClaimLineStatusId() {
        return claimLineStatusId;
    }

    public void setClaimLineStatusId(Integer claimLineStatusId) {
        this.claimLineStatusId = claimLineStatusId;
    }

    public boolean getTaxesPaid() {
        return isTaxesPaid;
    }

    public void setTaxesPaid(boolean taxesPaid) {
        isTaxesPaid = taxesPaid;
    }

    public BigDecimal getAmountApproved() {
        return amountApproved;
    }

    public void setAmountApproved(BigDecimal amountApproved) {
        this.amountApproved = amountApproved;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Date getRv() {
        return rv;
    }

    public void setRv(Date rv) {
        this.rv = rv;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    public Date getDateSentToTtcForRefundCheck() {
        return dateSentToTtcForRefundCheck;
    }

    public void setDateSentToTtcForRefundCheck(Date dateSentToTtcForRefundCheck) {
        this.dateSentToTtcForRefundCheck = dateSentToTtcForRefundCheck;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClaimProperties that = (ClaimProperties) o;
        return propertyId == that.propertyId &&
                isActive == that.isActive &&
                Objects.equals(appealNo, that.appealNo) &&
                Objects.equals(apn, that.apn) &&
                Objects.equals(apnSuffix, that.apnSuffix) &&
                Objects.equals(assessmentNo, that.assessmentNo) &&
                Objects.equals(claimAmount, that.claimAmount) &&
                Objects.equals(taxYear, that.taxYear) &&
                Objects.equals(claimLineStatusId, that.claimLineStatusId) &&
                Objects.equals(isTaxesPaid, that.isTaxesPaid) &&
                Objects.equals(amountApproved, that.amountApproved) &&
                Objects.equals(createdBy, that.createdBy) &&
                Objects.equals(createdDate, that.createdDate) &&
                Objects.equals(updatedBy, that.updatedBy) &&
                Objects.equals(updatedDate, that.updatedDate) &&
                Objects.equals(rv, that.rv) &&
                Objects.equals(conversionKey, that.conversionKey) &&
                Objects.equals(dateSentToTtcForRefundCheck, that.dateSentToTtcForRefundCheck);
    }

    @Override
    public int hashCode() {
        return Objects.hash(propertyId, appealNo, apn, apnSuffix, assessmentNo, claimAmount, taxYear, claimLineStatusId, isTaxesPaid, amountApproved, createdBy, createdDate, updatedBy, updatedDate, rv, isActive, conversionKey, dateSentToTtcForRefundCheck);
    }
}
