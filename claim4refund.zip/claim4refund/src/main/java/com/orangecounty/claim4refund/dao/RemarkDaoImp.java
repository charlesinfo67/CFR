package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Remark;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class RemarkDaoImp implements RemarkDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(Remark entity) {
        Session session = sessionFactory.getCurrentSession();
        session.save(entity);
    }

    @Override
    public List<Remark> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from RemarkEntity", Remark.class).list();
    }

    @Override
    public Remark findById(String id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Remark.class, id);
    }

    @Override
    public Remark findByClaimId(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Remark> criteria = builder.createQuery(Remark.class);
        Root<Remark> root = criteria.from(Remark.class);
        criteria.where(builder.and(builder.equal(root.get("claimId"), claimId)));

        List<Remark> results = session.createQuery(criteria).getResultList();
        if (!results.isEmpty())
            return results.get(0);
        else
            return new Remark();
    }

    @Override
    public Remark update(Remark entity) {
        Session session = sessionFactory.getCurrentSession();
        session.update(entity);
        return entity;
    }

    @Override
    public void delete(String id) {
        Session session = sessionFactory.getCurrentSession();
        Remark entity = findById(id);
        session.delete(entity);
    }
}
