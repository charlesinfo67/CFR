package com.orangecounty.claim4refund.model;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.utils.DateUtils;

import java.sql.Date;

public class ClaimViewOnList {
    private String appType;
    private int claimId;
    private String cobrefno;
    private String claimantName;
    private String agentName;
    private int claimRefundTypeId;
    private int claimStatusId;
    private Date receivedDate;
    private Date followUpDate;
    private int claimLetterType;
    private Integer conversionKey;
    private boolean isCompany;
    private String companyName;
    private String refundType;
    private int propertyId;
    private String appealNo;
    private String apn;
    private String assessmentNo;
    private Integer taxYear;
    private Integer claimLineStatusId;

    public ClaimViewOnList() {
        claimRefundTypeId = Constants.CLAIM_REFUND_TYPE_1;
        refundType = Constants.REFUND_TYPE_PARTIAL;
        receivedDate = DateUtils.now_sql();
        followUpDate = DateUtils.now_sql();
    }

    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public String getCobrefno() {
        return cobrefno;
    }

    public void setCobrefno(String cobrefno) {
        this.cobrefno = cobrefno;
    }

    public String getClaimantName() {
        return claimantName;
    }

    public void setClaimantName(String claimantName) {
        this.claimantName = claimantName;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getClaimRefundType() {
        return claimRefundTypeId == 1 ? "T" : "P";
    }

    public int getClaimRefundTypeId() {
        return claimRefundTypeId;
    }

    public void setClaimRefundTypeId(int claimRefundTypeId) {
        this.claimRefundTypeId = claimRefundTypeId;
    }

    public String getClaimStatus() {
        return ClaimService.ClaimStatus.getStatusByCode(claimStatusId).getText();
    }

    public int getClaimStatusId() {
        return claimStatusId;
    }

    public void setClaimStatusId(int claimStatusId) {
        this.claimStatusId = claimStatusId;
    }

    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    public Date getFollowUpDate() {
        return followUpDate;
    }

    public void setFollowUpDate(Date followUpDate) {
        this.followUpDate = followUpDate;
    }

    public int getClaimLetterType() {
        return claimLetterType;
    }

    public void setClaimLetterType(int claimLetterType) {
        this.claimLetterType = claimLetterType;
    }

    public Integer getConversionKey() {
        return conversionKey;
    }

    public void setConversionKey(Integer conversionKey) {
        this.conversionKey = conversionKey;
    }

    public boolean isCompany() {
        return isCompany;
    }

    public void setCompany(boolean company) {
        isCompany = company;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public String getRefundType() {
        return refundType;
    }

    public void setRefundType(String refundType) {
        this.refundType = refundType;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public String getAppealNo() {
        return appealNo;
    }

    public void setAppealNo(String appealNo) {
        this.appealNo = appealNo;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }

    public String getAssessmentNo() {
        return assessmentNo;
    }

    public void setAssessmentNo(String assessmentNo) {
        this.assessmentNo = assessmentNo;
    }

    public Integer getTaxYear() {
        return taxYear;
    }

    public void setTaxYear(Integer taxYear) {
        this.taxYear = taxYear;
    }

    public Integer getClaimLineStatusId() {
        return claimLineStatusId;
    }

    public void setClaimLineStatusId(Integer claimLineStatusId) {
        this.claimLineStatusId = claimLineStatusId;
    }
}
