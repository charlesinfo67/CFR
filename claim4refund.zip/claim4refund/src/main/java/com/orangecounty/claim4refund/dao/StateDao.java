package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.State;

import java.util.List;

public interface StateDao {
    void add(State state);

    List<State> get();

    State findById(String id);

    State update(State state);

    void delete(String id);
}