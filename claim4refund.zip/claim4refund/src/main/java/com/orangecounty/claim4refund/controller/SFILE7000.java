package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.model.ClaimViewOnList;
import com.orangecounty.claim4refund.model.DataTableResult;
import com.orangecounty.claim4refund.services.ClaimPropertiesService;
import com.orangecounty.claim4refund.services.ClaimRefundStatusService;
import com.orangecounty.claim4refund.services.ClaimService;
import com.orangecounty.claim4refund.utils.LogUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin/searchclaim")
public class SFILE7000 {
    @Autowired
    private ClaimService claimService;

    @Autowired
    private ClaimPropertiesService propertiesService;

    @Autowired
    private ClaimRefundStatusService statusService;

    @ModelAttribute
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public Date firstDayOfMonth() {
        return new Date();
    }

    @ModelAttribute
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public Date toDay() {
        return new Date();
    }

    @ModelAttribute("status")
    public List<ClaimRefundStatusMSTR> claimRefundStatusMstrs() {
        return statusService.get();
    }

    @GetMapping
    public String index() {
        return "/SFILE7000";
    }


    @ResponseBody
    @PostMapping(path = "/search")
    public DataTableResult search(@RequestParam Integer draw,
                                  @RequestParam Integer start,
                                  @RequestParam Integer length,
                                  @RequestParam(name = "columns[1][search][value]") String cobrefno,
                                  @RequestParam(name = "columns[2][search][value]") Integer claimRefundTypeId,
                                  @RequestParam(name = "columns[3][search][value]") Integer[] status,
                                  @RequestParam(name = "columns[4][search][value]") String receivedDate,
                                  @RequestParam(name = "columns[5][search][value]") String claimantName,
                                  @RequestParam(name = "columns[6][search][value]") String agentName,
                                  @RequestParam(name = "columns[7][search][value]") String apn,
                                  @RequestParam(name = "columns[8][search][value]") Integer taxyear,
                                  @RequestParam(name = "columns[9][search][value]") String assessmentNo) {
        DataTableResult result = new DataTableResult();
        List<ClaimViewOnList> claimsView;
        long recordFiltered = 0;
        try {
            claimsView = new ArrayList<>();

            String[] receivedDates = receivedDate.split(",");
            String[] claimantNames = claimantName.split(",");

            recordFiltered = claimService.search(start, -1, cobrefno, claimRefundTypeId, status,
                    receivedDates[0], receivedDates.length > 1 ? receivedDates[1] : "", claimantNames[0], claimantNames.length > 1 ? claimantNames[1] : "", agentName).size();
            List<Claim> claims = claimService.search(start, length, cobrefno, claimRefundTypeId, status,
                    receivedDates[0], receivedDates.length > 1 ? receivedDates[1] : "", claimantNames[0], claimantNames.length > 1 ? claimantNames[1] : "", agentName);

            claims.forEach(claim -> {
                ClaimViewOnList claimViewOnLst = new ClaimViewOnList();
                BeanUtils.copyProperties(claim, claimViewOnLst);
                claimViewOnLst.setClaimantName(claim.getFirstName() + ' ' + claim.getLastName());

                Optional<Properties> prop = propertiesService.search(claim.getClaimId(), apn, taxyear, assessmentNo).stream().findFirst();
                if (prop.isPresent()) {
                    claimViewOnLst.setPropertyId(prop.get().getPropertyId());
                    claimViewOnLst.setAppealNo(prop.get().getAppealNo());
                    claimViewOnLst.setApn(prop.get().getApn());
                    claimViewOnLst.setTaxYear(prop.get().getTaxYear());
                    claimViewOnLst.setAssessmentNo(prop.get().getAssessmentNo());
                    claimViewOnLst.setClaimLineStatusId(prop.get().getClaimLineStatusId());
                }

                claimsView.add(claimViewOnLst);
            });

            result.setDraw(draw);
            result.setRecordsTotal(claimService.countClaims());
            result.setRecordsFiltered(recordFiltered);
            result.setData(claimsView);

        } catch (Exception e) {
            //result.setMessage("Sorry! Something went wrong. Please try again later.");
            LogUtils.error(e);
        }
        return result;

    }
}