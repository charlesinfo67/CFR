package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.Claim;
import com.orangecounty.claim4refund.entities.GroupedCount;

import java.util.List;
import java.util.Optional;

public interface ClaimDao {

    void add(Claim Claim);

    Claim update(Claim claim);

    int updateInvalid();

    void delete(int claimId);

    List<Claim> get();

    Claim findById(int claimId);

    List<Claim> findByEmail(String email);

    List<Claim> findByUserId(String loginId);

    Claim findByCobrefno(String cobrefno, Optional<String> userId);

    List<Claim> search(String cobrefno);

    long countNewClaims();

    long countClaims();

    List<GroupedCount> countByStatus(Integer... ids);

    List<GroupedCount> countPendingReview(int status, int month_s, int month_e);

    String maxCOBREFNO(char prefix);

    List<Claim> search(int start, int length,
                       String cobrefno, Integer claimRefundTypeId, Integer[] status,
                       String receivedDate_s, String receivedDate_e,
                       String firstName, String lastName, String agentName);

}