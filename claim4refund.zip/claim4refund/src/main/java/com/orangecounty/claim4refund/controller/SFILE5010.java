package com.orangecounty.claim4refund.controller;

import com.orangecounty.claim4refund.Constants;
import com.orangecounty.claim4refund.entities.UserAccount;
import com.orangecounty.claim4refund.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/admin/manage_accounts")
public class SFILE5010 {
    @Autowired
    private UserService userService;

    @ModelAttribute
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public Date firstDayOfMonth() {
        return new Date();
    }

    @ModelAttribute
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public Date toDay() {
        return new Date();
    }

    @ModelAttribute("users")
    public List<UserAccount> users() {
        return userService.getByRole(Constants.USER_ROLE_MEMBER);
    }

    @GetMapping
    public String index() {
        return "/SFILE5010";
    }

}