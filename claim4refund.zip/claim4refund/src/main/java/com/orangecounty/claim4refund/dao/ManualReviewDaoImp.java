package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.ManualReview;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
@Transactional(rollbackFor = Exception.class)
public class ManualReviewDaoImp implements ManualReviewDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void add(ManualReview entity) {
        Session session = sessionFactory.getCurrentSession();
        session.save(entity);
    }

    @Override
    public List<ManualReview> get() {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from ManualReview", ManualReview.class).list();
    }

    @Override
    public ManualReview findById(int id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(ManualReview.class, id);
    }

    @Override
    public ManualReview findByClaimId(int claimId) {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<ManualReview> criteria = builder.createQuery(ManualReview.class);
        Root<ManualReview> root = criteria.from(ManualReview.class);
        criteria.where(builder.and(builder.equal(root.get("claimId"), claimId)));

        List<ManualReview> results = session.createQuery(criteria).getResultList();
        if (!results.isEmpty())
            return results.get(0);
        else
            return new ManualReview();
    }

    @Override
    public ManualReview update(ManualReview entity) {
        Session session = sessionFactory.getCurrentSession();
        session.update(entity);
        return entity;
    }

    @Override
    public void delete(int id) {
        Session session = sessionFactory.getCurrentSession();
        ManualReview entity = findById(id);
        session.delete(entity);
    }
}
