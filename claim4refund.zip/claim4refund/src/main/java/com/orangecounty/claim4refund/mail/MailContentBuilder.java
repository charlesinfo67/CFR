package com.orangecounty.claim4refund.mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class MailContentBuilder {

    private TemplateEngine templateEngine;

    @Autowired
    public MailContentBuilder(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }

    public String buildResetPassMailTemplate(Context context) {
        return templateEngine.process("/mail/reset_pass", context);
    }

    public String buildDownloadLinkMailTemplate(Context context) {
        return templateEngine.process("/mail/download_link", context);
    }

    public String buildNotiMailTemplate(Context context) {
        return templateEngine.process("/mail/notification", context);
    }

}