package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.dao.ClaimPropertiesDao;
import com.orangecounty.claim4refund.dao.ClaimPropertyHistoriesDao;
import com.orangecounty.claim4refund.entities.Properties;
import com.orangecounty.claim4refund.entities.PropertyHistories;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ClaimPropertiesServiceImp implements ClaimPropertiesService {
    @Autowired
    ClaimPropertiesDao claimPropertiesDao;

    @Autowired
    ClaimPropertyHistoriesDao claimPropertyHistoriesDao;

    @Override
    public List<Properties> get() {
        List<Properties> properties = claimPropertiesDao.get();
        return properties;
    }

    @Override
    public Properties findById(int propertyId) {
        Properties properties = claimPropertiesDao.findById(propertyId);
        return properties;
    }

    @Override
    public List<Properties> findByClaimId(int claimId) {
        return claimPropertiesDao.findByClaimId(claimId);
    }

    @Override
    public List<PropertyHistories> findPropertyHistoriesByPropertyId(int propertyId) {
        return claimPropertyHistoriesDao.findByPropertyId(propertyId);
    }

    @Override
    public List<PropertyHistories> findPropertyHistoriesByClaimId(int claimId) {
        return claimPropertyHistoriesDao.findByClaimId(claimId);
    }

    @Override
    public boolean isDupplicated(Properties property) {
        return claimPropertiesDao.isDupplicated(property);
    }

    @Override
    public List<Properties> search(int claimId, String apn, Integer taxyear, String assessmentNo) {
        return claimPropertiesDao.search(claimId, apn, taxyear, assessmentNo);
    }

    @Override
    public void create(Properties properties) {
        claimPropertiesDao.add(properties);
        PropertyHistories propertyHistories = new PropertyHistories();

        // add history
        BeanUtils.copyProperties(properties, propertyHistories);
        propertyHistories.setStatus(properties.getClaimLineStatusId());
        claimPropertyHistoriesDao.add(propertyHistories);
    }

    @Override
    public void delete(int propertyId) {
        Properties properties = claimPropertiesDao.findById(propertyId);
        claimPropertiesDao.delete(propertyId);
        // add history
        PropertyHistories propertyHistories = new PropertyHistories();
        BeanUtils.copyProperties(properties, propertyHistories);
        propertyHistories.setStatus(PropertyHistoryStatus.DELETED.getCode());
        claimPropertyHistoriesDao.add(propertyHistories);
    }

    @Override
    public Properties update(Properties properties) {
        Properties update = claimPropertiesDao.update(properties);

        // add history
        PropertyHistories propertyHistories = new PropertyHistories();
        BeanUtils.copyProperties(update, propertyHistories);
        propertyHistories.setStatus(PropertyHistoryStatus.UPDATED.getCode());
        claimPropertyHistoriesDao.add(propertyHistories);
        return update;
    }

}