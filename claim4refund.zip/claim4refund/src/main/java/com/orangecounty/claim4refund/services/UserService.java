package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.UserAccount;

import java.util.List;

public interface UserService {

    void create(UserAccount user);

    List<UserAccount> get();

    List<UserAccount> getByRole(int role);

    UserAccount findById(String loginId);

    UserAccount findByEmail(String email);

    UserAccount update(UserAccount user);

    void delete(String loginId);

    long countNewUsers();

    long countUsers();

    List<UserAccount> search(String name, int year, Integer start, Integer length);
}