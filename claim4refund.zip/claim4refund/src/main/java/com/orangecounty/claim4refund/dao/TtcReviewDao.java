package com.orangecounty.claim4refund.dao;

import com.orangecounty.claim4refund.entities.TtcReview;

import java.util.List;

public interface TtcReviewDao {
    void add(TtcReview entity);

    List<TtcReview> get();

    TtcReview findById(String id);

    TtcReview update(TtcReview entity);

    void delete(String id);
}