package com.orangecounty.claim4refund.services;

import com.orangecounty.claim4refund.entities.ClaimRefundStatusMSTR;

import java.util.List;

public interface ClaimRefundStatusService {
    void create(ClaimRefundStatusMSTR entity);

    List<ClaimRefundStatusMSTR> get();

    ClaimRefundStatusMSTR findById(String id);

    ClaimRefundStatusMSTR update(ClaimRefundStatusMSTR entity);

    void delete(String id);
}